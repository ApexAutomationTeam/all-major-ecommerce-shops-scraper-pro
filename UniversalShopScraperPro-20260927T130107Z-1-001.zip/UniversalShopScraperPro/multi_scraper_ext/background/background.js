// ═══════════════════════════════════════════════════════════════════════
// background/background.js — PDP enrichment via hidden background tabs
// v3.0 changes:
//  • Tabs are polled + re-extracted up to 3x (merging newly-found fields)
//    instead of a single fixed wait + single-shot extraction — pages that
//    render a little slower than our wait no longer come back empty.
//  • Works together with core/visibilitySpoof.js (a document_start
//    content script declared in manifest.json) which stops storefronts
//    from deferring their store/seller/price/spec blocks just because
//    the tab isn't the one currently in front.
//  • Site scraping logic itself lives in pdp/<site>PDP.js, loaded via
//    chrome.scripting.executeScript({files:[...]}) instead of being
//    inlined here — see core/pdpRunner.js for the dispatcher.
// ═══════════════════════════════════════════════════════════════════════
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get('files', ({ files }) => {
    if (!files) chrome.storage.local.set({ files: [] });
  });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'stopEnrichment') {
    _stopEnrichment = true;
    sendResponse({ stopped: true });
    return true;
  }
  if (msg.type === 'enrichPDP') {
    enrichProducts(msg.products, msg.site).then(enriched => {
      sendResponse({ enriched });
    }).catch(e => sendResponse({ error: e.message }));
    return true;
  }
  if (msg.type === 'captureScreenshot') {
    // Part of the debug bundle saved when a scrape finds 0 products —
    // a screenshot alongside the HTML/JSON snapshot so a human can see
    // at a glance what the page actually looked like (login wall? empty
    // results? completely different layout?).
    chrome.tabs.captureVisibleTab(null, { format: 'png' }, dataUrl => {
      if (chrome.runtime.lastError) sendResponse({ error: chrome.runtime.lastError.message });
      else sendResponse({ dataUrl });
    });
    return true;
  }
});

let _stopEnrichment = false;

function waitForTabComplete(tabId, timeoutMs) {
  return new Promise(resolve => {
    const start = Date.now();
    const poll = () => {
      chrome.tabs.get(tabId, tab => {
        if (chrome.runtime.lastError || !tab || tab.status === 'complete' || Date.now() - start > timeoutMs) {
          resolve();
        } else {
          setTimeout(poll, 400);
        }
      });
    };
    poll();
  });
}

const SITE_WAIT = {
  aliexpress: 4500,
  temu: 4000,
  '1688': 4000,
  alibaba: 3500,
  dhgate: 3500,
  default: 3000
};

const KEY_FIELDS = ['storeLink', 'rating', 'reviews', 'salePrice', 'images'];

async function extractOnce(tabId, site) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['core/helpers.js', 'core/pdpRunner.js', `pdp/${site}PDP.js`]
    });
    const res = await chrome.scripting.executeScript({
      target: { tabId },
      func: s => window.ShopPDPRun(s),
      args: [site]
    });
    return (res[0] && res[0].result) || {};
  } catch (e) {
    return {};
  }
}

// Runs extraction up to 3x, merging any newly-discovered non-empty field
// into the accumulated result. Stops early once the fields that matter
// most (store link, rating, reviews, price) are all filled, or after 3
// attempts / ~5s of extra polling — whichever comes first.
async function extractWithRetry(tabId, site) {
  let acc = {};
  for (let attempt = 0; attempt < 3; attempt++) {
    const cur = await extractOnce(tabId, site);
    Object.keys(cur).forEach(k => { if (!acc[k] && cur[k]) acc[k] = cur[k]; });
    const filled = KEY_FIELDS.filter(k => acc[k]).length;
    if (filled >= 3) break;
    if (attempt < 2) await new Promise(r => setTimeout(r, 1600));
  }
  return acc;
}

async function enrichProducts(products, site) {
  _stopEnrichment = false;
  const enriched = [];
  const DELAY = 1800;
  const MAX = Math.min(products.length, 15);
  const postWait = SITE_WAIT[site] || SITE_WAIT.default;

  for (let i = 0; i < MAX; i++) {
    if (_stopEnrichment) {
      for (let j = i; j < products.length; j++) enriched.push(products[j]);
      return enriched;
    }
    const p = products[i];
    const url = p.Link || '';
    if (!url || !url.startsWith('http')) { enriched.push(p); continue; }

    try {
      const tab = await chrome.tabs.create({ url, active: false });
      await waitForTabComplete(tab.id, 15000);
      await new Promise(r => setTimeout(r, postWait));
      const pdp = await extractWithRetry(tab.id, site);
      enriched.push({
        ...p,
        StoreLink: pdp.storeLink || p.StoreLink || '',
        Store: pdp.storeName || p.Store || '',
        Rating: pdp.rating || p.Rating || '',
        Reviews: pdp.reviews || p.Reviews || '',
        SalePrice: pdp.salePrice || p.SalePrice || '',
        OrigPrice: pdp.origPrice || p.OrigPrice || '',
        Sold: pdp.sold || p.Sold || '',
        Description: pdp.description || p.Description || '',
        Specifications: pdp.specs || p.Specifications || '',
        Return: pdp.returns || p.Return || '',
        SupplierInfo: pdp.supplierInfo || p.SupplierInfo || '',
        Images: pdp.images || p.Images || ''
      });
      await chrome.tabs.remove(tab.id);
    } catch (e) {
      enriched.push(p);
    }
    if (i < MAX - 1) await new Promise(r => setTimeout(r, DELAY));
  }
  for (let i = MAX; i < products.length; i++) enriched.push(products[i]);
  return enriched;
}
