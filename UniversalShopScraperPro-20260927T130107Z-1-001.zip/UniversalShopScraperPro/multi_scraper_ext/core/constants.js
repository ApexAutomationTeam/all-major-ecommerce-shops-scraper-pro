// ═══════════════════════════════════════════════════════════════════════
// core/constants.js — shared constants (popup UI context)
// ═══════════════════════════════════════════════════════════════════════
const COLORS = {
  amazon: '#FF9900', ebay: '#E53238', walmart: '#0071DC', etsy: '#F1641E',
  aliexpress: '#FF4747', alibaba: '#FF6A00', temu: '#FB7701', daraz: '#F85606',
  dhgate: '#FF6600', madeinchina: '#D4380D', '1688': '#FF4400', unknown: '#6B7280'
};
const SUPPORTED_SITES = ['amazon','ebay','walmart','etsy','aliexpress','alibaba','temu','daraz','dhgate','madeinchina','1688'];
const MIN_PRICE = 5;
