// ═══════════════════════════════════════════════════════════════════════
// core/siteDetector.js — URL → site key (popup UI context)
// ═══════════════════════════════════════════════════════════════════════
function detectSite(u) {
  if (!u) return 'unknown';
  if (u.includes('amazon.')) return 'amazon';
  if (u.includes('ebay.')) return 'ebay';
  if (u.includes('walmart.')) return 'walmart';
  if (u.includes('etsy.')) return 'etsy';
  if (u.includes('aliexpress.')) return 'aliexpress';
  if (u.includes('alibaba.')) return 'alibaba';
  if (u.includes('temu.')) return 'temu';
  if (u.includes('daraz.')) return 'daraz';
  if (u.includes('dhgate.')) return 'dhgate';
  if (u.includes('made-in-china.')) return 'madeinchina';
  if (u.includes('1688.')) return '1688';
  return 'unknown';
}
