// ═══════════════════════════════════════════════════════════════════════
// core/analyzer.js — Pros/Cons/Flags/Recommendation engine
// Self-contained: safe to inject into pages OR load in popup context.
// ═══════════════════════════════════════════════════════════════════════
function nmVal(v) { return parseFloat(String(v).replace(/[^0-9.]/g, '')) || 0; }

// BUG FIX (per user request): price is scraped exactly as shown on the
// site — no currency conversion, no invented columns. The problem was
// that "High price"/"Mid-range"/"Very cheap" used fixed USD-scale
// numbers against whatever currency happened to be on screen, so a PKR
// 6,236 (~USD 22) product got called "High price" just because 6236 is
// a big raw number. Fix: detect which currency symbol/code is actually
// in the price string and judge against bands sized for THAT currency,
// still using only the number the site displayed — never converting it.
const PRICE_BANDS = {
  PKR: { min: 300, accessible: 1500, mid: 8000, high: 40000 },
  INR: { min: 400, accessible: 1500, mid: 8000, high: 40000 },
  CNY: { min: 30, accessible: 100, mid: 700, high: 3500 },
  DEFAULT: { min: 5, accessible: 20, mid: 100, high: 500 } // USD, EUR, GBP and anything unrecognized
};

function detectPriceBand(priceStr) {
  const s = String(priceStr || '');
  if (/PKR|Rs\.?\s*\d/i.test(s)) return PRICE_BANDS.PKR;
  if (/₹|INR/i.test(s)) return PRICE_BANDS.INR;
  if (/¥|RMB|CNY/i.test(s)) return PRICE_BANDS.CNY;
  return PRICE_BANDS.DEFAULT;
}

function analyzeProduct(r) {
  const band = detectPriceBand(r.SalePrice);
  const MIN = band.min;
  const pros = [], cons = [], flags = [];
  const rat = nmVal(r.Rating);
  const rev = nmVal(String(r.Reviews).replace(/[Kk]/, '000').replace(/[Mm]/, '000000'));
  const price = nmVal(r.SalePrice);

  if (rat >= 4.8) pros.push('Exceptional ' + r.Rating + '★');
  else if (rat >= 4.6) pros.push('Excellent ' + r.Rating + '★');
  else if (rat >= 4.4) pros.push('Strong ' + r.Rating + '★');
  else if (rat >= 4.0) pros.push('Solid ' + r.Rating + '★');
  else if (rat >= 3.5) cons.push('Mixed ' + r.Rating + '★');
  else if (rat > 0) { cons.push('Weak ' + r.Rating + '★'); flags.push('⚠️ Below 3.5★'); }
  else if (r.Rating && r.Rating !== 'N/A') flags.push('⚠️ No rating');
  else if (!r.Rating) flags.push('⚠️ No rating');

  if (rev >= 10000) pros.push('Massive ' + r.Reviews + ' reviews');
  else if (rev >= 1000) pros.push(r.Reviews + ' reviews');
  else if (rev >= 200) pros.push('Healthy ' + r.Reviews + ' reviews');
  else if (rev >= 50) cons.push('Modest ' + r.Reviews + ' reviews');
  else if (rev > 0) { cons.push('Only ' + r.Reviews + ' reviews'); flags.push('⚠️ <50 reviews'); }
  else if (r.Reviews && r.Reviews !== 'N/A') flags.push('⚠️ No reviews');

  if (price >= band.high) cons.push('High price');
  else if (price >= band.mid) pros.push('Mid-range');
  else if (price >= band.accessible) pros.push('Accessible price');
  else if (price >= band.min) { cons.push('Very cheap'); flags.push('⚠️ Suspiciously low'); }

  if (/free.?(?:ship|deliv|env[íi]o|gratis|包邮)/i.test((r.DelCost || '') + (r.Delivery || ''))) pros.push('Free shipping');
  if (/renewed|refurb/i.test(r.Item || '')) { cons.push('Refurbished'); flags.push('⚠️ Not new'); }
  if (/deluxe|premium|collector/i.test(r.Item || '')) pros.push('Premium edition');
  if (/best seller|m[áa]s vendido|top rated|best.selling|endorsed/i.test((r.Item || '') + (r.Badge || ''))) pros.push('Best Seller');

  const origP = nmVal(r.OrigPrice);
  if (origP > 0 && price > 0 && origP > price) {
    const disc = Math.round((1 - price / origP) * 100);
    r.Discount = disc + '% off';
    if (disc >= 50) pros.push(disc + '% discount'); else if (disc >= 20) pros.push(disc + '% off');
  }

  const soldN = nmVal(String(r.Sold).replace(/[Kk]/, '000').replace(/[Mm]/, '000000'));
  // BUG FIX (live-verified): every scraper's Sold field already includes
  // its own suffix ("120 sold", "5,000+ sold", "50 pieces"), so appending
  // another literal " sold" here produced double wording like "120 sold
  // sold". Sold is descriptive enough on its own.
  if (soldN >= 10000) pros.push('Massive sales (' + r.Sold + ')');
  else if (soldN >= 1000) pros.push('Strong sales (' + r.Sold + ')');
  else if (soldN >= 100) pros.push(r.Sold);

  let sc = 0;
  if (rat >= 4.4) sc += 3; else if (rat >= 4.0) sc += 2; else if (rat >= 3.5) sc += 1;
  if (rev >= 1000) sc += 3; else if (rev >= 200) sc += 2; else if (rev >= 50) sc += 1;
  if (soldN >= 1000) sc += 1;
  if (price < MIN * 3 && rev < 50) sc -= 1;
  r.Rec = sc >= 6 ? '✅ TOP PICK' : sc >= 4 ? '👍 RECOMMENDED' : sc >= 2 ? '🤔 ACCEPTABLE' : '❌ SKIP';

  r.Pros = pros.join(' • ') || '—';
  r.Cons = cons.join(' • ') || '—';
  r.Flags = flags.join(' • ') || 'None';
  if (!r.Discount) r.Discount = '—';
  if (!r.Setup) r.Setup = 'N/A';
  if (!r.Condition) r.Condition = 'New';
  if (!r.MOQ) r.MOQ = '—';
  if (!r.SupplierInfo) r.SupplierInfo = '—';
  if (!r.Description) r.Description = '—';
  if (!r.Specifications) r.Specifications = '—';
  if (!r.StoreLink) r.StoreLink = '—';
  if (!r.Store) r.Store = '—';
  if (!r.Rating) r.Rating = '—';
  if (!r.Reviews || r.Reviews === 'N/A') r.Reviews = r.Reviews === 'N/A' ? 'N/A' : '—';
  if (!r.Images) r.Images = '—';
  return r;
}

if (typeof window !== 'undefined') { window.analyzeProduct = analyzeProduct; window.nmVal = nmVal; }
