// ═══════════════════════════════════════════════════════════════════════
// core/visibilitySpoof.js — content script, run_at: document_start
// Root-cause fix for "empty store link / rating / reviews on Deep Scrape":
// Deep Scrape opens PDP pages in BACKGROUND tabs (active:false) so the
// user isn't interrupted. Many modern storefronts (AliExpress, Temu,
// 1688, Alibaba, DHgate...) are SPAs that check document.hidden /
// visibilityState and DEFER rendering store/seller info, price blocks,
// and spec tables while a tab is in the background. That's why fields
// come back blank even though the data exists on the page.
// This script makes every supported storefront believe it is always the
// visible, focused tab, so those lazy sections render normally whether
// or not the tab is actually in front. It is intentionally always-on
// (not gated behind a scraping flag) because gating it would require an
// async storage read that can't win the race against document_start.
// ═══════════════════════════════════════════════════════════════════════
(function () {
  try {
    Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });
    Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
    document.hasFocus = function () { return true; };
    const fire = () => {
      try {
        document.dispatchEvent(new Event('visibilitychange'));
        window.dispatchEvent(new Event('focus'));
      } catch (e) {}
    };
    fire();
    document.addEventListener('readystatechange', fire);
    window.addEventListener('DOMContentLoaded', fire);
    setInterval(fire, 800);
  } catch (e) {}
})();
