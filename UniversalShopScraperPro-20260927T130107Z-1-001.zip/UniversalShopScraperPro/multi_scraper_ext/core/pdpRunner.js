// ═══════════════════════════════════════════════════════════════════════
// core/pdpRunner.js — dispatcher injected alongside core/helpers.js and
// exactly one pdp/<site>PDP.js file, run on each product detail page
// during Deep Scrape. Wakes the page first (see helpers.wakePage) since
// these tabs are opened in the background and many storefronts defer
// rendering store/seller/price/spec blocks until they think the tab is
// visible (see core/visibilitySpoof.js for the companion fix).
// ═══════════════════════════════════════════════════════════════════════
window.PDPRegistry = window.PDPRegistry || {};

window.ShopPDPRun = async function (site) {
  const empty = { storeLink: '', storeName: '', description: '', specs: '', returns: '', supplierInfo: '', rating: '', reviews: '', salePrice: '', origPrice: '', sold: '', images: '' };
  try {
    const fn = window.PDPRegistry[site];
    if (!fn) return empty;
    try { await window.ShopHelpers.wakePage(); } catch (e) {}
    const r = fn() || {};
    if (!r.images) { try { r.images = window.ShopHelpers.pdpCollectGalleryImages(6).join(' | '); } catch (e) {} }
    return Object.assign({}, empty, r);
  } catch (e) {
    return empty;
  }
};
