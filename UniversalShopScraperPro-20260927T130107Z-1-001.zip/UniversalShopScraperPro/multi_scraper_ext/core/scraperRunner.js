// ═══════════════════════════════════════════════════════════════════════
// core/scraperRunner.js — dispatcher injected alongside core/helpers.js,
// core/analyzer.js and exactly one scrapers/<site>.js file. Wakes the
// page (see helpers.wakePage), runs the site's registered raw scraper,
// analyzes every row, and extracts a search keyword for the filename.
// Wrapped defensively so a single bad site page can never throw all the
// way back to the extension (that used to look like "no products found"
// even when the DOM had simply changed shape).
// ═══════════════════════════════════════════════════════════════════════
window.ScraperRegistry = window.ScraperRegistry || {};

// Builds a best-effort snapshot of the page when structured scraping
// finds nothing at all — instead of the extension just saying "no
// products found" with zero information to act on, the user gets the
// raw material to see WHY (new layout? blocked/CAPTCHA page? empty
// results?) and can still get something out of the run.
function buildRawCapture() {
  try {
    const meta = document.querySelector('meta[name="description"]');
    const jsonLd = [...document.querySelectorAll('script[type="application/ld+json"]')].map(s => (s.textContent || '').trim()).filter(Boolean).slice(0, 5);
    const bodyText = (document.body.innerText || '').replace(/\s+/g, ' ').trim();
    // Debug bundle, per user request: enough to build a new selector in
    // minutes without re-visiting the site — full HTML tree (not just a
    // screenshot), any hydration JSON the page shipped, JSON-LD, and the
    // visible text as a plain-language backup.
    let html = '';
    try { html = document.documentElement.outerHTML.substring(0, 200000); } catch (e) {}
    let embeddedStateKeys = [];
    let embeddedStateSample = '';
    try {
      const state = window.ShopHelpers && window.ShopHelpers.scanEmbeddedState ? window.ShopHelpers.scanEmbeddedState() : {};
      embeddedStateKeys = Object.keys(state);
      if (embeddedStateKeys.length) embeddedStateSample = JSON.stringify(state[embeddedStateKeys[0]]).substring(0, 5000);
    } catch (e) {}
    return {
      url: location.href,
      title: document.title || '',
      metaDescription: meta ? (meta.getAttribute('content') || '') : '',
      visibleTextExcerpt: bodyText.substring(0, 4000),
      jsonLdBlocks: jsonLd,
      imageCount: document.querySelectorAll('img').length,
      linkCount: document.querySelectorAll('a').length,
      html: html,
      embeddedStateKeys: embeddedStateKeys,
      embeddedStateSample: embeddedStateSample,
      capturedAt: new Date().toISOString()
    };
  } catch (e) {
    return { url: location.href, title: document.title || '', error: e && e.message };
  }
}

window.ShopScraperRun = async function (site) {
  try {
    const rawFn = window.ScraperRegistry[site];
    if (!rawFn) return { rows: [], kw: '', site, error: 'no-scraper-registered', rawCapture: buildRawCapture() };
    try { await window.ShopHelpers.wakePage(); } catch (e) {}
    let raw = [];
    try { raw = rawFn() || []; } catch (e) { raw = []; }
    const rows = raw.map(r => { try { return window.analyzeProduct(r); } catch (e) { return r; } });

    const qs = new URLSearchParams(location.search);
    let kw = qs.get('k') || qs.get('q') || qs.get('_nkw') || qs.get('search_key') || qs.get('SearchText') || qs.get('keywords') || qs.get('searchkey') || '';
    if (!kw && site === 'aliexpress') {
      const pm = location.pathname.match(/\/w\/wholesale-([^.]+)/i);
      if (pm) kw = decodeURIComponent(pm[1].replace(/-/g, ' '));
    }
    if (!kw) kw = (document.title || 'products').split(/[-|–]/)[0].trim();
    kw = kw.substring(0, 25).replace(/\s+/g, '-');
    const result = { rows, kw, site };
    if (!rows.length) result.rawCapture = buildRawCapture();
    return result;
  } catch (e) {
    return { rows: [], kw: '', site, error: e && e.message, rawCapture: buildRawCapture() };
  }
};
