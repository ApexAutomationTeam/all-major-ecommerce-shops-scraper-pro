// ═══════════════════════════════════════════════════════════════════════
// core/xlsxBuilder.js — HTML-table-as-.xls builder (popup UI context)
// ═══════════════════════════════════════════════════════════════════════
function escXlsx(s) { return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }

function buildXLSX(entries, site, combo) {
  combo = combo || false;
  const e = escXlsx;
  const H = ['#','Item Name','Image(s)','Store/Vendor','Store Link','Product Link','Sale Price','Original Price','Discount','Delivery Cost','Setup Cost','Est. Delivery','Return Policy','Rating','Reviews','Sold','Condition','Badge','MOQ','Supplier Info','Description','Specifications','Pros','Cons','Red Flags','Recommendation'];
  const css = `body{margin:0;font-family:Arial}table{border-collapse:collapse;font-family:Arial;font-size:9pt;width:100%}td,th{border:1px solid #bbb;padding:5px;vertical-align:top;max-width:300px;word-wrap:break-word}th{background:#1F4E79;color:#fff;font-weight:bold;text-align:center}.mh{background:#1E1B4B;color:#fff;font-size:14pt;font-weight:bold;text-align:center;padding:12px}.fh{background:#8B0000;color:#FFD700;font-size:11pt;font-weight:bold;text-align:center;padding:10px;border-top:3px solid #FFD700}.fs{background:#4A148C;color:#fff;font-size:9pt;font-weight:bold;text-align:center;padding:4px}.g{background:#E8F5E9}.y{background:#FFFDE7}.r{background:#FFEBEE}.b{background:#E3F2FD}.rec{font-weight:bold}.flag{color:#B71C1C;font-weight:600}.pros{color:#1B5E20}.cons{color:#7B241C}a{color:#1155CC;text-decoration:none}`;

  function imgCell(images) {
    if (!images || images === '—') return '—';
    const urls = String(images).split(' | ').filter(Boolean);
    if (!urls.length) return '—';
    return urls.map((u, i) => '<a href="' + e(u) + '">Img' + (i + 1) + '</a>').join(' ');
  }

  function rw(r, n) {
    const cl = (r.Rec || '').startsWith('✅') ? 'g' : (r.Rec || '').startsWith('❌') ? 'r' : (r.Rec || '').startsWith('👍') ? 'b' : 'y';
    return `<tr class="${cl}"><td>${n}</td><td><b>${e(r.Item)}</b></td><td>${imgCell(r.Images)}</td><td>${e(r.Store)}</td><td>${r.StoreLink && r.StoreLink !== '—' ? `<a href="${e(r.StoreLink)}">${e(r.Store !== '—' ? r.Store : 'View Store')}</a>` : '—'}</td><td>${r.Link ? `<a href="${e(r.Link)}">View</a>` : '—'}</td><td><b>${e(r.SalePrice)}</b></td><td>${e(r.OrigPrice)}</td><td>${e(r.Discount)}</td><td>${e(r.DelCost)}</td><td>${e(r.Setup)}</td><td>${e(r.Delivery)}</td><td>${e(r.Return)}</td><td><b>${e(r.Rating)}</b></td><td>${e(r.Reviews)}</td><td>${e(r.Sold)}</td><td>${e(r.Condition)}</td><td>${e(r.Badge)}</td><td>${e(r.MOQ)}</td><td>${e(r.SupplierInfo)}</td><td>${e(r.Description)}</td><td>${e(r.Specifications)}</td><td class="pros">${e(r.Pros)}</td><td class="cons">${e(r.Cons)}</td><td class="flag">${e(r.Flags)}</td><td class="rec">${e(r.Rec)}</td></tr>`;
  }

  let html = `<html xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"><style>${css}</style></head><body><table>`;
  if (!combo) {
    const f = entries[0];
    html += `<tr><td class="mh" colspan="${H.length}">🔍 ${(f.site || '').toUpperCase()} — "${e(f.keyword)}"</td></tr><tr>${H.map(h => '<th>' + h + '</th>').join('')}</tr>`;
    f.rows.forEach((r, i) => { html += rw(r, i + 1); });
  } else {
    const tot = entries.reduce((s, f) => s + f.rows.length, 0);
    html += `<tr><td class="mh" colspan="${H.length}">🔍 COMBINED — ${entries.length} FILES → ${tot} PRODUCTS</td></tr>`;
    let off = 0;
    entries.forEach((f, idx) => {
      html += `<tr><td class="fh" colspan="${H.length}">📁 FILE ${idx + 1}: ${e(f.name)} — ${(f.site || '').toUpperCase()} — ${f.rows.length} products</td></tr><tr><td class="fs" colspan="${H.length}">Search: "${e(f.keyword)}"</td></tr><tr>${H.map(h => '<th>' + h + '</th>').join('')}</tr>`;
      f.rows.forEach((r, i) => { html += rw(r, off + i + 1); });
      off += f.rows.length;
    });
  }
  html += '</table></body></html>';
  return html;
}

// Used when a scrape finds zero structured products. Instead of handing
// back an empty/failed run, we save whatever raw material we captured
// from the page (visible text, JSON-LD blobs, counts) so the user has
// something to look at and Claude/a developer has a lead on what
// changed on the site.
function buildRawCaptureXLSX(capture, site) {
  const e = escXlsx;
  const css = `body{margin:0;font-family:Arial}table{border-collapse:collapse;font-family:Arial;font-size:9pt;width:100%}td,th{border:1px solid #bbb;padding:6px;vertical-align:top;word-wrap:break-word}th{background:#8B0000;color:#FFD700;font-weight:bold;text-align:left}.mh{background:#1E1B4B;color:#fff;font-size:13pt;font-weight:bold;text-align:center;padding:12px}.k{background:#F5F5F5;font-weight:bold;width:160px}`;
  const rows = [
    ['URL', capture.url || ''],
    ['Page Title', capture.title || ''],
    ['Meta Description', capture.metaDescription || ''],
    ['Image Count on Page', String(capture.imageCount || 0)],
    ['Link Count on Page', String(capture.linkCount || 0)],
    ['Captured At', capture.capturedAt || ''],
    ['Error (if any)', capture.error || '—']
  ];
  let html = `<html xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"><style>${css}</style></head><body><table>`;
  html += `<tr><td class="mh" colspan="2">⚠️ RAW CAPTURE — ${e((site || '').toUpperCase())} — no structured products found, page snapshot saved instead</td></tr>`;
  rows.forEach(([k, v]) => { html += `<tr><td class="k">${e(k)}</td><td>${e(v)}</td></tr>`; });
  html += `<tr><th colspan="2">Note</th></tr>`;
  html += `<tr><td colspan="2">Full page HTML and a screenshot were saved alongside this file in the same "debug" folder — use those to write a new selector.</td></tr>`;
  html += `<tr><th colspan="2">Embedded JS state objects found (${(capture.embeddedStateKeys || []).length}): ${e((capture.embeddedStateKeys || []).join(', ') || 'none')}</th></tr>`;
  if (capture.embeddedStateSample) html += `<tr><td class="k">Sample</td><td>${e(capture.embeddedStateSample.substring(0, 2000))}</td></tr>`;
  html += `<tr><th colspan="2">JSON-LD blocks found on page (${(capture.jsonLdBlocks || []).length})</th></tr>`;
  (capture.jsonLdBlocks || []).forEach((blob, i) => { html += `<tr><td class="k">Block ${i + 1}</td><td>${e(blob.substring(0, 2000))}</td></tr>`; });
  html += `<tr><th colspan="2">Visible page text (first 4000 chars)</th></tr>`;
  html += `<tr><td colspan="2">${e(capture.visibleTextExcerpt || '')}</td></tr>`;
  html += '</table></body></html>';
  return html;
}
