// ═══════════════════════════════════════════════════════════════════════
// core/helpers.js — shared DOM-scraping utilities, injected into pages
// alongside scrapers/*.js and pdp/*.js. Keep 100% self-contained (no
// references to extension APIs — this runs in the PAGE's isolated world).
// ═══════════════════════════════════════════════════════════════════════
function nm(v) { return parseFloat(String(v).replace(/[^0-9.]/g, '')) || 0; }

function absUrl(h) {
  if (!h) return '';
  if (h.startsWith('//')) return 'https:' + h;
  if (h.startsWith('/')) return location.origin + h;
  return h;
}

function itemId(u) {
  return (String(u).match(/\/item\/(\d+)/i) || String(u).match(/\/(\d{10,})\.html/i) || [])[1] || '';
}

// Walk up from el looking for the nearest ancestor that looks like a
// product/listing card. Falls back to closest() with common card selectors,
// then to the immediate parent so callers always get *something* usable.
function findCard(el, depth) {
  let n = el;
  for (let i = 0; i < (depth || 8) && n.parentElement; i++) {
    n = n.parentElement;
    const c = typeof n.className === 'string' ? n.className : '';
    if (/card|product|item|gallery|list--|search|offer|manhattan|feed/i.test(c) && n.querySelector('img')) return n;
  }
  return el.closest('[class*="card"],[class*="product"],[class*="item"],[class*="gallery"],[class*="list--"]') || el.parentElement || el;
}

// BUG FIX (live-verified — reported by user, AliExpress deep scrape):
// the optional "range" tail (`-second number`) had its currency symbol
// OPTIONAL, so a strikethrough price sitting right next to a discount
// badge like "PKR5,146.35 -68%" got swallowed whole as one match —
// "PKR5,146.35 -68" — instead of stopping cleanly at "PKR5,146.35".
// The second currency symbol is now REQUIRED for a range to be
// recognized, so a bare "-68" (a discount %, not a second price) is
// never absorbed into the previous price.
function firstPrice(t) {
  const m = (t || '').match(/(?:PKR|USD|US\$|Rs\.?|₹|€|£|¥|\$)\s*[\d,.]+(?:\s*[-–]\s*(?:PKR|USD|US\$|Rs\.?|₹|€|£|¥|\$)\s*[\d,.]+)?/g);
  return m || [];
}

function parseRatingReviews(t) {
  let rating = '', reviews = '';
  const ariaM = (t || '').match(/([\d.]+)\s*(?:out of|\/)\s*5/i);
  if (ariaM) rating = ariaM[1];
  const starM = (t || '').match(/\b([1-5](?:\.\d)?)\s*(?:★|stars?|star)\b/i);
  if (!rating && starM) rating = starM[1];
  const revM = (t || '').match(/([\d,.]+[KkMm]?)\s*(?:reviews?|ratings?|feedback)/i);
  if (revM) reviews = revM[1].replace(/,/g, '');
  if (!reviews) {
    const pM = (t || '').match(/\(([\d,.]+[KkMm]?)\)/);
    if (pM && !/sold|bought|orders/i.test(t)) reviews = pM[1].replace(/,/g, '');
  }
  return { rating, reviews };
}

function parseSold(t) {
  const m = (t || '').match(/([\d,.]+[KkMm+]*\+?\s*(?:sold|bought|orders|purchased))/i);
  return m ? m[1] : '';
}

// Forces layout/IntersectionObserver-driven lazy content to render even
// when this tab is not the visually-focused one. Call before scraping.
// BUG FIX (live-verified on DHgate): this used to fire its scroll steps
// on setTimeout and return immediately, so the scraper that ran right
// after it started before ANY of those scrolls actually happened — most
// lazy-loaded product images were still unrendered when we read the DOM
// (71% of DHgate rows came back with zero images in testing). Now
// returns a Promise the caller actually awaits, so scraping only starts
// once every scroll step has happened and settled.
function wakePage() {
  return new Promise(resolve => {
    try {
      const h = document.body.scrollHeight || 2000;
      const steps = [0.15, 0.4, 0.7, 0.95, 0];
      let i = 0;
      const next = () => {
        if (i >= steps.length) { setTimeout(resolve, 400); return; } // final settle time for React-based lazy-load libs (live-verified on DHgate)
        window.scrollTo(0, Math.round(h * steps[i]));
        window.dispatchEvent(new Event('scroll'));
        window.dispatchEvent(new Event('resize'));
        i++;
        setTimeout(next, 320);
      };
      next();
    } catch (e) { resolve(); }
  });
}

// ── PDP-page helpers: store-link scanning + JSON extraction ─────────────
function pdpMakeResult() {
  return { storeLink: '', storeName: '', description: '', specs: '', returns: '', supplierInfo: '', rating: '', reviews: '', salePrice: '', origPrice: '', sold: '', images: '' };
}

// Generic PDP gallery-image fallback: tries obvious gallery containers
// first, then falls back to the largest handful of images anywhere on
// the page. Used by pdpRunner.js when a site-specific extractor didn't
// already fill `images` (product pages almost always have a real photo
// gallery, unlike search cards which sometimes don't).
function pdpCollectGalleryImages(max) {
  max = max || 6;
  const gallerySels = ['#altImages', '#imgTagWrapperId', '[class*="gallery" i]', '[class*="image-view" i]', '[class*="magnifier" i]', '[class*="product-image" i]', '[id*="gallery" i]', '[class*="thumbnail" i]'];
  for (let i = 0; i < gallerySels.length; i++) {
    const el = document.querySelector(gallerySels[i]);
    if (el) {
      const imgs = collectImages(el, max);
      if (imgs.length) return imgs;
    }
  }
  return collectImages(document.body, max);
}

function pdpPickStoreLink(result, href, name) {
  if (!href) return;
  // BUG FIX (live-verified — reported by user): this used to strip the
  // ENTIRE query string (`.split(/[?#]/)[0]`), assuming it was always
  // disposable tracking cruft. On Amazon, an unbranded/generic-brand
  // product's byline link looks like "/s/ref=bl_dp_s_web_0?...", where
  // the query string is the actual brand-filter data — stripping it
  // left a bare "/s", which Amazon just redirects to the homepage. Only
  // the hash fragment is safe to drop unconditionally (it's always a
  // same-page scroll anchor, never load-bearing data).
  const link = absUrl(href).split('#')[0];
  if (!link || link === location.href.split('#')[0]) return;
  if (!result.storeLink) result.storeLink = link;
  if (name && !result.storeName) result.storeName = name.substring(0, 40);
}

function pdpScanLinks(result, patterns, nameFilter) {
  document.querySelectorAll('a[href]').forEach(a => {
    if (result.storeLink && result.storeName) return;
    const h = a.getAttribute('href') || '';
    const t = (a.textContent || '').trim();
    if (!patterns.some(p => h.includes(p))) return;
    if (nameFilter && (t.length < 2 || t.length > 45)) return;
    if (/sign in|register|help|policy|cart|wishlist|download/i.test(t)) return;
    pdpPickStoreLink(result, h, t);
  });
}

function pdpParseJsonScripts(result, keys, site) {
  document.querySelectorAll('script:not([src])').forEach(s => {
    const txt = s.textContent || '';
    if (!keys.some(k => txt.includes(k))) return;
    keys.forEach(key => {
      const nameM = txt.match(new RegExp('"' + key + 'Name"\\s*:\\s*"([^"]+)"'));
      const idM = txt.match(new RegExp('"' + key + 'Id"\\s*:\\s*"?([\\d]+)"?'));
      if (nameM && !result.storeName) result.storeName = nameM[1].substring(0, 40);
      if (idM && !result.storeLink && site === 'aliexpress') result.storeLink = 'https://www.aliexpress.com/store/' + idM[1];
      if (idM && !result.storeLink && site === 'dhgate') result.storeLink = 'https://www.dhgate.com/store/' + idM[1];
    });
    const storeM = txt.match(/"storeName"\s*:\s*"([^"]+)"/);
    const storeIdM = txt.match(/"storeId"\s*:\s*"?(\d+)"?/);
    if (storeM && !result.storeName) result.storeName = storeM[1].substring(0, 40);
    if (storeIdM && !result.storeLink && site === 'aliexpress') result.storeLink = 'https://www.aliexpress.com/store/' + storeIdM[1];
  });
}

function pdpParseLdJson(result) {
  document.querySelectorAll('script[type="application/ld+json"]').forEach(jld => {
    try {
      const d = JSON.parse(jld.textContent);
      const items = Array.isArray(d) ? d : [d];
      items.forEach(item => {
        const brand = (item.brand && item.brand.name) || item.brand;
        const seller = (item.seller && item.seller.name) || (item.offers && item.offers.seller && item.offers.seller.name);
        if (seller && !result.storeName) result.storeName = seller.substring(0, 40);
        if (brand && !result.storeName) result.storeName = brand.substring(0, 40);
        const ar = item.aggregateRating || {};
        if (ar.ratingValue && !result.rating) result.rating = String(ar.ratingValue);
        if (ar.reviewCount && !result.reviews) result.reviews = String(ar.reviewCount);
        const offer = item.offers || {};
        if (offer.price && !result.salePrice) {
          const curr = offer.priceCurrency || '';
          result.salePrice = curr && offer.price ? curr + ' ' + offer.price : offer.price;
        }
      });
    } catch (e) {}
  });
}

// ── Image extraction ─────────────────────────────────────────────────
// Strips common thumbnail-size query params/path segments so we keep the
// full-resolution version of a marketplace image instead of a 64x64 crop.
function upgradeImageUrl(u) {
  if (!u) return '';
  let s = absUrl(u);
  s = s.replace(/\.?_(?:SS|SR|SX|SY|SL|AC_UL|AC_US|UX|UY)\d+(?:_\d+)?_\.(jpg|png|webp)/i, '.$1'); // Amazon — also eats the preceding "." so we don't leave "name..jpg"
  s = s.replace(/\.(?:jpg|jpeg|png|webp)_\d+x\d+(?:q\d+)?\.(jpg|jpeg|png|webp)/i, '.$1'); // AliExpress/Alibaba
  s = s.replace(/_\d+x\d+\.(jpg|jpeg|png|webp)$/i, '.$1');
  s = s.replace(/[?&](?:w|width|h|height|size|imwidth|imageView2)=\d+[^&]*/gi, '');
  return s;
}

function isPlaceholderImage(u) {
  if (!u) return true;
  if (u.startsWith('data:')) return true;
  if (/placeholder|blank\.gif|spacer\.gif|1x1|loading\.gif|lazy-?load/i.test(u)) return true;
  return false;
}

// Filters out seller/store logo badges, "visit store" banners, etc. that
// sit inside a product card next to the real photo but aren't a photo of
// the product itself (live-verified on eBay: a "Visit <seller> Store!"
// logo — same tiny image repeated across every single row — was getting
// scraped as if it were a product image).
function isLikelyLogoOrBadge(img) {
  try {
    // BUG FIX (live-verified on Daraz): unbounded "icon" matched inside
    // ordinary product words like "silicone", nuking the real photo.
    // Every keyword below is now word-bounded (\b) so it only matches
    // whole words, not substrings of unrelated text.
    const alt = (img.getAttribute('alt') || '').toLowerCase();
    if (/\blogo\b|\bvisit\b.*\bstore\b|\bseller\b|\bstore\b!?$|\bbadge\b|\bicon\b|\baudited\b|\bdiamond member\b|\bsecured trading\b|\bverified supplier\b|\bview larger\b/i.test(alt)) return true;
    const cls = (img.className || '') + ' ' + ((img.closest('[class*="logo" i],[class*="seller" i],[class*="badge" i]') || {}).className || '');
    if (/\blogo\b|seller-logo|store-logo|\bbadge\b/i.test(cls)) return true;
    // BUG FIX (live-verified on Made-in-China): trust badges/certification
    // icons ("Audited Supplier", "Secured Trading", "Diamond Member") were
    // slipping through because their alt text didn't match any keyword
    // above. Those badge assets are consistently served from an
    // "/icon/"-ish or "/logo/"-ish URL PATH (checking the path, not the
    // alt text, is more reliable and generalizes across sites/languages).
    const src = img.getAttribute('data-src') || img.currentSrc || img.src || '';
    if (/\/(icon|logo|badge|sprite)s?[-_/]/i.test(src)) return true;
    // Real product photos are essentially never this small; store/seller
    // logos and rating icons usually are. naturalWidth is 0 for images
    // that haven't loaded yet, so we only reject when we KNOW the size.
    if (img.naturalWidth && img.naturalHeight && (img.naturalWidth < 60 || img.naturalHeight < 60)) return true;
  } catch (e) {}
  return false;
}

// Collects candidate <img> sources from a card/element, preferring
// data-src/srcset (real image) over src (often a lazy-load placeholder),
// upgrades to full-res, dedupes, and returns up to `max` URLs.
function collectImages(scope, max) {
  max = max || 5;
  const out = [];
  const seen = {};
  (scope ? scope.querySelectorAll('img') : []).forEach(img => {
    if (out.length >= max) return;
    if (isLikelyLogoOrBadge(img)) return;
    let src = img.getAttribute('data-src') || img.getAttribute('data-lazy-src') || img.currentSrc || img.src || '';
    if (!src && img.srcset) src = img.srcset.split(',').pop().trim().split(' ')[0];
    if (isPlaceholderImage(src)) return;
    src = upgradeImageUrl(src);
    if (!src || seen[src]) return;
    seen[src] = true;
    out.push(src);
  });
  return out;
}

// ── Generic embedded-JSON hydration scan ─────────────────────────────
// Modern storefronts often ship the exact PLP/PDP data as JSON before
// hydrating React/Next/Vue onto the page. When live selectors miss,
// this gives scrapers one more place to look. Keeps the search shallow
// and defensive — it must never throw even on huge/circular state trees.
function scanEmbeddedState() {
  const found = {};
  try {
    const globals = ['__NEXT_DATA__', '__INITIAL_STATE__', '__APOLLO_STATE__', '__NUXT__', '__PRELOADED_STATE__', 'runParams', '__AER_DATA__'];
    globals.forEach(g => { if (window[g] !== undefined) found[g] = window[g]; });
  } catch (e) {}
  try {
    document.querySelectorAll('script[type="application/json"]').forEach((s, i) => {
      if (i > 10) return; // cap how many we bother parsing
      try { found['inlineJSON_' + i] = JSON.parse(s.textContent); } catch (e) {}
    });
  } catch (e) {}
  return found;
}

// Walks a (possibly huge) object tree shallowly, looking for the first
// value matching each of several key-name candidates. Depth/breadth
// capped hard so this can never hang on a large hydration blob.
function deepFindKeys(obj, keyNames, maxDepth) {
  maxDepth = maxDepth || 5;
  const found = {};
  const seen = new Set();
  function walk(node, depth) {
    if (!node || typeof node !== 'object' || depth > maxDepth || seen.has(node)) return;
    seen.add(node);
    if (seen.size > 4000) return; // hard cap so a huge state tree can't hang the page
    const keys = Array.isArray(node) ? node.slice(0, 30) : Object.keys(node);
    (Array.isArray(node) ? keys : Object.keys(node)).forEach(k => {
      const key = Array.isArray(node) ? null : k;
      const val = Array.isArray(node) ? k : node[k];
      if (key && keyNames.includes(key) && (typeof val === 'string' || typeof val === 'number') && !(key in found)) {
        found[key] = val;
      }
      if (val && typeof val === 'object') walk(val, depth + 1);
    });
  }
  try { walk(obj, 0); } catch (e) {}
  return found;
}

// ── Generic embedded-JSON PRODUCT LIST fallback (last-resort scraping) ──
// This is the shared "even if the DOM changes completely, still get data"
// safety net every PLP scraper falls back to when every DOM strategy comes
// back empty. Instead of guessing one site's exact hydration schema, it
// walks whatever state scanEmbeddedState() found and looks for any array
// of objects that all carry a recognizable title-ish field — matching a
// wide set of aliases used across Amazon/eBay/Walmart/Etsy/AliExpress/
// Alibaba/Temu/Daraz/DHgate/Made-in-China/1688's various hydration
// payloads (React Next.js data, Vue/Nuxt state, Apollo/GraphQL cache,
// custom `runParams`-style blobs, etc.) rather than one specific shape.
// Returns plain {title, id, price, image} candidates; the calling
// scraper still owns turning `id` into a real product URL for its site,
// since only it knows that site's URL pattern.
function findEmbeddedProducts(maxSteps) {
  maxSteps = maxSteps || 800;
  const TITLE_KEYS = ['title', 'name', 'subject', 'productTitle', 'goodsName', 'itemName', 'product_name', 'productName', 'itemTitle', 'displayName'];
  const ID_KEYS = ['productId', 'itemId', 'id', 'goodsId', 'skuId', 'itemid', 'product_id', 'goods_id', 'asin', 'sku'];
  const PRICE_KEYS = ['price', 'salePrice', 'minPrice', 'formatPrice', 'currentPrice', 'displayPrice'];
  const IMAGE_KEYS = ['image', 'imageUrl', 'img', 'pic', 'picUrl', 'thumbnail', 'mainImage', 'imgUrl'];
  const results = [];
  try {
    const state = scanEmbeddedState();
    const seenNodes = new Set();
    Object.keys(state).forEach(key => {
      if (results.length) return;
      const root = state[key];
      if (!root || typeof root !== 'object') return;
      const stack = [root];
      let steps = 0;
      while (stack.length && steps < maxSteps && !results.length) {
        steps++;
        const node = stack.pop();
        if (!node || typeof node !== 'object' || seenNodes.has(node)) continue;
        seenNodes.add(node);
        if (Array.isArray(node)) {
          const looksLikeProducts = node.length > 1 && node.every(x => x && typeof x === 'object' && TITLE_KEYS.some(k => x[k]));
          if (looksLikeProducts) {
            node.forEach(it => {
              const title = TITLE_KEYS.map(k => it[k]).find(Boolean) || '';
              const id = ID_KEYS.map(k => it[k]).find(v => v !== undefined && v !== null && v !== '') || '';
              const priceRaw = PRICE_KEYS.map(k => it[k]).find(v => v !== undefined && v !== null);
              let price = '';
              if (priceRaw && typeof priceRaw === 'object') price = priceRaw.formattedPrice || priceRaw.value || priceRaw.text || '';
              else if (priceRaw !== undefined) price = String(priceRaw);
              const imgRaw = IMAGE_KEYS.map(k => it[k]).find(Boolean);
              const image = imgRaw ? (Array.isArray(imgRaw) ? imgRaw[0] : imgRaw) : '';
              if (title && id) results.push({ title: String(title), id: String(id), price: String(price || ''), image: image ? String(image) : '' });
            });
            return;
          }
          node.forEach(x => { if (x && typeof x === 'object') stack.push(x); });
        } else {
          Object.keys(node).forEach(k => { if (node[k] && typeof node[k] === 'object') stack.push(node[k]); });
        }
      }
    });
  } catch (e) { /* never let this take down the calling scraper */ }
  return results;
}

if (typeof window !== 'undefined') {
  window.ShopHelpers = {
    nm, absUrl, itemId, findCard, firstPrice, parseRatingReviews, parseSold, wakePage,
    pdpMakeResult, pdpPickStoreLink, pdpScanLinks, pdpParseJsonScripts, pdpParseLdJson, pdpCollectGalleryImages,
    upgradeImageUrl, isPlaceholderImage, isLikelyLogoOrBadge, collectImages, scanEmbeddedState, deepFindKeys,
    findEmbeddedProducts
  };
}
