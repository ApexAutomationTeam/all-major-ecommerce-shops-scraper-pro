// ═══════════════════════════════════════════════════════════════════════
// popup/storage.js — saved-file list management (select/combine/delete/clear)
// ═══════════════════════════════════════════════════════════════════════
$('select-all').addEventListener('change', e => {
  document.querySelectorAll('.file-checkbox').forEach(cb => cb.checked = e.target.checked);
  upSel();
});

$('file-list').addEventListener('change', e => {
  if (e.target.classList.contains('file-checkbox')) upSel();
});

$('btn-combine').addEventListener('click', async () => {
  const ch = [...document.querySelectorAll('.file-checkbox:checked')];
  if (ch.length < 2) return;
  const { files = [] } = await chrome.storage.local.get('files');
  const sel = ch.map(c => files[parseInt(c.dataset.idx)]);
  const tot = sel.reduce((s, f) => s + f.rows.length, 0);
  upP(50, `Combining ${sel.length} files...`);
  await downloadXLSX(sel, 'combined', true, `COMBINED_${sel.length}files_${tot}prod.xls`, true);
  upP(100, `✅ Combined ${tot} products`);
  setTimeout(() => upP(0, 'Ready'), 2000);
});

$('btn-delete').addEventListener('click', async () => {
  const ch = [...document.querySelectorAll('.file-checkbox:checked')];
  if (!ch.length || !confirm('Delete?')) return;
  const idxs = ch.map(c => parseInt(c.dataset.idx)).sort((a, b) => b - a);
  const { files = [] } = await chrome.storage.local.get('files');
  idxs.forEach(i => files.splice(i, 1));
  await chrome.storage.local.set({ files });
  $('select-all').checked = false;
  await loadFiles();
});

$('btn-clear').addEventListener('click', async () => {
  if (!confirm('Clear ALL?')) return;
  await chrome.storage.local.set({ files: [] });
  $('select-all').checked = false;
  await loadFiles();
});
