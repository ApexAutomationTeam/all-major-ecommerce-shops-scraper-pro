// ═══════════════════════════════════════════════════════════════════════
// popup/ui.js — rendering helpers for the popup (extension page context)
// ═══════════════════════════════════════════════════════════════════════
const $ = id => document.getElementById(id);

function upP(p, m) {
  $('progress-bar').style.width = p + '%';
  $('progress-bar').textContent = p > 0 ? p + '%' : '';
  $('status').textContent = m;
}

function resetB() {
  $('btn-start').style.display = 'block';
  $('btn-deep').style.display = 'block';
  $('btn-stop').style.display = 'none';
}

async function loadFiles() {
  const { files = [] } = await chrome.storage.local.get('files');
  const list = $('file-list');
  list.innerHTML = '';
  if (!files.length) {
    list.innerHTML = '<div class="empty-state">No files yet</div>';
  } else {
    files.forEach((f, i) => {
      const c = COLORS[f.site] || '#6B7280';
      const d = document.createElement('div');
      d.className = 'file-item';
      d.innerHTML = `<input type="checkbox" class="file-checkbox" data-idx="${i}"><div class="file-info"><div class="file-name">${escXlsx(f.name)}</div><div class="file-meta"><span class="file-site-badge" style="background:${c}">${(f.site || '').toUpperCase()}</span>${f.count} products</div></div>`;
      list.appendChild(d);
    });
  }
  $('file-count').textContent = files.length;
  $('total-files').textContent = files.length;
  $('total-products').textContent = files.reduce((s, f) => s + (f.count || 0), 0);
  upSel();
}

function upSel() {
  const ch = document.querySelectorAll('.file-checkbox:checked');
  $('selected-count').textContent = ch.length;
  $('btn-combine').disabled = ch.length < 2;
  $('btn-delete').disabled = ch.length === 0;
  document.querySelectorAll('.file-item').forEach(x => {
    const cb = x.querySelector('.file-checkbox');
    x.classList.toggle('selected', cb && cb.checked);
  });
}
