// ═══════════════════════════════════════════════════════════════════════
// popup/popup.js — main orchestration: site selection + scrape trigger
// ═══════════════════════════════════════════════════════════════════════
let selectedSite = 'auto';

document.querySelectorAll('.tag').forEach(t => {
  t.addEventListener('click', () => {
    document.querySelectorAll('.tag').forEach(x => x.classList.remove('active'));
    t.classList.add('active');
    selectedSite = t.dataset.site;
  });
});

// Injects core/helpers.js + core/analyzer.js + core/scraperRunner.js +
// scrapers/<site>.js into the active tab, then runs the scrape. Splitting
// the scraper into its own file (per user's requested folder layout)
// still keeps every DOM read 100% inside the target page's isolated
// world — nothing here touches page content directly.
async function runPLPScraper(tabId, site) {
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ['core/helpers.js', 'core/analyzer.js', 'core/scraperRunner.js', `scrapers/${site}.js`]
  });
  const res = await chrome.scripting.executeScript({
    target: { tabId },
    func: s => window.ShopScraperRun(s),
    args: [site]
  });
  return res[0] && res[0].result;
}

async function startScrape(deep) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const site = selectedSite === 'auto' ? detectSite(tab.url) : selectedSite;
  if (site === 'unknown') { $('status').textContent = '❌ Not supported'; return; }

  $('detected-site').style.display = 'block';
  $('detected-site').textContent = '🌐 ' + site.toUpperCase() + (deep ? ' (Deep)' : ' (Quick)');
  $('detected-site').style.color = COLORS[site];
  $('btn-start').style.display = 'none';
  $('btn-deep').style.display = 'none';
  $('btn-stop').style.display = 'block';
  upP(10, 'Scraping PLP...');

  try {
    const data = await runPLPScraper(tab.id, site);
    if (!data || !data.rows || !data.rows.length) {
      if (data && data.rawCapture) {
        await downloadDebugBundle(data.rawCapture, site);
        $('status').textContent = '⚠️ No structured products — saved a debug bundle (xls + HTML + screenshot) instead.';
      } else {
        $('status').textContent = data && data.error ? '❌ ' + data.error : '⚠️ No products. Scroll page first.';
      }
      resetB();
      return;
    }
    upP(40, data.rows.length + ' products found');

    let finalRows = data.rows;

    if (deep) {
      upP(45, 'Deep scrape: enriching from PDPs...');
      try {
        const enrichRes = await chrome.runtime.sendMessage({ type: 'enrichPDP', products: data.rows, site });
        if (enrichRes && enrichRes.enriched) {
          finalRows = enrichRes.enriched.map(analyzeProduct);
          upP(85, finalRows.length + ' enriched');
        }
      } catch (e) {
        upP(70, 'PDP enrichment partial: ' + e.message);
      }
    }

    upP(90, 'Generating XLSX...');
    const { files = [] } = await chrome.storage.local.get('files');
    const fn = `${site}_${data.kw}_${Date.now()}.xls`;
    const fe = { name: fn, count: finalRows.length, timestamp: Date.now(), rows: finalRows, site, keyword: data.kw };
    files.push(fe);
    await chrome.storage.local.set({ files });
    await downloadXLSX([fe], site, false, fn, false);

    upP(100, `✅ ${finalRows.length} from ${site.toUpperCase()}` + (deep ? ' (enriched)' : ''));
    await loadFiles();
    setTimeout(() => { upP(0, 'Ready — open any supported store search page'); }, 3000);
  } catch (e) {
    $('status').textContent = '❌ ' + e.message;
  } finally {
    setTimeout(resetB, 1500);
  }
}

$('btn-start').addEventListener('click', () => startScrape(false));
$('btn-deep').addEventListener('click', () => startScrape(true));
$('btn-stop').addEventListener('click', async () => {
  try { await chrome.runtime.sendMessage({ type: 'stopEnrichment' }); } catch (e) {}
  $('status').textContent = '⏹ Stopped — saving partial data...';
});

loadFiles();
