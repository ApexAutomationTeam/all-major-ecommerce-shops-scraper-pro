// ═══════════════════════════════════════════════════════════════════════
// popup/download.js — turns entries[] into an .xls download
// ═══════════════════════════════════════════════════════════════════════
async function downloadXLSX(entries, site, combo, filename, saveAs) {
  const html = buildXLSX(entries, site, combo);
  const blob = new Blob(['﻿' + html], { type: 'application/vnd.ms-excel' });
  const url = URL.createObjectURL(blob);
  await chrome.downloads.download({ url, filename: `ShopScraperPro/${filename}`, saveAs: !!saveAs });
  setTimeout(() => URL.revokeObjectURL(url), 3000);
}

// Last-resort export when a scrape found zero structured products —
// saves the page snapshot captured by scraperRunner.js's buildRawCapture()
// instead of losing the run entirely.
async function downloadRawCapture(capture, site, filename) {
  const html = buildRawCaptureXLSX(capture, site);
  const blob = new Blob(['﻿' + html], { type: 'application/vnd.ms-excel' });
  const url = URL.createObjectURL(blob);
  await chrome.downloads.download({ url, filename: `ShopScraperPro/${filename}`, saveAs: false });
  setTimeout(() => URL.revokeObjectURL(url), 3000);
}

// Full debug bundle (per user request): the raw-capture .xls above plus
// the actual page HTML (so a real selector can be written in minutes
// instead of guessing from a screenshot) and a screenshot of what the
// tab looked like. Saved as three files under one timestamped name so
// they're easy to find together: ShopScraperPro/debug/<site>_<ts>.*
async function downloadDebugBundle(capture, site) {
  const ts = Date.now();
  const base = `ShopScraperPro/debug/${site}_${ts}`;

  await downloadRawCapture(capture, site, `debug/${site}_${ts}_RAWCAPTURE.xls`);

  if (capture.html) {
    const htmlBlob = new Blob([capture.html], { type: 'text/html' });
    const htmlUrl = URL.createObjectURL(htmlBlob);
    await chrome.downloads.download({ url: htmlUrl, filename: `${base}_dom.html`, saveAs: false });
    setTimeout(() => URL.revokeObjectURL(htmlUrl), 5000);
  }

  try {
    const shot = await chrome.runtime.sendMessage({ type: 'captureScreenshot' });
    if (shot && shot.dataUrl) {
      await chrome.downloads.download({ url: shot.dataUrl, filename: `${base}_screenshot.png`, saveAs: false });
    }
  } catch (e) { /* screenshot is best-effort — the .xls/.html are the important part */ }
}
