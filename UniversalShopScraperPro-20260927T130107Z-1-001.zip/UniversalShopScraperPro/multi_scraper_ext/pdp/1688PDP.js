// ═══════════════════════════════════════════════════════════════════════
// pdp/1688PDP.js — 1688.com product detail page enrichment
// ═══════════════════════════════════════════════════════════════════════
window.PDPRegistry = window.PDPRegistry || {};

window.PDPRegistry['1688'] = function extract1688PDP() {
  const H = window.ShopHelpers;
  const result = H.pdpMakeResult();

  document.querySelectorAll('a[href]').forEach(a => {
    if (result.storeLink) return;
    const h = a.getAttribute('href') || '';
    const sub = h.match(/(?:https?:)?\/\/([a-z0-9]+)\.1688\.com/i);
    const skip = ['detail', 's', 'login', 'm', 'air', 'img', 'i', 'gw', 'offer', 'cbu01', 'cbuce01', 'pub', 'help', 'page', 'trade'];
    if (sub && !skip.includes(sub[1])) {
      result.storeLink = 'https://' + sub[1] + '.1688.com';
      result.storeName = (a.textContent || '').trim().substring(0, 25);
    }
  });

  const text = document.body.innerText || '';
  const pm = text.match(/¥\s*[\d.]+/);
  if (pm) result.salePrice = pm[0];
  const soldM = text.match(/([\d,]+\+?)\s*(?:items sold|pieces sold|sold)/i);
  if (soldM) result.sold = soldM[1] + ' sold';

  return result;
};
