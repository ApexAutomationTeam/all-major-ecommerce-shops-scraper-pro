// ═══════════════════════════════════════════════════════════════════════
// pdp/etsyPDP.js — Etsy product detail page enrichment
// ═══════════════════════════════════════════════════════════════════════
window.PDPRegistry = window.PDPRegistry || {};

window.PDPRegistry.etsy = function extractEtsyPDP() {
  const H = window.ShopHelpers;
  const result = H.pdpMakeResult();
  const text = document.body.innerText || '';
  H.pdpParseLdJson(result);
  H.pdpScanLinks(result, ['/shop/'], true);

  if (!result.storeName) {
    const shopM = text.match(/(?:From shop|Sold by)\s+([^\n]{2,30})/i);
    if (shopM) result.storeName = shopM[1].trim();
  }
  const desc = (document.querySelector('meta[name="description"]') || { getAttribute: () => '' }).getAttribute('content') || '';
  result.description = desc.substring(0, 200);

  if (!result.rating) { const rm = text.match(/([\d.]+)\s*(?:out of 5|\(|\s)/); if (rm) result.rating = rm[1]; }
  if (!result.reviews) { const revM = text.match(/\(([\d,.]+)\)/); if (revM) result.reviews = revM[1].replace(/,/g, ''); }

  // BUG FIX (live-verified — reported by user): Specifications was always
  // empty — this extractor never read the "Item details" toggle section,
  // which holds the real bullet-point spec list ("Solid polycarbonate
  // back", "Flexible, see-through polyurethane sides", etc.). Find that
  // section by its own header button and collect its bullet lines.
  const detailsHeader = [...document.querySelectorAll('button,h2,h3')].find(e => /^Item details$/i.test((e.textContent || '').trim()));
  if (detailsHeader) {
    let sec = detailsHeader.closest('div');
    for (let i = 0; i < 5 && sec; i++) {
      if (/•/.test(sec.innerText || '')) break;
      sec = sec.parentElement;
    }
    if (sec) {
      const bullets = (sec.innerText || '').split('\n').map(l => l.trim()).filter(l => l.startsWith('•')).map(l => l.replace(/^•\s*/, ''));
      if (bullets.length) result.specs = bullets.slice(0, 10).join(' | ');
    }
  }

  return result;
};
