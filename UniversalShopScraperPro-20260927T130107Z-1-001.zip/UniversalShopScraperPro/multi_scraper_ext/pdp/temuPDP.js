// ═══════════════════════════════════════════════════════════════════════
// pdp/temuPDP.js — Temu product detail page enrichment
// ═══════════════════════════════════════════════════════════════════════
window.PDPRegistry = window.PDPRegistry || {};

window.PDPRegistry.temu = function extractTemuPDP() {
  const H = window.ShopHelpers;
  const result = H.pdpMakeResult();
  const text = document.body.innerText || '';
  H.pdpParseLdJson(result);
  H.pdpScanLinks(result, ['mall', '/m-', '/store/'], true);

  const soldBy = text.match(/Sold by\s+([^\n]+)/i);
  if (soldBy && !result.storeName) result.storeName = soldBy[1].substring(0, 25);

  const brandM = text.match(/Brand\s*[:\n]\s*(\S+)/i);
  result.specs = brandM ? 'Brand: ' + brandM[1] : '';

  if (!result.rating) { const rm = text.match(/([\d.]+)\s*(?:out of 5|stars)/i); if (rm) result.rating = rm[1]; }
  if (!result.reviews) { const revM = text.match(/([\d,.]+)\s*reviews?/i); if (revM) result.reviews = revM[1].replace(/,/g, ''); }
  const soldM = text.match(/([\d,.]+[KkMm+]*)\s*sold/i);
  if (soldM) result.sold = soldM[1] + ' sold';

  return result;
};
