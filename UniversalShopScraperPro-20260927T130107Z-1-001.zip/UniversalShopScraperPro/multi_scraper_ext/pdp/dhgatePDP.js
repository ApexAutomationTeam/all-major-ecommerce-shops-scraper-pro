// ═══════════════════════════════════════════════════════════════════════
// pdp/dhgatePDP.js — DHgate product detail page enrichment
// ═══════════════════════════════════════════════════════════════════════
window.PDPRegistry = window.PDPRegistry || {};

window.PDPRegistry.dhgate = function extractDhgatePDP() {
  const H = window.ShopHelpers;
  const result = H.pdpMakeResult();
  const text = document.body.innerText || '';
  H.pdpParseLdJson(result);
  H.pdpScanLinks(result, ['/store/', '/stores/'], true);
  H.pdpParseJsonScripts(result, ['store'], 'dhgate');

  const desc = (document.querySelector('meta[name="description"]') || { getAttribute: () => '' }).getAttribute('content') || '';
  result.description = desc.substring(0, 200);

  if (!result.rating) { const rm = text.match(/([\d.]+)\s*(?:out of 5|★)/i); if (rm) result.rating = rm[1]; }
  const soldM = text.match(/(\d+)\s*Sold/i);
  if (soldM) result.sold = soldM[1] + ' sold';

  return result;
};
