// ═══════════════════════════════════════════════════════════════════════
// pdp/alibabaPDP.js — Alibaba product detail page enrichment
// ═══════════════════════════════════════════════════════════════════════
window.PDPRegistry = window.PDPRegistry || {};

window.PDPRegistry.alibaba = function extractAlibabaPDP() {
  const H = window.ShopHelpers;
  const result = H.pdpMakeResult();
  const text = document.body.innerText || '';
  H.pdpParseLdJson(result);
  // BUG FIX (live-verified — reported by user): pdpParseLdJson() reads the
  // schema.org Offer block, but on Alibaba that JSON-LD ALWAYS reports the
  // base/SEO price in USD (e.g. "USD 0.98") no matter what currency is
  // actually shown to the visitor — the real page displays a tiered price
  // table in the visitor's local currency (e.g. "PKR 213 / 1-499 pieces").
  // That USD schema price was overriding the correct localized price from
  // the PLP row during the deep-scrape merge. Discard it and read the
  // first (lowest-quantity) tier's visible current/original price instead.
  result.salePrice = '';
  result.origPrice = '';
  // BUG FIX (live-verified — reported by user): Alibaba shows MULTIPLE
  // quantity-based price tiers (e.g. "PKR 213 / 1-499 pieces", "PKR 206 /
  // 500-999 pieces", "PKR 200 / ≥1,000 pieces") and none of that tier
  // detail was being captured — only nothing at all previously. We read
  // EVERY `.price-item` block (not just the first) so all tiers make it
  // into the sheet. Sale Price / Original Price columns still hold just
  // the first (lowest-quantity, i.e. the "walk-in" retail) tier — exactly
  // what the page shows as its headline price — while the full tier table
  // is preserved in priceTiers for the Specifications column. Nothing is
  // converted or invented: every value here is copied verbatim from
  // whatever currency the page itself is displaying.
  // NOTE (live-verified): Alibaba renders the price-tier block TWICE in the
  // DOM (identical duplicate nodes, both visible per offsetParent) — dedupe
  // by the tier's own text so we don't double-list every quantity break.
  let priceTiers = [];
  const seenTierText = {};
  const priceItems = [...document.querySelectorAll('.module_price .price-item, [class*="price-item"]')];
  priceItems.forEach(item => {
    const raw = (item.textContent || '').trim();
    if (seenTierText[raw]) return;
    seenTierText[raw] = true;
    const priceCol = item.children[0];
    const qtyCol = item.children[1];
    const parts = priceCol ? [...priceCol.querySelectorAll('*')].filter(e => e.children.length === 0).map(e => (e.textContent || '').trim()).filter(Boolean) : [];
    const qty = qtyCol ? (qtyCol.textContent || '').trim() : '';
    if (!parts[0]) return;
    priceTiers.push(qty ? (qty + ': ' + parts[0] + (parts[1] && parts[1] !== parts[0] ? ' (was ' + parts[1] + ')' : '')) : parts[0]);
  });
  if (priceItems[0]) {
    const priceCol = priceItems[0].children[0];
    const parts = priceCol ? [...priceCol.querySelectorAll('*')].filter(e => e.children.length === 0).map(e => (e.textContent || '').trim()).filter(Boolean) : [];
    if (parts[0]) result.salePrice = parts[0];
    if (parts[1] && parts[1] !== parts[0]) result.origPrice = parts[1];
  }
  if (!result.salePrice) {
    const pm = text.match(/(?:PKR|US\$|\$|€)\s*[\d,.]+(?:\s*[-–]\s*[\d,.]+)?/);
    if (pm) result.salePrice = pm[0];
  }
  H.pdpScanLinks(result, ['company_profile', '/company/', '/supplier/'], true);
  H.pdpParseJsonScripts(result, ['company', 'supplier'], 'alibaba');
  // BUG FIX (live-verified — reported by user): the supplier's storefront
  // link on the PDP is usually a subdomain like
  // "https://<slug>.m.en.alibaba.com/" or "https://<slug>.en.alibaba.com/"
  // — it does NOT contain "company_profile"/"/company/"/"/supplier/" in
  // the path, so pdpScanLinks above missed it and left storeLink empty.
  // When that happens the deep-scrape merge fell back to the PLP row's
  // StoreLink, which (before its own fix) was just the product page URL —
  // so "Store Link" ended up reopening the PDP instead of the real store.
  // Find the anchor whose visible text is the actual company name instead.
  if (!result.storeLink) {
    const companyA = [...document.querySelectorAll('a[href*=".en.alibaba.com"]')].find(a => /(Co\.,?\s*Ltd\.?|Corporation|Trading Co|Factory|Manufacturer)\b/i.test((a.textContent || '').trim()) && (a.textContent || '').trim().length < 80);
    if (companyA) {
      result.storeName = result.storeName || (companyA.textContent || '').trim().substring(0, 60);
      H.pdpPickStoreLink(result, companyA.getAttribute('href'), result.storeName);
    }
  }

  const desc = (document.querySelector('meta[name="description"]') || { getAttribute: () => '' }).getAttribute('content') || '';
  result.description = desc.substring(0, 200);

  if (!result.rating) { const rm = text.match(/([\d.]+)\s*\/\s*5\.0/); if (rm) result.rating = rm[1]; }
  if (!result.reviews) { const revM = text.match(/\((\d+)\)/); if (revM) result.reviews = revM[1]; }
  const moqM = text.match(/Min\.\s*order:\s*([\d,]+\s*\w+)/i) || text.match(/(\d+)\s*(?:Pieces?|Units?)\s*\(Min/i);
  if (moqM) result.supplierInfo = ('MOQ: ' + moqM[0]).substring(0, 60);

  // BUG FIX (live-verified — reported by user): Specifications column was
  // always empty for Alibaba because this extractor never read the
  // "Key attributes" section (compatible brand / material / product type /
  // feature / design style / special craft, etc. — each label+value pair
  // sits in its own small block). Walk that section's text and pair up
  // consecutive short lines as label/value.
  const keyAttrHeader = [...document.querySelectorAll('h2,h3,div,span')].find(e => /^Key attributes$/i.test((e.textContent || '').trim()));
  if (keyAttrHeader) {
    const sec = keyAttrHeader.closest('section') || keyAttrHeader.parentElement;
    const lines = (sec ? sec.innerText : '').split('\n').map(l => l.trim()).filter(Boolean);
    const specs = [];
    for (let i = 1; i < lines.length - 1; i += 2) {
      if (specs.length >= 8) break;
      const label = lines[i], value = lines[i + 1];
      if (label && value && label.length < 30 && value.length < 60) specs.push(label + ': ' + value);
    }
    if (specs.length) result.specs = specs.join(' | ');
  }

  if (priceTiers.length > 1) {
    const tierNote = 'Price Tiers: ' + priceTiers.join(' | ');
    result.specs = result.specs ? (tierNote + ' || ' + result.specs) : tierNote;
  }

  return result;
};
