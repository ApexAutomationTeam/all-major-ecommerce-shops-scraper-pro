// ═══════════════════════════════════════════════════════════════════════
// pdp/amazonPDP.js — Amazon product detail page enrichment
// ═══════════════════════════════════════════════════════════════════════
window.PDPRegistry = window.PDPRegistry || {};

window.PDPRegistry.amazon = function extractAmazonPDP() {
  const H = window.ShopHelpers;
  const result = H.pdpMakeResult();
  const text = document.body.innerText || '';
  H.pdpParseLdJson(result);

  // BUG FIX (live-verified — reported by user): `document.querySelector(
  // '#bylineInfo, a[href*="/stores/"], ...')` does NOT try selectors in
  // the order written — a comma-separated selector list just matches
  // "any of these" and returns whichever match comes FIRST IN THE PAGE,
  // regardless of which selector matched it. Amazon often has a
  // completely unrelated sponsored-brand ad link earlier in the DOM than
  // the real "#bylineInfo" (verified live: a "Diamond Bakery" ad link
  // with no visible text sat before "#bylineInfo" on a mattress page,
  // so every product's Store Link came out as that random unrelated
  // brand). Fix: query #bylineInfo on its OWN first — it is always the
  // correct byline for the product actually being viewed — and only
  // fall back to a generic "/stores/" search if it's genuinely absent.
  const bylineEl = document.querySelector('#bylineInfo');
  if (bylineEl) {
    result.storeName = bylineEl.textContent.trim().replace(/^Visit the\s+/i, '').replace(/\s+Store$/i, '').substring(0, 40);
    H.pdpPickStoreLink(result, bylineEl.getAttribute('href'), result.storeName);
  }
  if (!result.storeLink) {
    const poBrand = document.querySelector('a.po-brand, a[href*="/sp?"]');
    if (poBrand) {
      result.storeName = result.storeName || poBrand.textContent.trim().substring(0, 40);
      H.pdpPickStoreLink(result, poBrand.getAttribute('href'), result.storeName);
    }
  }
  const sellerEl = document.querySelector('#sellerProfileTriggerId, #merchant-info a, a[href*="/gp/help/seller"]');
  if (sellerEl) {
    if (!result.storeName) result.storeName = sellerEl.textContent.trim().substring(0, 40);
    if (!result.storeLink) H.pdpPickStoreLink(result, sellerEl.getAttribute('href'), result.storeName);
  }
  // Last-resort fallback: any "/stores/" link, but ONLY one with real,
  // non-empty visible text — the bogus ad-carousel link that caused this
  // bug had empty text (it was an image-only tile), which is a reliable
  // tell that it isn't the product's own byline link.
  if (!result.storeLink) {
    document.querySelectorAll('a[href*="/stores/"], a[href*="seller="], a[href*="/s?me="]').forEach(a => {
      if (result.storeLink) return;
      const t = (a.textContent || '').trim();
      if (t.length < 3 || t.length > 60) return;
      if (/sign in|register|help|policy|cart|wishlist|download/i.test(t)) return;
      H.pdpPickStoreLink(result, a.getAttribute('href'), t);
    });
  }

  const acr = document.querySelector('[data-hook="rating-out-of-text"], #acrPopover');
  if (acr) {
    const m = (acr.textContent || acr.getAttribute('title') || '').match(/([\d.]+)\s+out of/i);
    if (m) result.rating = m[1];
  }
  const revEl = document.querySelector('#acrCustomerReviewText, [data-hook="total-review-count"]');
  if (revEl) result.reviews = (revEl.textContent || '').replace(/[^\d]/g, '');

  const bullets = [];
  document.querySelectorAll('#feature-bullets li span.a-list-item, #feature-bullets li').forEach(s => {
    const t = s.textContent.trim(); if (t.length > 5 && t.length < 200) bullets.push(t);
  });
  if (bullets.length) result.description = bullets.join(' | ');

  const specs = [];
  document.querySelectorAll('#productDetails_techSpec_section_1 tr, #prodDetails table tr, table.a-keyvalue tr, #productOverview_feature_div tr').forEach(tr => {
    const th = (tr.querySelector('th, td:first-child') || {}).textContent || '';
    const td = (tr.querySelector('td:last-child') || {}).textContent || '';
    if (th.trim() && td.trim() && th.trim() !== td.trim()) specs.push(th.trim() + ': ' + td.trim());
  });
  if (specs.length) result.specs = specs.slice(0, 10).join(' | ');

  return result;
};
