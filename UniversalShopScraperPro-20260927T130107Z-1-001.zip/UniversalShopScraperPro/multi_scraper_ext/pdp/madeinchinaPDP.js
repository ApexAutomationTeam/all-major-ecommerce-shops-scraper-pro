// ═══════════════════════════════════════════════════════════════════════
// pdp/madeinchinaPDP.js — Made-in-China product detail page enrichment
// ═══════════════════════════════════════════════════════════════════════
window.PDPRegistry = window.PDPRegistry || {};

window.PDPRegistry.madeinchina = function extractMadeInChinaPDP() {
  const H = window.ShopHelpers;
  const result = H.pdpMakeResult();

  const urlM = location.href.match(/\/\/([\w-]+)\.en\.made-in-china\.com/);
  if (urlM) { result.storeLink = 'https://' + urlM[1] + '.en.made-in-china.com/'; result.storeName = urlM[1]; }
  H.pdpScanLinks(result, ['.en.made-in-china.com', '/company/', '/supplier/'], true);

  const bodyText = document.body.innerText || '';
  // BUG FIX (live-verified — reported by user): the real company name
  // ("Shenzhen Tina Nis Electronics Co., Ltd.") is right there on the
  // page but was never used to replace the URL-slug-derived storeName
  // ("tinanis"). Prefer the actual company-name anchor when found.
  const companyA = [...document.querySelectorAll('a')].find(a => /(Co\.,?\s*Ltd\.?|Corporation|Trading Co|Factory|Manufacturer)\b/i.test((a.textContent || '').trim()) && (a.textContent || '').trim().length < 80);
  if (companyA) result.storeName = (companyA.textContent || '').trim().substring(0, 60);

  // BUG FIX (live-verified — reported by user): the PDP shows multiple
  // quantity-based price tiers (e.g. "US$7.60 / 50-199 Pieces", "US$7.20 /
  // 200-999 Pieces", "US$6.30 / 1,000+ Pieces") that weren't being
  // captured at all — salePrice/origPrice were left empty by this
  // extractor. Read every tier from the pricing swiper and use the first
  // (lowest-quantity) one as the headline Sale Price, exactly as shown on
  // the page — no currency conversion, nothing invented.
  let priceTierNote = '';
  const priceEls = [...document.querySelectorAll('*')].filter(e => e.children.length === 0 && /^US\$[\d,.]+$/.test((e.textContent || '').trim()));
  if (priceEls.length) {
    let scope = priceEls[0].parentElement;
    while (scope && !scope.contains(priceEls[priceEls.length - 1])) scope = scope.parentElement;
    const lines = (scope ? scope.innerText : '').split('\n').map(l => l.trim()).filter(Boolean);
    const tiers = [];
    for (let i = 0; i < lines.length - 1; i += 2) {
      if (/^US\$/.test(lines[i])) tiers.push(lines[i + 1] + ': ' + lines[i]);
    }
    if (tiers.length) {
      result.salePrice = priceEls[0].textContent.trim();
      // Kept in `specs` (not `description`) since the basic-info block
      // further below unconditionally overwrites `result.description` —
      // putting it there would just get wiped out.
      priceTierNote = 'Price Tiers: ' + tiers.join(' | ');
    }
  }

  // BUG FIX (live-verified — reported by user): the PRODUCT itself has no
  // rating/reviews on Made-in-China (that's normal — only the SUPPLIER
  // has a rating, e.g. "5.0 (58 Reviews)" next to the company name). Do
  // NOT put that into the product's own Rating/Reviews columns — those
  // should stay accurate/empty for the product. Instead record it in
  // Supplier Info, which is exactly the column meant for store-level data.
  const srM = bodyText.match(/([\d.]+)\s*\n?\s*\(([\d,]+)\s*Reviews?\)/i);
  if (srM) {
    result.supplierInfo = (result.storeName ? result.storeName + ' | ' : '') + 'Store Rating: ' + srM[1] + ' (' + srM[2] + ' Reviews)';
  }

  const specs = [];
  document.querySelectorAll('table tr').forEach(tr => {
    const cells = tr.querySelectorAll('td, th');
    if (cells.length >= 2) {
      const k = (cells[0].textContent || '').trim();
      const v = (cells[1].textContent || '').trim();
      if (k && v && k.length < 40 && v.length < 100 && k !== v) specs.push(k + ': ' + v);
    }
  });
  if (specs.length) result.specs = specs.slice(0, 10).join(' | ');
  if (priceTierNote) result.specs = result.specs ? (priceTierNote + ' || ' + result.specs) : priceTierNote;

  const basicInfo = [];
  document.querySelectorAll('li, dd, dt').forEach(el => {
    if (el.children.length > 1) return;
    const t = (el.innerText || '').trim();
    if (/^(Type|Material|Color|Feature|Compatible|Application|Weight|Size|Brand)\s*:/i.test(t) && t.length < 100) basicInfo.push(t);
  });
  if (basicInfo.length) result.description = basicInfo.slice(0, 8).join(' | ');
  else {
    const meta = document.querySelector('meta[name="description"]');
    result.description = meta ? (meta.getAttribute('content') || '').substring(0, 300) : '';
  }

  return result;
};
