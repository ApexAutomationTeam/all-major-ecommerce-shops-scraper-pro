// ═══════════════════════════════════════════════════════════════════════
// pdp/aliexpressPDP.js — AliExpress product detail page enrichment
// Live-verified (2026-07) DOM: the store block sits in an element whose
// class starts with "store-detail--wrap--" and contains an
// <a href="https://www.aliexpress.com/store/<id>"> with text like
// "Sold By\nShop<id> Store\n(Trader)". We match on the class *prefix*
// (via [class*=]) rather than the full hashed suffix so this keeps
// working even when AliExpress rotates its CSS module hash.
// ═══════════════════════════════════════════════════════════════════════
window.PDPRegistry = window.PDPRegistry || {};

window.PDPRegistry.aliexpress = function extractAliexpressPDP() {
  const H = window.ShopHelpers;
  const result = H.pdpMakeResult();
  const text = document.body.innerText || '';

  // Strategy 1 — dedicated store-detail block (most reliable, live-verified)
  const storeBlock = document.querySelector('[class*="store-detail--wrap"], [class*="store-info--wrap"], [class*="storeHeader"]');
  if (storeBlock) {
    const a = storeBlock.querySelector('a[href*="/store/"]') || (storeBlock.matches('a[href*="/store/"]') ? storeBlock : null);
    if (a) H.pdpPickStoreLink(result, a.getAttribute('href'), (a.textContent || '').replace(/\s+/g, ' ').trim());
  }

  // Strategy 2 — any /store/ link on the page
  if (!result.storeLink) H.pdpScanLinks(result, ['/store/', '/shop/', 'storeId=', 'seller.alibaba'], true);

  // Strategy 3 — JSON blobs embedded in inline <script> tags
  if (!result.storeLink) H.pdpParseJsonScripts(result, ['store', 'seller', 'shop'], 'aliexpress');

  // Strategy 4 — plain-text "Sold By ShopXXXXX Store" / "seller of this item
  // is ShopXXXXX Store" patterns.
  // BUG FIX (live-verified — reported by user): the old fallback regex
  // `/(?:Store|Official Store|Shop)\s*[:\n]?\s*([^\n|]{2,40})/i` had no word
  // boundary before "Shop", so on pages whose "Explanation of the Supplier"
  // text contains something like "5,000+ Shoppers bought this", it matched
  // mid-word inside "Shoppers" and captured garbage ("per ") as the store
  // name instead of the real "Shop1104962053 Store" a few lines above. Now
  // word-bounded, and a dedicated "seller of this item is" pattern is tried
  // first since that phrasing reliably contains the real shop ID.
  const sellerIsM = text.match(/seller of this item is\s*(Shop(\d+)\s*Store)/i);
  if (sellerIsM) {
    if (!result.storeName) result.storeName = sellerIsM[1].trim();
    if (!result.storeLink) result.storeLink = 'https://www.aliexpress.com/store/' + sellerIsM[2];
  }
  if (!result.storeName) {
    const nameM = text.match(/Sold\s*By\s*\n?\s*([^\n]{2,40})/i) || text.match(/\b(?:Store|Official Store|Shop)\b\s*[:\n]?\s*([^\n|]{2,40})/i);
    if (nameM) result.storeName = nameM[1].trim();
  }
  if (result.storeName) result.storeName = result.storeName.replace(/^Sold\s*By\s*/i, '').trim();

  const specTexts = [];
  document.querySelectorAll('[class*="specification"], [class*="property"], [class*="sku"] li, .product-prop-list li').forEach(el => {
    const t = (el.textContent || '').trim();
    if (t.length > 3 && t.length < 100) specTexts.push(t);
  });
  if (!specTexts.length) {
    text.split('\n').forEach(line => {
      const l = line.trim();
      if (/^(Material|Color|Size|Weight|Brand|Type|Style|Compatible|Feature)/i.test(l) && l.length < 80) specTexts.push(l);
    });
  }
  result.specs = specTexts.slice(0, 8).join(' | ');

  if (!result.rating) { const rm = text.match(/([\d.]+)\s*(?:\/\s*5|out of 5|★)/i); if (rm) result.rating = rm[1]; }
  const soldM = text.match(/([\d,.]+[KkMm+]*)\s*(?:sold|orders|pieces)/i);
  if (soldM) result.sold = soldM[1] + ' sold';
  if (!result.reviews) { const revM = text.match(/([\d,.]+)\s*(?:reviews?|Ratings?)/i); if (revM) result.reviews = revM[1].replace(/,/g, ''); }

  if (!result.salePrice) {
    // BUG FIX (live-verified — reported by user): `[class*="price"]`
    // is broad enough to also match a "deal ends in..." countdown/timer
    // banner (e.g. class "flash-deal-price-timer"), whose text is a
    // date/time like "Ends : Jul 8, 11:59 (GMT+5)" — that was getting
    // saved as the Sale Price. Check EVERY candidate in order and only
    // accept the first one whose text actually looks like a price
    // (currency symbol + digits) and does NOT look like a date/time.
    const candidates = document.querySelectorAll('[class*="price--current"], [class*="product-price-value"], [class*="price"]');
    for (let i = 0; i < candidates.length; i++) {
      const t = (candidates[i].textContent || '').trim().substring(0, 30);
      if (!t) continue;
      if (/Ends|GMT|\bAM\b|\bPM\b|Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec/i.test(t)) continue;
      if (!/(?:PKR|USD|US\$|Rs\.?|₹|€|£|¥|\$)\s*[\d,.]/i.test(t)) continue;
      result.salePrice = t;
      break;
    }
  }

  return result;
};
