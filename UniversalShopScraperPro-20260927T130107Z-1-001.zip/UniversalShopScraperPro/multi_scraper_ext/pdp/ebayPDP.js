// ═══════════════════════════════════════════════════════════════════════
// pdp/ebayPDP.js — eBay product detail page enrichment
// ═══════════════════════════════════════════════════════════════════════
window.PDPRegistry = window.PDPRegistry || {};

window.PDPRegistry.ebay = function extractEbayPDP() {
  const H = window.ShopHelpers;
  const result = H.pdpMakeResult();
  H.pdpParseLdJson(result);
  // BUG FIX (live-verified — reported by user): eBay's JSON-LD Product
  // schema has no `seller` field, so pdpParseLdJson()'s fallback grabbed
  // `brand.name` instead (e.g. "Apple", "Samsung" — the manufacturer, NOT
  // the actual eBay seller/store) and locked that in as storeName. Since
  // storeName was already non-empty, the real seller link found below by
  // pdpScanLinks couldn't correct the name (only fills empty storeName).
  // Discard the brand-derived storeName so the real seller info (from the
  // seller card, same reliable source the PLP scraper already uses) wins.
  result.storeName = '';
  H.pdpScanLinks(result, ['/str/', '/usr/'], true);
  // BUG FIX (live-verified — reported by user): use the SAME seller-card
  // "<name>\n(<count>)\n<pct>% positive" pattern the PLP scraper trusts,
  // and build the storeLink the same way ("https://www.ebay.com/usr/
  // <name>") for consistency — PLP's logic was already correct, PDP's
  // link-scanning fallback above is kept only as a backup.
  const sellerCardEl = document.querySelector('[class*="seller-card"], [class*="x-sellercard"], .x-sellercard-atf');
  if (sellerCardEl) {
    const sellerLinkA = [...sellerCardEl.querySelectorAll('a[href*="/str/"], a[href*="/usr/"]')].find(a => (a.textContent || '').trim().length > 1);
    if (sellerLinkA) {
      result.storeName = (sellerLinkA.textContent || '').trim().substring(0, 40);
      result.storeLink = H.absUrl(sellerLinkA.getAttribute('href') || '').split('#')[0] || result.storeLink;
    }
  }

  const desc = (document.querySelector('meta[name="description"]') || { getAttribute: () => '' }).getAttribute('content') || '';
  result.description = desc.substring(0, 200);

  const specs = [];
  document.querySelectorAll('[class*="ux-labels-values"], .ux-layout-section-evo__col, dl.ux-labels-values').forEach(el => {
    const l = (el.querySelector('[class*="label"], dt') || {}).textContent || '';
    const v = (el.querySelector('[class*="value"], dd') || {}).textContent || '';
    if (l && v) specs.push(l.trim() + ': ' + v.trim());
  });
  result.specs = specs.slice(0, 8).join(' | ');

  const retEl = document.querySelector('[data-testid*="return"], [class*="return"]');
  result.returns = retEl ? retEl.textContent.trim().substring(0, 80) : '';

  const sellerText = (document.querySelector('[class*="seller-card"], [class*="x-sellercard"], .x-sellercard-atf') || {}).innerText || '';
  const posM = sellerText.match(/([\d.]+)%\s*positive/i);
  result.supplierInfo = posM ? posM[1] + '% positive feedback' : '';

  if (!result.rating) { const rm = document.body.innerText.match(/([\d.]+)\s+out of 5 stars/i); if (rm) result.rating = rm[1]; }
  return result;
};
