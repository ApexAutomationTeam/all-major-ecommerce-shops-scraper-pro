// ═══════════════════════════════════════════════════════════════════════
// pdp/walmartPDP.js — Walmart product detail page enrichment
// ═══════════════════════════════════════════════════════════════════════
window.PDPRegistry = window.PDPRegistry || {};

window.PDPRegistry.walmart = function extractWalmartPDP() {
  const H = window.ShopHelpers;
  const result = H.pdpMakeResult();
  const text = document.body.innerText || '';
  H.pdpParseLdJson(result);
  // BUG FIX (live-verified — reported by user): '/cp/' is Walmart's generic
  // "content page" path — it also matches unrelated global-nav links like
  // "/cp/subscriptions/4191733", which sit earlier in the DOM than the
  // actual seller/brand link. pdpScanLinks took that first match and
  // locked in storeLink = the Subscriptions page, while storeName below
  // got silently overwritten with the correct "BENTOBEN Store" text — so
  // the sheet showed the right name next to a dead/wrong link. Dropped the
  // generic '/cp/' pattern; kept only patterns that are reliably
  // seller/brand-specific (confirmed live: "/global/seller/<id>" and
  // "/brand/<slug>/<id>").
  H.pdpScanLinks(result, ['/seller/', '/global/seller/', '/brand/', '/c/brand/'], true);
  // pdpScanLinks can pick up the anchor's full label ("Visit the BENTOBEN
  // Store") rather than the bare name — strip that wrapping so it matches
  // the cleaner "Sold by" text used as a fallback below.
  if (result.storeName) result.storeName = result.storeName.replace(/^Visit the\s+/i, '').trim();

  const sb = text.match(/Sold and shipped by\s*([^\n]+)/i) || text.match(/Sold by\s*([^\n]+)/i);
  // BUG FIX: only take the text-regex name if pdpScanLinks didn't already
  // find a name tied to the actual verified store link — otherwise this
  // unconditional overwrite is what made the Store column show the right
  // name while StoreLink still pointed at the wrong /cp/ page above.
  if (sb && !result.storeName) result.storeName = sb[1].substring(0, 30).trim();
  result.supplierInfo = result.storeName;

  const desc = (document.querySelector('meta[name="description"]') || { getAttribute: () => '' }).getAttribute('content') || '';
  result.description = desc.substring(0, 300);

  const rm = text.match(/([\d.]+)\s+out of 5 Stars?\.\s*([\d,]+)\s*reviews?/i);
  if (rm) { result.rating = rm[1]; result.reviews = rm[2].replace(/,/g, ''); }

  // BUG FIX (live-verified — reported by user): Specifications column was
  // empty — this extractor never read Walmart's "Key item features" bullet
  // list ("Compatibility: ...", "Material Quality: ...", etc.), so the
  // sheet's Specifications cell ended up falling back to showing the
  // product title placeholder instead. Each bullet is already a clean
  // "Label: Value" line — just collect them.
  const keyFeatHeader = [...document.querySelectorAll('h2,h3,div,span,button')].find(e => /^Key item features$/i.test((e.textContent || '').trim()));
  if (keyFeatHeader) {
    const sec = keyFeatHeader.closest('section') || keyFeatHeader.parentElement.parentElement;
    const lines = (sec ? sec.innerText : '').split('\n').map(l => l.trim()).filter(Boolean).filter(l => !/^Key item features$/i.test(l));
    const specs = lines.filter(l => /^[A-Z][\w\s/-]{2,30}:\s*.+/.test(l)).slice(0, 8);
    if (specs.length) result.specs = specs.join(' | ');
  }

  return result;
};
