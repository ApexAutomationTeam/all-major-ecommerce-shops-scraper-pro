// ═══════════════════════════════════════════════════════════════════════
// pdp/darazPDP.js — Daraz product detail page enrichment
// ═══════════════════════════════════════════════════════════════════════
window.PDPRegistry = window.PDPRegistry || {};

window.PDPRegistry.daraz = function extractDarazPDP() {
  const H = window.ShopHelpers;
  const result = H.pdpMakeResult();
  const text = document.body.innerText || '';
  H.pdpScanLinks(result, ['/shop/'], false);

  const sellerM = text.match(/Sold by\s*\n?\s*([^\n]{2,30})/i);
  if (sellerM) result.storeName = sellerM[1];

  const posM = text.match(/Positive Seller\s*\n?\s*Ratings\s*\n?\s*(\d+%)/i);
  const shipM = text.match(/Ship on Time\s*\n?\s*(\d+%)/i);
  result.supplierInfo = (posM ? posM[1] + ' positive' : '') + (shipM ? ' | ' + shipM[1] + ' on-time' : '');

  const pm = text.match(/Rs\.\s*([\d,]+)/);
  if (pm) result.salePrice = 'Rs. ' + pm[1];

  return result;
};
