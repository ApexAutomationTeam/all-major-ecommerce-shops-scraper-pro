// ═══════════════════════════════════════════════════════════════
// BACKGROUND.JS — PDP Enrichment via Hidden Background Tabs
// Multi-DOM fallbacks for all supported sites
// ═══════════════════════════════════════════════════════════════
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get('files', ({files}) => {
    if (!files) chrome.storage.local.set({files: []});
  });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'stopEnrichment') {
    _stopEnrichment = true;
    sendResponse({stopped: true});
    return true;
  }
  if (msg.type === 'enrichPDP') {
    enrichProducts(msg.products, msg.site).then(enriched => {
      sendResponse({enriched});
    }).catch(e => sendResponse({error: e.message}));
    return true;
  }
});

let _stopEnrichment = false;

function waitForTabComplete(tabId, timeoutMs) {
  return new Promise(resolve => {
    const start = Date.now();
    const poll = () => {
      chrome.tabs.get(tabId, tab => {
        if (chrome.runtime.lastError || !tab || tab.status === 'complete' || Date.now() - start > timeoutMs) {
          resolve();
        } else {
          setTimeout(poll, 400);
        }
      });
    };
    poll();
  });
}

const SITE_WAIT = {
  aliexpress: 5500,
  temu: 5000,
  '1688': 5000,
  alibaba: 4500,
  default: 3500
};

async function enrichProducts(products, site) {
  _stopEnrichment = false;
  const enriched = [];
  const DELAY = 1800;
  const MAX = Math.min(products.length, 15);
  const postWait = SITE_WAIT[site] || SITE_WAIT.default;

  for (let i = 0; i < MAX; i++) {
    if (_stopEnrichment) {
      for (let j = i; j < products.length; j++) enriched.push(products[j]);
      return enriched;
    }
    const p = products[i];
    const url = p.Link || '';
    if (!url || !url.startsWith('http')) { enriched.push(p); continue; }

    try {
      const tab = await chrome.tabs.create({url, active: false});
      await waitForTabComplete(tab.id, 15000);
      await new Promise(r => setTimeout(r, postWait));
      const results = await chrome.scripting.executeScript({
        target: {tabId: tab.id},
        func: extractPDP,
        args: [site]
      });
      const pdp = results[0]?.result || {};
      enriched.push({
        ...p,
        StoreLink: pdp.storeLink || p.StoreLink || '',
        Store: pdp.storeName || p.Store || '',
        Rating: pdp.rating || p.Rating || '',
        Reviews: pdp.reviews || p.Reviews || '',
        SalePrice: pdp.salePrice || p.SalePrice || '',
        OrigPrice: pdp.origPrice || p.OrigPrice || '',
        Sold: pdp.sold || p.Sold || '',
        Description: pdp.description || p.Description || '',
        Specifications: pdp.specs || p.Specifications || '',
        Return: pdp.returns || p.Return || '',
        SupplierInfo: pdp.supplierInfo || p.SupplierInfo || ''
      });
      await chrome.tabs.remove(tab.id);
    } catch (e) {
      enriched.push(p);
    }
    if (i < MAX - 1) await new Promise(r => setTimeout(r, DELAY));
  }
  for (let i = MAX; i < products.length; i++) enriched.push(products[i]);
  return enriched;
}

// ═══════════════════════════════════════════════════════════════
// PDP Extractor — injected into each product page
// ═══════════════════════════════════════════════════════════════
function extractPDP(site) {
  const result = {storeLink:'', storeName:'', description:'', specs:'', returns:'', supplierInfo:'', rating:'', reviews:'', salePrice:'', origPrice:'', sold:''};
  const text = document.body.innerText || '';
  const origin = location.origin;

  function absUrl(h) {
    if (!h) return '';
    if (h.startsWith('//')) return 'https:' + h;
    if (h.startsWith('/')) return origin + h;
    return h;
  }

  function pickStoreLink(href, name) {
    if (!href) return;
    const link = absUrl(href).split(/[?#]/)[0];
    if (!link || link === location.href.split(/[?#]/)[0]) return;
    if (!result.storeLink) result.storeLink = link;
    if (name && !result.storeName) result.storeName = name.substring(0, 40);
  }

  function scanLinks(patterns, nameFilter) {
    document.querySelectorAll('a[href]').forEach(a => {
      if (result.storeLink && result.storeName) return;
      const h = a.getAttribute('href') || '';
      const t = (a.textContent || '').trim();
      if (!patterns.some(p => h.includes(p))) return;
      if (nameFilter && (t.length < 2 || t.length > 45)) return;
      if (/sign in|register|help|policy|cart|wishlist|download/i.test(t)) return;
      pickStoreLink(h, t);
    });
  }

  function parseJsonScripts(keys) {
    document.querySelectorAll('script:not([src])').forEach(s => {
      const txt = s.textContent || '';
      if (!keys.some(k => txt.includes(k))) return;
      keys.forEach(key => {
        const nameM = txt.match(new RegExp('"' + key + 'Name"\\s*:\\s*"([^"]+)"'));
        const idM = txt.match(new RegExp('"' + key + 'Id"\\s*:\\s*"?([\\d]+)"?'));
        if (nameM && !result.storeName) result.storeName = nameM[1].substring(0, 40);
        if (idM && !result.storeLink && site === 'aliexpress') result.storeLink = 'https://www.aliexpress.com/store/' + idM[1];
        if (idM && !result.storeLink && site === 'dhgate') result.storeLink = 'https://www.dhgate.com/store/' + idM[1];
      });
      const storeM = txt.match(/"storeName"\s*:\s*"([^"]+)"/);
      const storeIdM = txt.match(/"storeId"\s*:\s*"?(\d+)"?/);
      if (storeM && !result.storeName) result.storeName = storeM[1].substring(0, 40);
      if (storeIdM && !result.storeLink && site === 'aliexpress') result.storeLink = 'https://www.aliexpress.com/store/' + storeIdM[1];
    });
  }

  function parseLdJson() {
    document.querySelectorAll('script[type="application/ld+json"]').forEach(jld => {
      try {
        const d = JSON.parse(jld.textContent);
        const items = Array.isArray(d) ? d : [d];
        items.forEach(item => {
          const brand = item.brand?.name || item.brand;
          const seller = item.seller?.name || item.offers?.seller?.name;
          if (seller && !result.storeName) result.storeName = seller.substring(0, 40);
          if (brand && !result.storeName) result.storeName = brand.substring(0, 40);
          const ar = item.aggregateRating || {};
          if (ar.ratingValue && !result.rating) result.rating = String(ar.ratingValue);
          if (ar.reviewCount && !result.reviews) result.reviews = String(ar.reviewCount);
          const offer = item.offers || {};
          if (offer.price && !result.salePrice) {
            const curr = offer.priceCurrency || '';
            result.salePrice = curr && offer.price ? curr + ' ' + offer.price : offer.price;
          }
        });
      } catch (e) {}
    });
  }

  parseLdJson();

  // ── AMAZON ──
  if (site === 'amazon') {
    const brandEl = document.querySelector('#bylineInfo, a[href*="/stores/"], a.po-brand, a[href*="/sp?"]');
    if (brandEl) {
      result.storeName = brandEl.textContent.trim().replace(/^Visit the\s+/i,'').replace(/\s+Store$/i,'').substring(0,40);
      pickStoreLink(brandEl.getAttribute('href'), result.storeName);
    }
    const sellerEl = document.querySelector('#sellerProfileTriggerId, #merchant-info a, a[href*="/gp/help/seller"]');
    if (sellerEl) {
      if (!result.storeName) result.storeName = sellerEl.textContent.trim().substring(0, 40);
      if (!result.storeLink) pickStoreLink(sellerEl.getAttribute('href'), result.storeName);
    }
    scanLinks(['/stores/', '/sp?', 'seller=', '/s?me='], true);
    const acr = document.querySelector('[data-hook="rating-out-of-text"], #acrPopover');
    if (acr) {
      const m = (acr.textContent || acr.getAttribute('title') || '').match(/([\d.]+)\s+out of/i);
      if (m) result.rating = m[1];
    }
    const revEl = document.querySelector('#acrCustomerReviewText, [data-hook="total-review-count"]');
    if (revEl) result.reviews = (revEl.textContent || '').replace(/[^\d]/g, '');
    const bullets = [];
    document.querySelectorAll('#feature-bullets li span.a-list-item, #feature-bullets li').forEach(s => {
      const t = s.textContent.trim(); if (t.length > 5 && t.length < 200) bullets.push(t);
    });
    if (bullets.length) result.description = bullets.join(' | ');
    const specs = [];
    document.querySelectorAll('#productDetails_techSpec_section_1 tr, #prodDetails table tr, table.a-keyvalue tr, #productOverview_feature_div tr').forEach(tr => {
      const th = (tr.querySelector('th, td:first-child') || {}).textContent || '';
      const td = (tr.querySelector('td:last-child') || {}).textContent || '';
      if (th.trim() && td.trim() && th.trim() !== td.trim()) specs.push(th.trim() + ': ' + td.trim());
    });
    if (specs.length) result.specs = specs.slice(0, 10).join(' | ');
  }

  // ── EBAY ──
  if (site === 'ebay') {
    scanLinks(['/str/', '/usr/'], true);
    const desc = (document.querySelector('meta[name="description"]') || {getAttribute:()=>''}).getAttribute('content') || '';
    result.description = desc.substring(0, 200);
    const specs = [];
    document.querySelectorAll('[class*="ux-labels-values"], .ux-layout-section-evo__col, dl.ux-labels-values').forEach(el => {
      const l = (el.querySelector('[class*="label"], dt') || {}).textContent || '';
      const v = (el.querySelector('[class*="value"], dd') || {}).textContent || '';
      if (l && v) specs.push(l.trim() + ': ' + v.trim());
    });
    result.specs = specs.slice(0, 8).join(' | ');
    const retEl = document.querySelector('[data-testid*="return"], [class*="return"]');
    result.returns = retEl ? retEl.textContent.trim().substring(0, 80) : '';
    const sellerText = (document.querySelector('[class*="seller-card"], [class*="x-sellercard"], .x-sellercard-atf') || {}).innerText || '';
    const posM = sellerText.match(/([\d.]+)%\s*positive/i);
    result.supplierInfo = posM ? posM[1] + '% positive feedback' : '';
  }

  // ── WALMART ──
  if (site === 'walmart') {
    scanLinks(['/seller/', '/cp/', '/brand/', '/c/brand/'], true);
    const sb = text.match(/Sold and shipped by\s*([^\n]+)/i) || text.match(/Sold by\s*([^\n]+)/i);
    result.storeName = sb ? sb[1].substring(0, 30).trim() : result.storeName;
    result.supplierInfo = result.storeName;
    const desc = (document.querySelector('meta[name="description"]') || {getAttribute:()=>''}).getAttribute('content') || '';
    result.description = desc.substring(0, 300);
    const rm = text.match(/([\d.]+)\s+out of 5 Stars?\.\s*([\d,]+)\s*reviews?/i);
    if (rm) { result.rating = rm[1]; result.reviews = rm[2].replace(/,/g, ''); }
  }

  // ── ETSY ──
  if (site === 'etsy') {
    scanLinks(['/shop/'], true);
    if (!result.storeName) {
      const shopM = text.match(/(?:From shop|Sold by)\s+([^\n]{2,30})/i);
      if (shopM) result.storeName = shopM[1].trim();
    }
    const desc = (document.querySelector('meta[name="description"]') || {getAttribute:()=>''}).getAttribute('content') || '';
    result.description = desc.substring(0, 200);
    const rm = text.match(/([\d.]+)\s*(?:out of 5|\(|\s)/);
    if (rm) result.rating = rm[1];
    const revM = text.match(/\(([\d,.]+)\)/);
    if (revM) result.reviews = revM[1].replace(/,/g, '');
  }

  // ── ALIEXPRESS ──
  if (site === 'aliexpress') {
    scanLinks(['/store/', '/shop/', 'storeId=', 'seller.alibaba'], true);
    parseJsonScripts(['store', 'seller', 'shop']);
    if (!result.storeName) {
      const nameM = text.match(/(?:Store|Official Store|Shop)\s*[:\n]?\s*([^\n|]{2,40})/i);
      if (nameM) result.storeName = nameM[1].trim();
    }
    const specTexts = [];
    document.querySelectorAll('[class*="specification"], [class*="property"], [class*="sku"] li, .product-prop-list li').forEach(el => {
      const t = (el.textContent || '').trim();
      if (t.length > 3 && t.length < 100) specTexts.push(t);
    });
    if (!specTexts.length) {
      text.split('\n').forEach(line => {
        const l = line.trim();
        if (/^(Material|Color|Size|Weight|Brand|Type|Style|Compatible|Feature)/i.test(l) && l.length < 80) specTexts.push(l);
      });
    }
    result.specs = specTexts.slice(0, 8).join(' | ');
    const rm = text.match(/([\d.]+)\s*(?:\/\s*5|out of 5|★)/i);
    if (rm) result.rating = rm[1];
    const soldM = text.match(/([\d,.]+[KkMm+]*)\s*(?:sold|orders|pieces)/i);
    if (soldM) result.sold = soldM[1] + ' sold';
    const revM = text.match(/([\d,.]+)\s*(?:reviews?|Ratings?)/i);
    if (revM) result.reviews = revM[1].replace(/,/g, '');
    const priceEl = document.querySelector('[class*="price--current"], [class*="product-price-value"], [class*="price"]');
    if (priceEl) result.salePrice = (priceEl.textContent || '').trim().substring(0, 30);
  }

  // ── TEMU ──
  if (site === 'temu') {
    scanLinks(['mall', '/m-'], true);
    const soldBy = text.match(/Sold by\s+([^\n]+)/i);
    if (soldBy && !result.storeName) result.storeName = soldBy[1].substring(0, 25);
    const brandM = text.match(/Brand\s*[:\n]\s*(\S+)/i);
    result.specs = brandM ? 'Brand: ' + brandM[1] : '';
  }

  // ── ALIBABA ──
  if (site === 'alibaba') {
    scanLinks(['company_profile', '/company/', '/supplier/'], true);
    parseJsonScripts(['company', 'supplier']);
    const desc = (document.querySelector('meta[name="description"]') || {getAttribute:()=>''}).getAttribute('content') || '';
    result.description = desc.substring(0, 200);
    const rm = text.match(/([\d.]+)\s*\/\s*5\.0/);
    if (rm) result.rating = rm[1];
  }

  // ── DHGATE ──
  if (site === 'dhgate') {
    scanLinks(['/store/', '/stores/'], true);
    parseJsonScripts(['store']);
    const desc = (document.querySelector('meta[name="description"]') || {getAttribute:()=>''}).getAttribute('content') || '';
    result.description = desc.substring(0, 200);
  }

  // ── DARAZ ──
  if (site === 'daraz') {
    scanLinks(['/shop/'], false);
    const sellerM = text.match(/Sold by\s*\n?\s*([^\n]{2,30})/i);
    result.storeName = sellerM ? sellerM[1] : result.storeName;
    const posM = text.match(/Positive Seller\s*\n?\s*Ratings\s*\n?\s*(\d+%)/i);
    const shipM = text.match(/Ship on Time\s*\n?\s*(\d+%)/i);
    result.supplierInfo = (posM ? posM[1] + ' positive' : '') + (shipM ? ' | ' + shipM[1] + ' on-time' : '');
  }

  // ── MADE-IN-CHINA ──
  if (site === 'madeinchina') {
    const urlM = location.href.match(/\/\/([\w-]+)\.en\.made-in-china\.com/);
    if (urlM) {
      result.storeLink = 'https://' + urlM[1] + '.en.made-in-china.com/';
      result.storeName = urlM[1];
    }
    scanLinks(['.en.made-in-china.com', '/company/', '/supplier/'], true);
    const specs = [];
    document.querySelectorAll('table tr').forEach(tr => {
      const cells = tr.querySelectorAll('td, th');
      if (cells.length >= 2) {
        const k = (cells[0].textContent || '').trim();
        const v = (cells[1].textContent || '').trim();
        if (k && v && k.length < 40 && v.length < 100 && k !== v) specs.push(k + ': ' + v);
      }
    });
    if (specs.length) result.specs = specs.slice(0, 10).join(' | ');
    const basicInfo = [];
    document.querySelectorAll('li, dd, dt').forEach(el => {
      if (el.children.length > 1) return;
      const t = (el.innerText || '').trim();
      if (/^(Type|Material|Color|Feature|Compatible|Application|Weight|Size|Brand)\s*:/i.test(t) && t.length < 100) basicInfo.push(t);
    });
    if (basicInfo.length) result.description = basicInfo.slice(0, 8).join(' | ');
    else {
      const meta = document.querySelector('meta[name="description"]');
      result.description = meta ? meta.getAttribute('content').substring(0, 300) : '';
    }
  }

  // ── 1688 ──
  if (site === '1688') {
    document.querySelectorAll('a[href]').forEach(a => {
      if (result.storeLink) return;
      const h = a.getAttribute('href') || '';
      const sub = h.match(/(?:https?:)?\/\/([a-z0-9]+)\.1688\.com/i);
      const skip = ['detail','s','login','m','air','img','i','gw','offer','cbu01','cbuce01','pub','help','page','trade'];
      if (sub && !skip.includes(sub[1])) {
        result.storeLink = 'https://' + sub[1] + '.1688.com';
        result.storeName = (a.textContent || '').trim().substring(0, 25);
      }
    });
  }

  return result;
}
