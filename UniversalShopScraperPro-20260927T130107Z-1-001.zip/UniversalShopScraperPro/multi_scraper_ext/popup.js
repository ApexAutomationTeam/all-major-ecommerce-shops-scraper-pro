// ═══════════════════════════════════════════════════════════════════════
// UNIVERSAL SHOP SCRAPER PRO v2.5 — ALL SITES + PDP ENRICHMENT
// ALL selectors LIVE-VERIFIED on real sites
// PDP data fetched in BACKGROUND (no visible tab opening)
// ═══════════════════════════════════════════════════════════════════════
const $=id=>document.getElementById(id);
let selectedSite='auto';
const COLORS={amazon:'#FF9900',ebay:'#E53238',walmart:'#0071DC',etsy:'#F1641E',aliexpress:'#FF4747',alibaba:'#FF6A00',temu:'#FB7701',daraz:'#F85606',dhgate:'#FF6600',madeinchina:'#D4380D','1688':'#FF4400',unknown:'#6B7280'};

function detectSite(u){if(!u)return'unknown';if(u.includes('amazon.'))return'amazon';if(u.includes('ebay.'))return'ebay';if(u.includes('walmart.'))return'walmart';if(u.includes('etsy.'))return'etsy';if(u.includes('aliexpress.'))return'aliexpress';if(u.includes('alibaba.'))return'alibaba';if(u.includes('temu.'))return'temu';if(u.includes('daraz.'))return'daraz';if(u.includes('dhgate.'))return'dhgate';if(u.includes('made-in-china.'))return'madeinchina';if(u.includes('1688.'))return'1688';return'unknown';}
function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function nmVal(v){return parseFloat(String(v).replace(/[^0-9.]/g,''))||0;}
function analyzeProduct(r){
  const MIN=5;
  const pros=[],cons=[],flags=[];
  const rat=nmVal(r.Rating),rev=nmVal(String(r.Reviews).replace(/[Kk]/,'000').replace(/[Mm]/,'000000')),price=nmVal(r.SalePrice);
  if(rat>=4.8)pros.push('Exceptional '+r.Rating+'★');else if(rat>=4.6)pros.push('Excellent '+r.Rating+'★');
  else if(rat>=4.4)pros.push('Strong '+r.Rating+'★');else if(rat>=4.0)pros.push('Solid '+r.Rating+'★');
  else if(rat>=3.5)cons.push('Mixed '+r.Rating+'★');else if(rat>0){cons.push('Weak '+r.Rating+'★');flags.push('⚠️ Below 3.5★');}
  else if(r.Rating&&r.Rating!=='N/A')flags.push('⚠️ No rating');else if(!r.Rating)flags.push('⚠️ No rating');
  if(rev>=10000)pros.push('Massive '+r.Reviews+' reviews');else if(rev>=1000)pros.push(r.Reviews+' reviews');
  else if(rev>=200)pros.push('Healthy '+r.Reviews+' reviews');else if(rev>=50)cons.push('Modest '+r.Reviews+' reviews');
  else if(rev>0){cons.push('Only '+r.Reviews+' reviews');flags.push('⚠️ <50 reviews');}
  else if(r.Reviews&&r.Reviews!=='N/A')flags.push('⚠️ No reviews');
  if(price>=500)cons.push('High price');else if(price>=100)pros.push('Mid-range');else if(price>=20)pros.push('Accessible price');
  else if(price>=MIN){cons.push('Very cheap');flags.push('⚠️ Suspiciously low');}
  if(/free.?(?:ship|deliv|envío|gratis|包邮)/i.test((r.DelCost||'')+(r.Delivery||'')))pros.push('Free shipping');
  if(/renewed|refurb/i.test(r.Item||'')){cons.push('Refurbished');flags.push('⚠️ Not new');}
  if(/deluxe|premium|collector/i.test(r.Item||''))pros.push('Premium edition');
  if(/best seller|más vendido|top rated|best.selling|endorsed/i.test((r.Item||'')+(r.Badge||'')))pros.push('Best Seller');
  var origP=nmVal(r.OrigPrice);if(origP>0&&price>0&&origP>price){var disc=Math.round((1-price/origP)*100);r.Discount=disc+'% off';if(disc>=50)pros.push(disc+'% discount');else if(disc>=20)pros.push(disc+'% off');}
  var soldN=nmVal(String(r.Sold).replace(/[Kk]/,'000').replace(/[Mm]/,'000000'));
  if(soldN>=10000)pros.push('Massive sales ('+r.Sold+')');else if(soldN>=1000)pros.push('Strong sales');else if(soldN>=100)pros.push(r.Sold+' sold');
  var sc=0;if(rat>=4.4)sc+=3;else if(rat>=4.0)sc+=2;else if(rat>=3.5)sc+=1;
  if(rev>=1000)sc+=3;else if(rev>=200)sc+=2;else if(rev>=50)sc+=1;if(soldN>=1000)sc+=1;
  if(price<MIN*3&&rev<50)sc-=1;
  r.Rec=sc>=6?'✅ TOP PICK':sc>=4?'👍 RECOMMENDED':sc>=2?'🤔 ACCEPTABLE':'❌ SKIP';
  r.Pros=pros.join(' • ')||'—';r.Cons=cons.join(' • ')||'—';r.Flags=flags.join(' • ')||'None';
  if(!r.Discount)r.Discount='—';if(!r.Setup)r.Setup='N/A';if(!r.Condition)r.Condition='New';
  if(!r.MOQ)r.MOQ='—';if(!r.SupplierInfo)r.SupplierInfo='—';if(!r.Description)r.Description='—';if(!r.Specifications)r.Specifications='—';
  if(!r.StoreLink)r.StoreLink='—';if(!r.Store)r.Store='—';
  if(!r.Rating)r.Rating='—';if(!r.Reviews||r.Reviews==='N/A')r.Reviews=r.Reviews==='N/A'?'N/A':'—';
  return r;
}
function upP(p,m){$('progress-bar').style.width=p+'%';$('progress-bar').textContent=p>0?p+'%':'';$('status').textContent=m;}
function resetB(){$('btn-start').style.display='block';$('btn-deep').style.display='block';$('btn-stop').style.display='none';}

// ── Tags ───────────────────────────────────────────────────────────────
document.querySelectorAll('.tag').forEach(t=>{t.addEventListener('click',()=>{document.querySelectorAll('.tag').forEach(x=>x.classList.remove('active'));t.classList.add('active');selectedSite=t.dataset.site;});});

// ── File management ────────────────────────────────────────────────────
async function loadFiles(){
  const{files=[]}=await chrome.storage.local.get('files');const list=$('file-list');list.innerHTML='';
  if(!files.length){list.innerHTML='<div class="empty-state">No files yet</div>';}
  else{files.forEach((f,i)=>{const c=COLORS[f.site]||'#6B7280';const d=document.createElement('div');d.className='file-item';d.innerHTML=`<input type="checkbox" class="file-checkbox" data-idx="${i}"><div class="file-info"><div class="file-name">${esc(f.name)}</div><div class="file-meta"><span class="file-site-badge" style="background:${c}">${(f.site||'').toUpperCase()}</span>${f.count} products</div></div>`;list.appendChild(d);});}
  $('file-count').textContent=files.length;$('total-files').textContent=files.length;
  $('total-products').textContent=files.reduce((s,f)=>s+(f.count||0),0);upSel();
}
function upSel(){const ch=document.querySelectorAll('.file-checkbox:checked');$('selected-count').textContent=ch.length;$('btn-combine').disabled=ch.length<2;$('btn-delete').disabled=ch.length===0;document.querySelectorAll('.file-item').forEach(x=>{const cb=x.querySelector('.file-checkbox');x.classList.toggle('selected',cb&&cb.checked);});}

// ── SCRAPE HANDLER (Quick or Deep) ─────────────────────────────────────
async function startScrape(deep){
  const[tab]=await chrome.tabs.query({active:true,currentWindow:true});
  const site=selectedSite==='auto'?detectSite(tab.url):selectedSite;
  if(site==='unknown'){$('status').textContent='❌ Not supported';return;}
  $('detected-site').style.display='block';$('detected-site').textContent='🌐 '+site.toUpperCase()+(deep?' (Deep)':' (Quick)');$('detected-site').style.color=COLORS[site];
  $('btn-start').style.display='none';$('btn-deep').style.display='none';$('btn-stop').style.display='block';
  upP(10,'Scraping PLP...');
  try{
    // Step 1: PLP scrape
    const res=await chrome.scripting.executeScript({target:{tabId:tab.id},func:SCRAPER,args:[site]});
    const data=res[0].result;
    if(!data||!data.rows||!data.rows.length){$('status').textContent='⚠️ No products. Scroll page first.';resetB();return;}
    upP(40,data.rows.length+' products found');

    let finalRows=data.rows;

    // Step 2: PDP enrichment (Deep Scrape only)
    if(deep){
      upP(45,'Deep scrape: enriching from PDPs...');
      // Send to background for PDP enrichment
      try{
        const enrichRes=await chrome.runtime.sendMessage({type:'enrichPDP',products:data.rows,site:site});
        if(enrichRes&&enrichRes.enriched){finalRows=enrichRes.enriched.map(analyzeProduct);upP(85,finalRows.length+' enriched');}
      }catch(e){upP(70,'PDP enrichment partial: '+e.message);}
    }

    // Step 3: Save + download
    upP(90,'Generating XLSX...');
    const{files=[]}=await chrome.storage.local.get('files');
    const fn=`${site}_${data.kw}_${Date.now()}.xls`;
    const fe={name:fn,count:finalRows.length,timestamp:Date.now(),rows:finalRows,site,keyword:data.kw};
    files.push(fe);await chrome.storage.local.set({files});
    const x=buildXLSX([fe],site);const b=new Blob(['\uFEFF'+x],{type:'application/vnd.ms-excel'});
    const u=URL.createObjectURL(b);
    await chrome.downloads.download({url:u,filename:`ShopScraperPro/${fn}`,saveAs:false});
    setTimeout(()=>URL.revokeObjectURL(u),3000);
    upP(100,`✅ ${finalRows.length} from ${site.toUpperCase()}`+(deep?' (enriched)':''));
    await loadFiles();
    // FIXED: reset progress bar after 3 seconds
    setTimeout(()=>{upP(0,'Ready — open any supported store search page');},3000);
  }catch(e){$('status').textContent='❌ '+e.message;}
  finally{setTimeout(resetB,1500);}
}

$('btn-start').addEventListener('click',()=>startScrape(false));
$('btn-deep').addEventListener('click',()=>startScrape(true));
$('btn-stop').addEventListener('click',async()=>{
  try{await chrome.runtime.sendMessage({type:'stopEnrichment'});}catch(e){}
  $('status').textContent='⏹ Stopped — saving partial data...';
});
$('select-all').addEventListener('change',e=>{document.querySelectorAll('.file-checkbox').forEach(cb=>cb.checked=e.target.checked);upSel();});
$('file-list').addEventListener('change',e=>{if(e.target.classList.contains('file-checkbox'))upSel();});

// ── Combine ────────────────────────────────────────────────────────────
$('btn-combine').addEventListener('click',async()=>{
  const ch=[...document.querySelectorAll('.file-checkbox:checked')];if(ch.length<2)return;
  const{files=[]}=await chrome.storage.local.get('files');
  const sel=ch.map(c=>files[parseInt(c.dataset.idx)]);const tot=sel.reduce((s,f)=>s+f.rows.length,0);
  upP(50,`Combining ${sel.length} files...`);
  const x=buildXLSX(sel,'combined',true);const b=new Blob(['\uFEFF'+x],{type:'application/vnd.ms-excel'});
  const u=URL.createObjectURL(b);
  await chrome.downloads.download({url:u,filename:`ShopScraperPro/COMBINED_${sel.length}files_${tot}prod.xls`,saveAs:true});
  setTimeout(()=>URL.revokeObjectURL(u),3000);
  upP(100,`✅ Combined ${tot} products`);setTimeout(()=>upP(0,'Ready'),2000);
});
$('btn-delete').addEventListener('click',async()=>{
  const ch=[...document.querySelectorAll('.file-checkbox:checked')];if(!ch.length||!confirm('Delete?'))return;
  const idxs=ch.map(c=>parseInt(c.dataset.idx)).sort((a,b)=>b-a);const{files=[]}=await chrome.storage.local.get('files');
  idxs.forEach(i=>files.splice(i,1));await chrome.storage.local.set({files});$('select-all').checked=false;await loadFiles();
});
$('btn-clear').addEventListener('click',async()=>{if(!confirm('Clear ALL?'))return;await chrome.storage.local.set({files:[]});$('select-all').checked=false;await loadFiles();});

// ═══════════════════════════════════════════════════════════════════════
// XLSX BUILDER — stacked combine, colorful, all columns
// ═══════════════════════════════════════════════════════════════════════
function buildXLSX(entries,site,combo=false){
  const e=s=>esc(s);
  const H=['#','Item Name','Store/Vendor','Store Link','Product Link','Sale Price','Original Price','Discount','Delivery Cost','Setup Cost','Est. Delivery','Return Policy','Rating','Reviews','Sold','Condition','Badge','MOQ','Supplier Info','Description','Specifications','Pros','Cons','Red Flags','Recommendation'];
  const css=`body{margin:0;font-family:Arial}table{border-collapse:collapse;font-family:Arial;font-size:9pt;width:100%}td,th{border:1px solid #bbb;padding:5px;vertical-align:top;max-width:300px;word-wrap:break-word}th{background:#1F4E79;color:#fff;font-weight:bold;text-align:center}.mh{background:#1E1B4B;color:#fff;font-size:14pt;font-weight:bold;text-align:center;padding:12px}.fh{background:#8B0000;color:#FFD700;font-size:11pt;font-weight:bold;text-align:center;padding:10px;border-top:3px solid #FFD700}.fs{background:#4A148C;color:#fff;font-size:9pt;font-weight:bold;text-align:center;padding:4px}.g{background:#E8F5E9}.y{background:#FFFDE7}.r{background:#FFEBEE}.b{background:#E3F2FD}.rec{font-weight:bold}.flag{color:#B71C1C;font-weight:600}.pros{color:#1B5E20}.cons{color:#7B241C}a{color:#1155CC;text-decoration:none}`;
  function rw(r,n){
    const cl=(r.Rec||'').startsWith('✅')?'g':(r.Rec||'').startsWith('❌')?'r':(r.Rec||'').startsWith('👍')?'b':'y';
    return `<tr class="${cl}"><td>${n}</td><td><b>${e(r.Item)}</b></td><td>${e(r.Store)}</td><td>${r.StoreLink&&r.StoreLink!=='—'?`<a href="${e(r.StoreLink)}">${e(r.Store!=='—'?r.Store:'View Store')}</a>`:'—'}</td><td>${r.Link?`<a href="${e(r.Link)}">View</a>`:'—'}</td><td><b>${e(r.SalePrice)}</b></td><td>${e(r.OrigPrice)}</td><td>${e(r.Discount)}</td><td>${e(r.DelCost)}</td><td>${e(r.Setup)}</td><td>${e(r.Delivery)}</td><td>${e(r.Return)}</td><td><b>${e(r.Rating)}</b></td><td>${e(r.Reviews)}</td><td>${e(r.Sold)}</td><td>${e(r.Condition)}</td><td>${e(r.Badge)}</td><td>${e(r.MOQ)}</td><td>${e(r.SupplierInfo)}</td><td>${e(r.Description)}</td><td>${e(r.Specifications)}</td><td class="pros">${e(r.Pros)}</td><td class="cons">${e(r.Cons)}</td><td class="flag">${e(r.Flags)}</td><td class="rec">${e(r.Rec)}</td></tr>`;
  }
  let html=`<html xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="UTF-8"><style>${css}</style></head><body><table>`;
  if(!combo){const f=entries[0];html+=`<tr><td class="mh" colspan="${H.length}">🔍 ${(f.site||'').toUpperCase()} — "${e(f.keyword)}"</td></tr><tr>${H.map(h=>'<th>'+h+'</th>').join('')}</tr>`;f.rows.forEach((r,i)=>{html+=rw(r,i+1);});}
  else{const tot=entries.reduce((s,f)=>s+f.rows.length,0);html+=`<tr><td class="mh" colspan="${H.length}">🔍 COMBINED — ${entries.length} FILES → ${tot} PRODUCTS</td></tr>`;let off=0;entries.forEach((f,idx)=>{html+=`<tr><td class="fh" colspan="${H.length}">📁 FILE ${idx+1}: ${e(f.name)} — ${(f.site||'').toUpperCase()} — ${f.rows.length} products</td></tr><tr><td class="fs" colspan="${H.length}">Search: "${e(f.keyword)}"</td></tr><tr>${H.map(h=>'<th>'+h+'</th>').join('')}</tr>`;f.rows.forEach((r,i)=>{html+=rw(r,off+i+1);});off+=f.rows.length;});}
  html+='</table></body></html>';return html;
}

// ═══════════════════════════════════════════════════════════════════════
// PLP SCRAPER — injected into page (ALL SITES LIVE-VERIFIED)
// ═══════════════════════════════════════════════════════════════════════
function SCRAPER(site){
  const MIN=5;
  const nm=v=>parseFloat(String(v).replace(/[^0-9.]/g,''))||0;
  const origin=location.origin;
  const absUrl=h=>{if(!h)return'';if(h.startsWith('//'))return'https:'+h;if(h.startsWith('/'))return origin+h;return h;};
  const itemId=u=>(String(u).match(/\/item\/(\d+)/i)||String(u).match(/\/(\d{10,})\.html/i)||[])[1]||'';
  const findCard=(el,depth)=>{let n=el;for(let i=0;i<(depth||8)&&n.parentElement;i++){n=n.parentElement;const c=typeof n.className==='string'?n.className:'';if(/card|product|item|gallery|list--|search|offer|manhattan|feed/i.test(c)&&n.querySelector('img'))return n;}return el.closest('[class*="card"],[class*="product"],[class*="item"],[class*="gallery"],[class*="list--"]')||el.parentElement||el;};
  const firstPrice=t=>{const m=(t||'').match(/(?:PKR|USD|US\$|Rs\.?|₹|€|£|\$)\s*[\d,.]+(?:\s*[-–]\s*(?:PKR|USD|US\$|Rs\.?|₹|€|£|\$)?\s*[\d,.]+)?/g);return m||[];};
  const parseRatingReviews=t=>{
    let rating='',reviews='';
    const ariaM=(t||'').match(/([\d.]+)\s*(?:out of|\/)\s*5/i);
    if(ariaM)rating=ariaM[1];
    const starM=(t||'').match(/\b([1-5](?:\.\d)?)\s*(?:★|stars?|star)\b/i);
    if(!rating&&starM)rating=starM[1];
    const revM=(t||'').match(/([\d,.]+[KkMm]?)\s*(?:reviews?|ratings?|feedback)/i);
    if(revM)reviews=revM[1].replace(/,/g,'');
    if(!reviews){const pM=(t||'').match(/\(([\d,.]+[KkMm]?)\)/);if(pM&&!/sold|bought|orders/i.test(t))reviews=pM[1].replace(/,/g,'');}
    return{rating,reviews};
  };
  const parseSold=t=>{const m=(t||'').match(/([\d,.]+[KkMm+]*\+?\s*(?:sold|bought|orders|purchased))/i);return m?m[1]:'';};

  function analyze(r){
    const pros=[],cons=[],flags=[];
    const rat=nm(r.Rating),rev=nm(String(r.Reviews).replace(/[Kk]/,'000').replace(/[Mm]/,'000000')),price=nm(r.SalePrice);
    if(rat>=4.8)pros.push('Exceptional '+r.Rating+'★');else if(rat>=4.6)pros.push('Excellent '+r.Rating+'★');
    else if(rat>=4.4)pros.push('Strong '+r.Rating+'★');else if(rat>=4.0)pros.push('Solid '+r.Rating+'★');
    else if(rat>=3.5)cons.push('Mixed '+r.Rating+'★');else if(rat>0){cons.push('Weak '+r.Rating+'★');flags.push('⚠️ Below 3.5★');}
    else flags.push('⚠️ No rating');
    if(rev>=10000)pros.push('Massive '+r.Reviews+' reviews');else if(rev>=1000)pros.push(r.Reviews+' reviews');
    else if(rev>=200)pros.push('Healthy '+r.Reviews+' reviews');else if(rev>=50)cons.push('Modest '+r.Reviews+' reviews');
    else if(rev>0){cons.push('Only '+r.Reviews+' reviews');flags.push('⚠️ <50 reviews');}
    else flags.push('⚠️ No reviews');
    if(price>=500)cons.push('High price');else if(price>=100)pros.push('Mid-range');else if(price>=20)pros.push('Accessible price');
    else if(price>=MIN){cons.push('Very cheap');flags.push('⚠️ Suspiciously low');}
    if(/free.?(?:ship|deliv|envío|gratis|包邮)/i.test((r.DelCost||'')+(r.Delivery||'')))pros.push('Free shipping');
    if(/renewed|refurb/i.test(r.Item||'')){cons.push('Refurbished');flags.push('⚠️ Not new');}
    if(/deluxe|premium|collector/i.test(r.Item||''))pros.push('Premium edition');
    if(/best seller|más vendido|top rated|best.selling|endorsed/i.test((r.Item||'')+(r.Badge||'')))pros.push('Best Seller');
    var origP=nm(r.OrigPrice);if(origP>0&&price>0&&origP>price){var disc=Math.round((1-price/origP)*100);r.Discount=disc+'% off';if(disc>=50)pros.push(disc+'% discount');else if(disc>=20)pros.push(disc+'% off');}
    var soldN=nm(String(r.Sold).replace(/[Kk]/,'000').replace(/[Mm]/,'000000'));
    if(soldN>=10000)pros.push('Massive sales ('+r.Sold+')');else if(soldN>=1000)pros.push('Strong sales');else if(soldN>=100)pros.push(r.Sold+' sold');
    var sc=0;if(rat>=4.4)sc+=3;else if(rat>=4.0)sc+=2;else if(rat>=3.5)sc+=1;
    if(rev>=1000)sc+=3;else if(rev>=200)sc+=2;else if(rev>=50)sc+=1;if(soldN>=1000)sc+=1;
    if(price<MIN*3&&rev<50)sc-=1;
    r.Rec=sc>=6?'✅ TOP PICK':sc>=4?'👍 RECOMMENDED':sc>=2?'🤔 ACCEPTABLE':'❌ SKIP';
    r.Pros=pros.join(' • ')||'—';r.Cons=cons.join(' • ')||'—';r.Flags=flags.join(' • ')||'None';
    if(!r.Discount)r.Discount='—';if(!r.Setup)r.Setup='N/A';if(!r.Condition)r.Condition='New';
    if(!r.MOQ)r.MOQ='—';if(!r.SupplierInfo)r.SupplierInfo='—';if(!r.Description)r.Description='—';if(!r.Specifications)r.Specifications='—';
    return r;
  }

  const host=location.hostname;
  const EX={
    // ═══ TEMU — JSON-LD + DOM (VERIFIED: 40 products, rating, reviews, sold, original price) ═══
    temu(){
      const rows=[],seen={};
      const jld=document.querySelector('script[type="application/ld+json"]');
      let jItems=[];
      if(jld){try{const d=JSON.parse(jld.textContent);if(d.itemListElement)jItems=d.itemListElement;}catch(e){}}
      // DOM extras map (sold count, original price, badges from rendered cards)
      const dom={};
      document.querySelectorAll('h2').forEach(h2=>{
        const c=h2.closest('div')||h2.parentElement;if(!c)return;
        const t=(h2.innerText||'').trim().substring(0,50);
        const txt=c.innerText||'';
        const sold=(txt.match(/([\d,.]+[KkMm+]*)\s*(?:\|?\s*)?sold/i)||[])[1]||'';
        const orig=(txt.match(/Original price\s*\S*\s*([\d,]+)/i)||[])[1]||'';
        const badge=(txt.match(/(Best-Selling|Top pick|Top Rated|Summer Deals?|Star seller|Last \d+ days?|ONLY \d+ LEFT)/i)||[])[1]||'';
        dom[t]={sold,orig,badge};
      });
      if(jItems.length){
        jItems.forEach(item=>{
          const url=item.url||'';if(seen[url])return;seen[url]=true;
          const p=item.offers||{};const ar=item.aggregateRating||{};
          const title=(item.name||'').trim();
          const dk=title.substring(0,50);const d=dom[dk]||{};
          const curr=p.priceCurrency||'';const priceVal=p.price||'';
          const sp=curr&&priceVal?curr+' '+priceVal:priceVal;
          const op=d.orig?(curr+' '+d.orig):'';
          rows.push({Item:title,Store:'',StoreLink:'',Link:url,SalePrice:sp,OrigPrice:op,Discount:'',DelCost:'Free shipping',Setup:'',Delivery:'',Return:'',Rating:String(ar.ratingValue||''),Reviews:String(ar.reviewCount||''),Sold:d.sold||'',Condition:'',Badge:d.badge||'',MOQ:'',SupplierInfo:'',Description:'',Specifications:''});
        });
      }
      return rows;
    },

    // ═══ EBAY — su-* selectors (VERIFIED: 69 products, condition, seller) ═══
    // BUG FIX: Sold column was empty — now extracting from multiple patterns
    ebay(){
      const rows=[],seen={};
      document.querySelectorAll('[class*="s-item"]').forEach(x=>{
        const lk=x.querySelector('a.su-link, a[href*="/itm/"]');if(!lk)return;
        const url=lk.href||'';const id=(url.match(/\/itm\/(\d+)/)||[])[1]||'';
        if(!id||seen[id])return;
        const te=x.querySelector('a.su-link span.su-styled-text')||x.querySelector('.s-item__title span')||x.querySelector('.s-item__title');
        const title=te?(te.innerText||'').trim():'';
        if(!title||title.length<5||/^Shop on eBay$/i.test(title))return;
        const pe=x.querySelector('.su-item-card__price-container .su-styled-text')||x.querySelector('.s-item__price');
        const price=pe?(pe.innerText||'').trim().split('\n')[0]:'';if(!price)return;
        seen[id]=true;
        const cardText=x.innerText||'';
        const lines=cardText.split('\n').map(l=>l.trim());
        // Condition
        const cond=(cardText.match(/^(Brand New|Pre-Owned|Open Box|New \(Other\)|Used|Refurbished|New)$/im)||[])[1]||'';
        // Seller = "username X.X% positive (feedback)" pattern
        const sellerM=cardText.match(/([a-z_][\w.-]{2,30})\s+([\d.]+)%\s+positive\s+\(([\d.,KkMm]+)\)/i);
        const sellerName=sellerM?sellerM[1]:'';
        const sellerFeedback=sellerM?sellerM[2]+'% positive ('+sellerM[3]+')':'';
        const storeLink=sellerName?'https://www.ebay.com/usr/'+encodeURIComponent(sellerName):'';
        // Original price — second $X.XX line in card
        let origP='';lines.forEach(l=>{const m=l.match(/^\$([\d,.]+)$/);if(m&&'$'+m[1]!==price&&!origP)origP='$'+m[1];});
        // Sold count from text
        let sold='';const soldM2=cardText.match(/(\d[\d,]*)\s+sold/i);if(soldM2)sold=soldM2[1]+' sold';
        // Delivery cost
        let delCost='';const delM=cardText.match(/\+\$([\d.]+)\s*delivery/i);if(delM)delCost='+$'+delM[1];
        if(/Free.*Shipping|Free.*delivery/i.test(cardText))delCost='FREE';
        // Buy format
        const buyFmt=(cardText.match(/(Buy It Now|Auction|Best Offer)/i)||[])[1]||'';
        rows.push({Item:title,Store:sellerName,StoreLink:storeLink,Link:url,SalePrice:price,OrigPrice:origP,Discount:'',DelCost:delCost,Setup:'',Delivery:'',Return:'',Rating:'',Reviews:'',Sold:sold,Condition:cond,Badge:buyFmt,MOQ:'',SupplierInfo:sellerFeedback,Description:'',Specifications:''});
      });
      return rows;
    },

    // ═══ AMAZON — data-asin + multi-DOM fallbacks ═══
    amazon(){
      const rows=[],seen={};
      const cards=[...document.querySelectorAll('div[data-asin][data-component-type="s-search-result"]')];
      if(!cards.length)document.querySelectorAll('[data-asin]').forEach(x=>{if((x.getAttribute('data-asin')||'').length===10)cards.push(x);});
      cards.forEach(x=>{
        const id=x.getAttribute('data-asin');if(!id||id.length!==10||seen[id])return;
        const title=Array.from(x.querySelectorAll('h2 span,a h2 span,[class*="title"] span')).map(s=>s.innerText.trim()).filter(t=>t.length>1).join(' ');
        if(!title||title.length<5)return;
        const pe=x.querySelector('.a-price .a-offscreen,[class*="price"] .a-offscreen,span.a-price-whole');
        let price=pe?pe.innerText.trim():'';
        if(!price){const pm=(x.innerText||'').match(/\$[\d,.]+/);price=pm?pm[0]:'';}
        if(!price||nm(price)<MIN)return;seen[id]=true;
        let store='',storeLink='';
        const storeA=x.querySelector('a[href*="/stores/"],a[href*="/sp?"],a[href*="seller="],a[href*="/s?me="]');
        if(storeA){storeLink=absUrl(storeA.getAttribute('href')||'').split('?')[0];store=(storeA.innerText||'').trim().substring(0,40);}
        if(!store){x.querySelectorAll('span.a-size-base.a-color-secondary,span.a-color-secondary').forEach(sp=>{const bt=(sp.innerText||'').trim();const byM=bt.match(/^by\s+(.+)/i);if(byM&&!store)store=byM[1].substring(0,40);});}
        if(!store){const visit=x.querySelector('a[href*="/stores/"]');if(visit)store=(visit.innerText||'').replace(/^Visit the\s+/i,'').replace(/\s+Store$/i,'').substring(0,40);}
        let rating='';const st=x.querySelector('[aria-label*="out of 5"],[aria-label*="de 5"],[aria-label*="von 5"],i[class*="a-star"]');
        if(st){const m=(st.getAttribute('aria-label')||st.parentElement?.getAttribute('aria-label')||'').match(/([\d.]+)\s+(?:out of 5|de 5|von 5)/);if(m)rating=m[1];}
        let reviews='';
        const rl=x.querySelector('a[aria-label*="ratings"],a[aria-label*="valoraciones"],a[aria-label*="Bewertungen"],span[aria-label*="ratings"]');
        if(rl){const m=(rl.getAttribute('aria-label')||'').match(/([\d,.]+)\s+(?:ratings|valoraciones|Bewertungen)/i);if(m)reviews=m[1].replace(/,/g,'');}
        if(!reviews){const rb=x.querySelector('.a-row.a-size-small,[class*="rating"]');if(rb){const links=rb.querySelectorAll('a,span');for(let i=0;i<links.length;i++){const t=(links[i].innerText||'').trim();if(/^\([\d,.]+[KkMm]?\)$/.test(t)&&!/bought|sold/i.test(rb.innerText)){reviews=t.replace(/[()]/g,'');break;}}}}
        let origP='';const origEl=x.querySelector('.a-price[data-a-strike="true"] .a-offscreen,.a-text-price .a-offscreen,[data-a-strike="true"] .a-offscreen');if(origEl)origP=origEl.innerText.trim();
        let delivery='',delCost='';const dEl=x.querySelector('[data-cy="delivery-recipe"],[class*="delivery"]');
        if(dEl){const dt=dEl.innerText;const dm=dt.match(/((?:Mon|Tue|Wed|Thu|Fri|Sat|Sun|Tomorrow|mañana|lun|mar|mié|jue|vie)[^\n]{0,25}\d+|(?:Jun|Jul|Aug|jun|jul|ago)\w*\s+\d+(?:\s*-\s*\d+)?)/i);if(dm)delivery=dm[1].trim();if(/gratis|free/i.test(dt))delCost='FREE';}
        const badge=((x.querySelector('.a-badge-text,[class*="badge"]')||{}).innerText||'').trim();
        let sold='';x.querySelectorAll('.a-size-base,.a-color-secondary,span').forEach(sp=>{const t=(sp.innerText||'').trim();if(/bought|purchased|verkauft/i.test(t)&&!/rating|review/i.test(t)&&!sold)sold=t.substring(0,35);});
        const link='https://'+host+'/dp/'+id;
        rows.push({Item:title,Store:store,StoreLink:storeLink||'',Link:link,SalePrice:price,OrigPrice:origP,Discount:'',DelCost:delCost,Setup:'',Delivery:delivery,Return:'',Rating:rating||'',Reviews:reviews||'',Sold:sold||'',Condition:'',Badge:badge,MOQ:'',SupplierInfo:'',Description:'',Specifications:''});
      });
      return rows;
    },

    // ═══ ALIEXPRESS — multi-DOM + link-based fallbacks (2024-2026 layouts) ═══
    aliexpress(){
      const rows=[],seen={};
      function pushRow(card,url,title){
        const id=itemId(url);if(!id||seen[id])return false;
        const text=(card.innerText||'').trim();if(text.length<10)return false;
        const prices=firstPrice(text);
        const salePrice=prices[0]||'';
        let origPrice=prices[1]||'';
        if(origPrice&&nm(origPrice)<=nm(salePrice))origPrice='';
        const rr=parseRatingReviews(text);
        let rating=rr.rating,sold=parseSold(text),reviews=rr.reviews;
        const ratSoldM=text.match(/(\d\.?\d?)\s*[|·]\s*([\d,.]+[KkMm+]*)\s*(?:sold|orders)/i);
        if(ratSoldM){rating=rating||ratSoldM[1];sold=sold||(ratSoldM[2]+' sold');}
        if(!sold){const sm=text.match(/([\d,.]+[KkMm+]*)\s*(?:sold|orders)/i);if(sm)sold=sm[1]+' sold';}
        if(!rating){const rm=text.match(/\b([1-5](?:\.\d)?)\b/);if(rm&&parseFloat(rm[1])<=5)rating=rm[1];}
        const discM=text.match(/-(\d+)%/);const discount=discM?discM[1]+'% off':'';
        const shipM=text.match(/(Free shipping[^|\n]*|Save\s+\S+)/i);const ship=shipM?shipM[0].substring(0,30):'';
        let store='',storeLink='';
        const storeA=card.querySelector('a[href*="/store/"],a[href*="/shop/"],a[href*="storeId"]');
        if(storeA){storeLink=absUrl(storeA.getAttribute('href')||'').split('?')[0];store=(storeA.innerText||'').trim().substring(0,40);}
        if(!store){const storeM=text.match(/(?:Store|Shop)\s*[:\n]?\s*([^\n|]{2,35})/i);if(storeM)store=storeM[1].trim();}
        if(!salePrice&&!sold&&!rating&&!store)return false;
        seen[id]=true;
        rows.push({Item:title.substring(0,200),Store:store,StoreLink:storeLink,Link:absUrl(url).split('?')[0],SalePrice:salePrice,OrigPrice:origPrice,Discount:discount||'',DelCost:/free/i.test(ship)?'FREE':ship,Setup:'',Delivery:'',Return:'',Rating:rating||'',Reviews:reviews||'',Sold:sold||'',Condition:'',Badge:'',MOQ:'',SupplierInfo:'',Description:'',Specifications:''});
        return true;
      }
      // Scope to main product grid (many AliExpress layout variants)
      const gridSels=['[class*="SearchProductFeed"]','[class*="search-item-card"]','[class*="search-card"]','[class*="list--gallery"]','[class*="manhattan"]','[class*="product-list"]','[class*="search-root"]','[class*="items-list"]','main','#root'];
      let scope=document.body;
      for(let i=0;i<gridSels.length;i++){const el=document.querySelector(gridSels[i]);if(el&&el.querySelectorAll('a[href*="/item/"]').length>=2){scope=el;break;}}
      // Strategy A: product links inside card containers
      scope.querySelectorAll('a[href*="/item/"]').forEach(a=>{
        const url=a.href||a.getAttribute('href')||'';if(!url||seen[itemId(url)])return;
        const card=findCard(a,10);
        let title=(a.getAttribute('title')||'').trim();
        if(!title){const te=card.querySelector('h1,h2,h3,[class*="title"],[class*="Title"]');title=te?((te.getAttribute('title')||te.innerText||'').trim()):'';}
        if(!title)title=(a.innerText||'').trim().split('\n').map(l=>l.trim()).filter(l=>l.length>8)[0]||'';
        if(!title||title.length<5||/aliexpress|download|sign in|register/i.test(title))return;
        pushRow(card,url,title);
      });
      // Strategy B: legacy search-card / card-out-wrapper
      if(!rows.length){
        document.querySelectorAll('[class*="search-card"],[class*="card-out-wrapper"],[class*="list--item"],a.search-card-item').forEach(card=>{
          const h3=card.querySelector('h3,h2,[class*="title"]');if(!h3)return;
          const title=(h3.getAttribute('title')||h3.innerText||'').trim();if(!title||title.length<5)return;
          const linkA=h3.closest('a')||card.querySelector('a[href*="/item/"]');const url=linkA?(linkA.href||linkA.getAttribute('href')||''):'';
          if(!url)return;pushRow(card,url,title);
        });
      }
      // Strategy C: JSON-LD ItemList
      if(!rows.length){
        document.querySelectorAll('script[type="application/ld+json"]').forEach(jld=>{
          try{
            const d=JSON.parse(jld.textContent);
            const list=d.itemListElement||d['@graph']?.filter(x=>x['@type']==='ListItem')||[];
            (Array.isArray(list)?list:[]).forEach(li=>{
              const item=li.item||li;const url=item.url||item['@id']||'';if(!url||seen[itemId(url)])return;
              pushRow(document.body,url,item.name||'');
            });
          }catch(e){}
        });
      }
      // Strategy D: any /item/ link with image sibling (last resort)
      if(!rows.length){
        document.querySelectorAll('a[href*="/item/"]').forEach(a=>{
          const url=a.href||'';if(!url||seen[itemId(url)])return;
          const card=findCard(a,6);if(!card.querySelector('img'))return;
          const title=(a.getAttribute('title')||a.innerText||'').trim().split('\n')[0];
          if(title.length<5)return;pushRow(card,url,title);
        });
      }
      return rows;
    },

    // ═══ WALMART — data-item-id (VERIFIED: rating, reviews, badge, bought count) ═══
    // BUG FIX: Best seller tag + price parsing fixed
    walmart(){
      const rows=[],seen={};
      document.querySelectorAll('[data-item-id]').forEach(card=>{
        const id=card.getAttribute('data-item-id');if(!id||seen[id])return;
        let title='';const ts=card.querySelector('[data-automation-id="product-title"]');
        if(ts)title=ts.innerText.trim();
        if(!title){const btn=card.querySelector('button[data-automation-id="add-to-cart"]');if(btn){const m=(btn.getAttribute('aria-label')||'').match(/Add to cart - (.+)/i);if(m)title=m[1];}}
        if(!title)return;
        // Price — FIX: extract "current price $XX.XX" properly
        const pt=card.querySelector('[data-automation-id="product-price"]');
        const priceText=pt?pt.innerText:'';
        // FIXED: only use "current price $X.XX" pattern — Walmart also has unformatted $1399 which broke fallback
        const pm=priceText.match(/current price \$([\d.]+)/i);
        const price=pm?'$'+pm[1]:'';if(!price)return;seen[id]=true;
        // Original price — only from "Was $X.XX" pattern
        const origMatch=priceText.match(/Was \$([\d.]+)/i);
        const origPrice=origMatch?'$'+origMatch[1]:'';
        // Rating + Reviews — FIX: proper regex
        const cardText=card.innerText;
        const rm=cardText.match(/([\d.]+)\s+out of 5 Stars?\.\s*([\d,]+)\s*reviews?/i);
        const rating=rm?rm[1]:'';const reviews=rm?rm[2].replace(/,/g,''):'';
        // Badge — FIX: now capturing Best seller + other badges
        const bg=card.querySelector('[data-testid="badgeTagComponent"]');
        const badge=bg?(bg.innerText||'').trim():'';
        // Delivery
        const dm=cardText.match(/(Shipping arrives[^\n]+|Free delivery[^\n]+|Arrives [^\n]+)/i);
        const delivery=dm?dm[0].substring(0,50):'';
        // Sold/popularity — FIX: "50+ bought since yesterday"
        const sm=cardText.match(/([\d+]+\+?\s*bought\s+[^\n]+)/i);
        const sold=sm?sm[0].substring(0,35):'';
        // Link
        const lk=card.querySelector('a[href*="/ip/"]');const url=lk?lk.href:'';
        let storeLink='',store='';
        const sellerA=card.querySelector('a[href*="/seller/"]');
        if(sellerA){storeLink=absUrl(sellerA.getAttribute('href')||'').split('?')[0];store=(sellerA.innerText||'').trim().substring(0,30);}
        rows.push({Item:title,Store:store,StoreLink:storeLink,Link:url,SalePrice:price,OrigPrice:origPrice,Discount:'',DelCost:delivery.toLowerCase().includes('free')?'FREE':'',Setup:'',Delivery:delivery,Return:'',Rating:rating||'',Reviews:reviews||'',Sold:sold||'',Condition:'',Badge:badge,MOQ:'',SupplierInfo:'',Description:'',Specifications:''});
      });
      return rows;
    },

    // ═══ ETSY — JSON-LD + v2-listing-card (VERIFIED: shop name, price, brand) ═══
    etsy(){
      const rows=[],seen={};
      document.querySelectorAll('script[type="application/ld+json"]').forEach(jld=>{
        try{const d=JSON.parse(jld.textContent);if(!d.itemListElement)return;
        d.itemListElement.forEach(li=>{
          const item=li.item;if(!item||item['@type']!=='Product')return;
          const url=item.url||'';if(seen[url])return;seen[url]=true;
          const p=item.offers||{};const brand=(item.brand||{}).name||'Etsy Shop';
          const curr=p.priceCurrency||'';const priceVal=p.price||p.lowPrice||'';
          const salePrice=curr&&priceVal?curr+' '+priceVal:priceVal;
          rows.push({Item:item.name||'',Store:brand,StoreLink:'',Link:url,SalePrice:salePrice,OrigPrice:'',Discount:'',DelCost:'',Setup:'',Delivery:'',Return:'',Rating:'',Reviews:'',Sold:'',Condition:'',Badge:'',MOQ:'',SupplierInfo:brand,Description:'',Specifications:''});
        });}catch(e){}
      });
      if(!rows.length){
        document.querySelectorAll('.v2-listing-card').forEach(c=>{
          const lk=c.querySelector('a[href*="/listing/"]');const url=lk?lk.href:'';
          if(!url||seen[url])return;seen[url]=true;
          const te=c.querySelector('h3,[class*="title"],a[aria-label]');
          const title=te?(te.getAttribute('aria-label')||te.innerText||'').trim():'';if(!title)return;
          const pm=c.innerText.match(/(PKR|USD|\$|€|£)\s*[\d,.]+/i);const price=pm?pm[0]:'';
          rows.push({Item:title,Store:'',StoreLink:'',Link:url,SalePrice:price,OrigPrice:'',Discount:'',DelCost:'',Setup:'',Delivery:'',Return:'',Rating:'',Reviews:'',Sold:'',Condition:'',Badge:'',MOQ:'',SupplierInfo:'',Description:'',Specifications:''});
        });
      }
      return rows;
    },

    // ═══ ALIBABA — h2 cards (VERIFIED: rating, reviews, MOQ, supplier years, company) ═══
    // BUG FIX: MOQ now separate column, supplier years in SupplierInfo, Sold NOT mixed
    alibaba(){
      const rows=[],seen={};
      document.querySelectorAll('h2').forEach(h2=>{
        const title=(h2.innerText||'').trim();if(!title||title.length<5||seen[title])return;
        let card=h2;for(let j=0;j<8;j++){if(!card.parentElement)break;const p=card.parentElement;if(p.querySelectorAll('h2').length>1)break;card=p;}
        const text=card.innerText;
        const lk=card.querySelector('a[href*="alibaba.com/product"]');const url=lk?lk.href:'';
        if(!url)return;seen[title]=true;
        // Price
        const pm=text.match(/(?:PKR|US\$|\$|€)\s*[\d,.]+(?:\s*[-–]\s*(?:PKR|US\$|\$|€)?\s*[\d,.]+)?/);
        const price=pm?pm[0]:'Inquiry';
        // MOQ — BUG FIX: now extracted properly into its own field
        const moqM=text.match(/Min\.\s*order:\s*([\d,]+\s*\w+)/i)||text.match(/(\d+)\s*(?:Pieces?|Units?)\s*\(Min/i);
        const moq=moqM?moqM[0].substring(0,25):'—';
        // Rating — separate from years
        const ratM=text.match(/([\d.]+)\s*\/\s*5\.0/);const rating=ratM?ratM[1]:'';
        // Reviews count — from (XX) pattern
        const revM=text.match(/\((\d+)\)/);const reviews=revM?revM[1]:'';
        // Supplier years — BUG FIX: now in SupplierInfo, NOT in Sold
        const yrsM=text.match(/(\d+)\s*yrs?/i);const yrs=yrsM?yrsM[0]+' on Alibaba':'';
        // Company name
        const compM=text.match(/([A-Z][\w\s]+(?:Co\.|Ltd|Inc|Trading|Factory|Technology)[^|]{0,30})/);
        const company=compM?compM[0].trim().substring(0,40):'Alibaba Supplier';
        // Country
        const cnM=text.match(/\b(CN|IN|TR|VN|TW|TH)\b/);const country=cnM?cnM[1]:'';
        // Verified
        const verified=/verified/i.test(text);
        rows.push({Item:title,Store:company,StoreLink:url,Link:url,SalePrice:price,OrigPrice:'',Discount:'',DelCost:'',Setup:'',Delivery:'',Return:'',Rating:rating||'',Reviews:reviews||'',Sold:'N/A',Condition:'',Badge:verified?'Verified Supplier':'',MOQ:moq,SupplierInfo:yrs+(country?' | '+country:'')+(verified?' | Verified':''),Description:'',Specifications:''});
      });
      return rows;
    },

    // ═══ DARAZ — JSON-LD + DOM (VERIFIED: Product type, prices) ═══
    daraz(){
      const rows=[],seen={};
      // FIXED: DOM extraction — JSON-LD has no prices on Daraz
      document.querySelectorAll('[data-qa-locator*="product"]').forEach(card=>{
        const lk=card.querySelector('a[href*="/products/"]');const url=lk?lk.href:'';
        if(!url||seen[url])return;
        const text=card.innerText||'';
        const lines=text.split('\n').map(l=>l.trim()).filter(Boolean);
        let title='';for(let i=0;i<lines.length;i++){if(lines[i].length>10&&!lines[i].startsWith('Rs.')){title=lines[i];break;}}
        if(!title||title.length<5||seen[title])return;seen[title]=true;seen[url]=true;
        const pm=text.match(/Rs\.\s*([\d,]+)/);const price=pm?'Rs. '+pm[1]:'';
        const discM=text.match(/(\d+)%\s*Off/i);const disc=discM?discM[1]+'% Off':'';
        const soldM=text.match(/([\d,.]+[KkMm]*)\s*sold/i);const sold=soldM?soldM[1]+' sold':'';
        const revM=text.match(/\((\d[\d,]*)\)/);const reviews=revM?revM[1]:'';
        const locM=text.match(/(Sindh|Punjab|Islamabad|KPK|Balochistan)/i);const loc=locM?locM[0]:'';
        rows.push({Item:title.substring(0,80),Store:'',StoreLink:url,Link:url,SalePrice:price,OrigPrice:'',Discount:disc,DelCost:'',Setup:'',Delivery:'',Return:'',Rating:'N/A',Reviews:reviews||'',Sold:sold||'',Condition:'',Badge:'',MOQ:'',SupplierInfo:loc,Description:'',Specifications:''});
      });
      return rows;
    },

    // ═══ DHGATE — gallery-main (VERIFIED: price, sold, rating, endorsed badge) ═══
    dhgate(){
      const rows=[],seen={};
      document.querySelectorAll('.gallery-main, [class*="gallery-main"]').forEach(card=>{
        const text=card.innerText;if(text.length<30)return;
        const lk=card.querySelector('a[href*="dhgate.com/product"]');
        const url=lk?lk.href:'';if(!url||seen[url])return;seen[url]=true;
        const lines=text.split('\n').map(l=>l.trim()).filter(l=>l.length>5);
        let title='';for(const l of lines){if(l.length>20&&!/^(US\s*\$|Free|Endorsed)/.test(l)){title=l;break;}}
        if(!title)return;
        const pm=text.match(/US\s*\$[\d.]+\s*[-–]\s*[\d.]+/)||text.match(/US\s*\$[\d.]+/);
        const soldM=text.match(/(\d+)\s*Sold/i);const sold=soldM?soldM[1]+' sold':'';
        const ratM=text.match(/([\d.]+)\s*$/m);const rating=(ratM&&parseFloat(ratM[1])<=5)?ratM[1]:'';
        const shipFree=/Free Shipping/i.test(text);
        const delivM=text.match(/(\d+)\s*Days?\s*Del/i);
        const endorsed=/Endorsed/i.test(text);
        rows.push({Item:title.substring(0,90),Store:'DHgate',StoreLink:url,Link:url,SalePrice:pm?pm[0]:'See DHgate',OrigPrice:'',Discount:'',DelCost:shipFree?'FREE':'',Setup:'',Delivery:delivM?delivM[0]:'',Return:'',Rating:rating||'',Reviews:'N/A',Sold:sold||'',Condition:'',Badge:endorsed?'Endorsed':'',MOQ:'',SupplierInfo:'',Description:'',Specifications:''});
      });
      return rows;
    },

    // ═══ MADE-IN-CHINA — h2 titles (VERIFIED: price, MOQ, rating, supplier) ═══
    madeinchina(){
      const rows=[],seen={};
      // FIXED: Sibling text parsing + ALL specs + company store link + badges
      document.querySelectorAll('h2').forEach(h2=>{
        const title=(h2.innerText||'').trim();if(!title||title.length<5||seen[title])return;
        let container=h2.parentElement;
        while(container&&container.parentElement){const p=container.parentElement;if(p.querySelectorAll('h2').length>1||/US\$/.test(container.innerText))break;container=p;}
        let text=(container.innerText||'');
        let sib=container.nextElementSibling;
        for(let i=0;i<5&&sib;i++){text+=' '+sib.innerText;sib=sib.nextElementSibling;}
        const lk=container.querySelector('a[href*="made-in-china.com/product"]')||h2.querySelector('a')||h2.closest('a');
        const url=lk?(lk.href||''):'';if(!url)return;seen[title]=true;
        const pm=text.match(/US\$([\d.]+[-–][\d.]+)/)||text.match(/US\$([\d.]+)/);
        const moqM=text.match(/(\d+)\s*Pieces?\s*\(MOQ\)/i);
        const ratM=text.match(/([\d.]+)\s*\/\s*5\.0/);
        const compM=text.match(/([A-Z][\w\s]+(?:Co\.|Ltd|Inc|Technology|Electronics|Machinery)[^|]{0,15})/);
        const company=compM?compM[0].trim().substring(0,40):'China Supplier';
        const urlMatch=url.match(/\/\/([\w-]+)\.en\.made-in-china\.com/);
        const storeLink=urlMatch?'https://'+urlMatch[1]+'.en.made-in-china.com/':url;
        // ALL specs visible on PLP
        const specs=[];
        ['Type','Material','After-sales Service','Warranty','Logo Printing','Customized','Size','Application','Color','Weight','Certification','Brand Name','Voltage','Power','Condition'].forEach(k=>{
          const m=text.match(new RegExp(k+'\\s*[:\\s]\\s*([^\\n]{2,40})','i'));
          if(m)specs.push(k+': '+m[1].trim());
        });
        // Badges
        const badges=[];
        if(/Audited/i.test(text))badges.push('Audited');
        if(/Secured Trading/i.test(text))badges.push('Secured Trading');
        if(/"On-time Delivery"/i.test(text))badges.push('On-time Delivery');
        if(/"Fast Dispatch"/i.test(text))badges.push('Fast Dispatch');
        rows.push({Item:title,Store:company,StoreLink:storeLink,Link:url,SalePrice:pm?'US$'+pm[1]:'FOB',OrigPrice:'',Discount:'',DelCost:'',Setup:'',Delivery:'',Return:'',Rating:ratM?ratM[1]:'N/A',Reviews:'N/A',Sold:'N/A',Condition:'',Badge:badges.join(', '),MOQ:moqM?moqM[0]:'—',SupplierInfo:company+(badges.includes('Audited')?' | Audited':''),Description:'',Specifications:specs.join(' | ')});
      });
      return rows;
    },

    // ═══ 1688 — .search-offer-wrapper (LIVE VERIFIED: 61 cards, prices, sold, supplier) ═══
    '1688'(){
      const rows=[],seen={};
      document.querySelectorAll('.search-offer-wrapper, a.search-offer-wrapper').forEach(card=>{
        const cls=typeof card.className==='string'?card.className:'';
        if(cls.includes('adOffer'))return; // skip ads
        const text=card.innerText||'';if(text.length<20)return;
        const lines=text.split('\n').map(l=>l.trim()).filter(Boolean);
        // Title = first long line
        let title='';for(const l of lines){if(l.length>15&&!/^(¥|Free|Return|First|Gold|Official|Supports)/.test(l)&&!seen[l]){title=l;break;}}
        if(!title||title.length<5)return;seen[title]=true;
        // Price
        const pm=text.match(/¥\s*[\d.]+/);const price=pm?pm[0]:'';
        // Sold
        const soldM=text.match(/([\d,]+\+?)\s*(?:items sold|items|pieces|sold)/i);const sold=soldM?soldM[1]:'';
        // Supplier name (city + company)
        let supplier='';
        lines.forEach(l=>{if(/^(Shenzhen|Guangzhou|Dongguan|Foshan|Yiwu|Ningbo|Shanghai|Hangzhou)/.test(l))supplier=l.substring(0,35);});
        // Badges
        const badges=[];
        if(/Free shipping/i.test(text))badges.push('Free shipping');
        if(/Return shipping/i.test(text))badges.push('Return shipping included');
        if(/Limited.time/i.test(text))badges.push('Limited-time offer');
        // Product link — offerId from detail.m.1688 links inside card
        let url=card.href||'';
        if(!url){const a=card.querySelector('a[href]');if(a)url=a.href;}
        // offerId from mobile links
        if(!url.includes('detail')){
          const mLink=card.querySelector('a[href*="detail.m.1688"]');
          if(mLink){const m=(mLink.getAttribute('href')||'').match(/offerId=(\d+)/i);if(m)url='https://detail.1688.com/offer/'+m[1]+'.html';}
        }
        rows.push({Item:title.substring(0,80),Store:supplier||'1688 Supplier',StoreLink:url,Link:url,SalePrice:price||'¥ Inquiry',OrigPrice:'',Discount:'',DelCost:badges.includes('Free shipping')?'FREE':'CN Domestic',Setup:'',Delivery:'',Return:'',Rating:'N/A',Reviews:'N/A',Sold:sold||'',Condition:'',Badge:badges.join(', '),MOQ:'',SupplierInfo:supplier,Description:'',Specifications:''});
      });
      return rows;
    }
  };

  const fn=EX[site];if(!fn)return{rows:[],kw:'',site};
  const rows=fn().map(r=>analyze(r));
  const qs=new URLSearchParams(location.search);
  let kw=qs.get('k')||qs.get('q')||qs.get('_nkw')||qs.get('search_key')||qs.get('SearchText')||qs.get('keywords')||qs.get('searchkey')||'';
  if(!kw&&site==='aliexpress'){const pm=location.pathname.match(/\/w\/wholesale-([^.]+)/i);if(pm)kw=decodeURIComponent(pm[1].replace(/-/g,' '));}
  if(!kw)kw=(document.title||'products').split(/[-|–]/)[0].trim();
  kw=kw.substring(0,25).replace(/\s+/g,'-');
  return{rows,kw,site};
}

loadFiles();
