// ═══════════════════════════════════════════════════════════════════════
// scrapers/1688.js — 1688.com search results (PLP)
// ═══════════════════════════════════════════════════════════════════════
window.ScraperRegistry = window.ScraperRegistry || {};

window.ScraperRegistry['1688'] = function scrape1688() {
  const H = window.ShopHelpers;
  const rows = [], seen = {};
  document.querySelectorAll('.search-offer-wrapper, a.search-offer-wrapper, [class*="offer-card"]').forEach(card => {
    try {
      const cls = typeof card.className === 'string' ? card.className : '';
      if (cls.includes('adOffer')) return;
      const text = card.innerText || '';
      if (text.length < 20) return;
      const lines = text.split('\n').map(l => l.trim()).filter(Boolean);

      let title = '';
      for (const l of lines) { if (l.length > 15 && !/^(¥|Free|Return|First|Gold|Official|Supports)/.test(l) && !seen[l]) { title = l; break; } }
      if (!title || title.length < 5) return;
      seen[title] = true;

      const pm = text.match(/¥\s*[\d.]+/);
      const price = pm ? pm[0] : '';

      const soldM = text.match(/([\d,]+\+?)\s*(?:items sold|items|pieces|sold)/i);
      const sold = soldM ? soldM[1] : '';

      let supplier = '';
      lines.forEach(l => { if (/^(Shenzhen|Guangzhou|Dongguan|Foshan|Yiwu|Ningbo|Shanghai|Hangzhou)/.test(l)) supplier = l.substring(0, 35); });

      const badges = [];
      if (/Free shipping/i.test(text)) badges.push('Free shipping');
      if (/Return shipping/i.test(text)) badges.push('Return shipping included');
      if (/Limited.time/i.test(text)) badges.push('Limited-time offer');

      let url = card.href || '';
      if (!url) { const a = card.querySelector('a[href]'); if (a) url = a.href; }
      if (!url.includes('detail')) {
        const mLink = card.querySelector('a[href*="detail.m.1688"]');
        if (mLink) { const m = (mLink.getAttribute('href') || '').match(/offerId=(\d+)/i); if (m) url = 'https://detail.1688.com/offer/' + m[1] + '.html'; }
      }

      const images = H.collectImages(card, 5).join(' | ');
      rows.push({ Item: title.substring(0, 80), Store: supplier || '1688 Supplier', StoreLink: url, Link: url, SalePrice: price || '¥ Inquiry', OrigPrice: '', Discount: '', DelCost: badges.includes('Free shipping') ? 'FREE' : 'CN Domestic', Setup: '', Delivery: '', Return: '', Rating: 'N/A', Reviews: 'N/A', Sold: sold || '', Condition: '', Badge: badges.join(', '), MOQ: '', SupplierInfo: supplier, Description: '', Specifications: '', Images: images });
    } catch (e) { /* skip malformed card */ }
  });
  return rows;
};
