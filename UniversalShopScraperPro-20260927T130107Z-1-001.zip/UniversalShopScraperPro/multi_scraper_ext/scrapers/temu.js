// ═══════════════════════════════════════════════════════════════════════
// scrapers/temu.js — Temu search results (PLP)
// Primary source is the JSON-LD ItemList Temu embeds on every search
// page; DOM text is only used to enrich sold-count / original-price /
// badge / a best-effort store name, since Temu's markup is heavily
// obfuscated and changes often.
// ═══════════════════════════════════════════════════════════════════════
window.ScraperRegistry = window.ScraperRegistry || {};

window.ScraperRegistry.temu = function scrapeTemu() {
  const H = window.ShopHelpers;
  const rows = [], seen = {};
  let jItems = [];
  document.querySelectorAll('script[type="application/ld+json"]').forEach(jld => {
    try { const d = JSON.parse(jld.textContent); if (d.itemListElement && d.itemListElement.length) jItems = jItems.concat(d.itemListElement); } catch (e) {}
  });

  const dom = {};
  document.querySelectorAll('h2').forEach(h2 => {
    try {
      const c = h2.closest('div') || h2.parentElement;
      if (!c) return;
      const t = (h2.innerText || '').trim().substring(0, 50);
      const txt = c.innerText || '';
      const sold = (txt.match(/([\d,.]+[KkMm+]*)\s*(?:\|?\s*)?sold/i) || [])[1] || '';
      const orig = (txt.match(/Original price\s*\S*\s*([\d,]+)/i) || [])[1] || '';
      const badge = (txt.match(/(Best-Selling|Top pick|Top Rated|Summer Deals?|Star seller|Last \d+ days?|ONLY \d+ LEFT)/i) || [])[1] || '';
      const storeM = txt.match(/Sold by\s+([^\n]{2,30})/i);
      dom[t] = { sold, orig, badge, store: storeM ? storeM[1].trim() : '' };
    } catch (e) {}
  });

  if (jItems.length) {
    jItems.forEach(item => {
      try {
        const url = item.url || '';
        if (seen[url]) return;
        seen[url] = true;
        const p = item.offers || {};
        const ar = item.aggregateRating || {};
        const title = (item.name || '').trim();
        const dk = title.substring(0, 50);
        const d = dom[dk] || {};
        const curr = p.priceCurrency || '';
        const priceVal = p.price || '';
        const sp = curr && priceVal ? curr + ' ' + priceVal : priceVal;
        const op = d.orig ? (curr + ' ' + d.orig) : '';
        const imgRaw = item.image ? (Array.isArray(item.image) ? item.image : [item.image]) : [];
        const images = imgRaw.filter(Boolean).slice(0, 5).map(H.upgradeImageUrl).join(' | ');
        rows.push({ Item: title, Store: d.store || '', StoreLink: '', Link: url, SalePrice: sp, OrigPrice: op, Discount: '', DelCost: 'Free shipping', Setup: '', Delivery: '', Return: '', Rating: String(ar.ratingValue || ''), Reviews: String(ar.reviewCount || ''), Sold: d.sold || '', Condition: '', Badge: d.badge || '', MOQ: '', SupplierInfo: '', Description: '', Specifications: '', Images: images });
      } catch (e) {}
    });
  }

  // Fallback: no JSON-LD found (Temu occasionally omits it) — scrape cards directly.
  if (!rows.length) {
    document.querySelectorAll('[class*="goods-item"],[class*="_goods"],a[href*="/goods.html"],a[href*="-g-"]').forEach(card => {
      try {
        const lk = card.matches('a') ? card : card.querySelector('a[href*="goods"],a[href*="-g-"]');
        const url = lk ? lk.href : '';
        if (!url || seen[url]) return;
        const text = card.innerText || '';
        if (text.length < 8) return;
        const priceM = text.match(/[\$€£]\s*[\d,.]+/);
        if (!priceM) return;
        seen[url] = true;
        const title = text.split('\n').map(l => l.trim()).filter(l => l.length > 8)[0] || '';
        const images = H.collectImages(card, 5).join(' | ');
        rows.push({ Item: title.substring(0, 150), Store: '', StoreLink: '', Link: url, SalePrice: priceM[0], OrigPrice: '', Discount: '', DelCost: '', Setup: '', Delivery: '', Return: '', Rating: '', Reviews: '', Sold: '', Condition: '', Badge: '', MOQ: '', SupplierInfo: '', Description: '', Specifications: '', Images: images });
      } catch (e) {}
    });
  }

  // Last resort — embedded hydration JSON (DOM-change-proof). If Temu ships
  // neither JSON-LD nor a recognizable card layout, pull title/price
  // straight from its own (heavily obfuscated but still present) React
  // hydration state. Temu's real product URL needs an exact slug the
  // hydration blob doesn't reliably expose, so Link honestly points back
  // to this search page instead of guessing a broken one.
  if (!rows.length) {
    H.findEmbeddedProducts().forEach(p => {
      if (!p.title || seen[p.title]) return;
      seen[p.title] = true;
      rows.push({ Item: p.title.substring(0, 200), Store: '', StoreLink: '', Link: location.href.split('#')[0], SalePrice: p.price, OrigPrice: '', Discount: '', DelCost: '', Setup: '', Delivery: '', Return: '', Rating: '', Reviews: '', Sold: '', Condition: '', Badge: '', MOQ: '', SupplierInfo: '', Description: '', Specifications: '', Images: p.image ? H.upgradeImageUrl(p.image) : '' });
    });
  }

  return rows;
};
