// ═══════════════════════════════════════════════════════════════════════
// scrapers/aliexpress.js — AliExpress search results (PLP)
// NOTE: as of the current AliExpress layout, seller/store links are NOT
// present on the search-results cards at all (verified live) — only on
// the product detail page. StoreLink/Store are therefore filled in by
// pdp/aliexpressPDP.js during Deep Scrape, not here. Quick Scrape will
// correctly show "—" for Store/StoreLink; that is expected, not a bug.
// Four independent extraction strategies run in order so a DOM change
// on any one of them still yields data.
// ═══════════════════════════════════════════════════════════════════════
window.ScraperRegistry = window.ScraperRegistry || {};

window.ScraperRegistry.aliexpress = function scrapeAliexpress() {
  const H = window.ShopHelpers, nm = H.nm, absUrl = H.absUrl, itemId = H.itemId, findCard = H.findCard, firstPrice = H.firstPrice, parseRatingReviews = H.parseRatingReviews, parseSold = H.parseSold;
  const rows = [], seen = {};

  function pushRow(card, url, title) {
    try {
      const id = itemId(url);
      if (!id || seen[id]) return false;
      const text = (card.innerText || '').trim();
      if (text.length < 10) return false;

      const prices = firstPrice(text);
      const salePrice = prices[0] || '';
      let origPrice = prices[1] || '';
      if (origPrice && nm(origPrice) <= nm(salePrice)) origPrice = '';

      const rr = parseRatingReviews(text);
      let rating = rr.rating, sold = parseSold(text), reviews = rr.reviews;
      const ratSoldM = text.match(/(\d\.?\d?)\s*[|·]\s*([\d,.]+[KkMm+]*)\s*(?:sold|orders)/i);
      if (ratSoldM) { rating = rating || ratSoldM[1]; sold = sold || (ratSoldM[2] + ' sold'); }
      if (!sold) { const sm = text.match(/([\d,.]+[KkMm+]*)\s*(?:sold|orders)/i); if (sm) sold = sm[1] + ' sold'; }
      if (!rating) { const rm = text.match(/\b([1-5](?:\.\d)?)\b/); if (rm && parseFloat(rm[1]) <= 5) rating = rm[1]; }

      const discM = text.match(/-(\d+)%/); const discount = discM ? discM[1] + '% off' : '';
      const shipM = text.match(/(Free shipping[^|\n]*|Save\s+\S+)/i); const ship = shipM ? shipM[0].substring(0, 30) : '';

      let store = '', storeLink = '';
      const storeA = card.querySelector('a[href*="/store/"],a[href*="/shop/"],a[href*="storeId"]');
      // BUG FIX: don't strip the query string on store links — the
      // selector explicitly targets "storeId" which can live in the
      // query string itself; stripping it would produce a dead link.
      // (Product `Link` below is untouched: its query string is just
      // tracking params, confirmed live — the item ID lives in the path.)
      if (storeA) { storeLink = absUrl(storeA.getAttribute('href') || '').split('#')[0]; store = (storeA.innerText || '').trim().substring(0, 40); }
      // BUG FIX (live-verified — reported by user): unbounded "Shop"
      // matched mid-word inside "Shoppers" (e.g. "5,000 Shoppers save
      // PKR2,425"), capturing the tail of that sentence ("pers save
      // PKR2,425") as if it were the store name. Word-bounded now, same
      // fix pattern as the earlier "icon"/"silicone" bug.
      if (!store) { const storeM = text.match(/\b(?:Store|Shop)\b\s*[:\n]?\s*([^\n|]{2,35})/i); if (storeM && !/\d/.test(storeM[1].trim()[0] || '')) store = storeM[1].trim(); }

      if (!salePrice && !sold && !rating && !store) return false;
      seen[id] = true;
      const images = H.collectImages(card, 5).join(' | ');
      rows.push({ Item: title.substring(0, 200), Store: store, StoreLink: storeLink, Link: absUrl(url).split('?')[0], SalePrice: salePrice, OrigPrice: origPrice, Discount: discount || '', DelCost: /free/i.test(ship) ? 'FREE' : ship, Setup: '', Delivery: '', Return: '', Rating: rating || '', Reviews: reviews || '', Sold: sold || '', Condition: '', Badge: '', MOQ: '', SupplierInfo: '', Description: '', Specifications: '', Images: images });
      return true;
    } catch (e) { return false; }
  }

  const gridSels = ['[class*="SearchProductFeed"]', '[class*="search-item-card"]', '[class*="search-card"]', '[class*="list--gallery"]', '[class*="manhattan"]', '[class*="product-list"]', '[class*="search-root"]', '[class*="items-list"]', 'main', '#root'];
  let scope = document.body;
  for (let i = 0; i < gridSels.length; i++) {
    const el = document.querySelector(gridSels[i]);
    if (el && el.querySelectorAll('a[href*="/item/"]').length >= 2) { scope = el; break; }
  }

  // Strategy A — product links inside card containers (primary path)
  scope.querySelectorAll('a[href*="/item/"]').forEach(a => {
    try {
      const url = a.href || a.getAttribute('href') || '';
      if (!url || seen[itemId(url)]) return;
      const card = findCard(a, 10);
      let title = (a.getAttribute('title') || '').trim();
      if (!title) { const te = card.querySelector('h1,h2,h3,[class*="title"],[class*="Title"]'); title = te ? ((te.getAttribute('title') || te.innerText || '').trim()) : ''; }
      if (!title) title = (a.innerText || '').trim().split('\n').map(l => l.trim()).filter(l => l.length > 8)[0] || '';
      if (!title || title.length < 5 || /aliexpress|download|sign in|register/i.test(title)) return;
      pushRow(card, url, title);
    } catch (e) {}
  });

  // Strategy B — legacy search-card / card-out-wrapper
  if (!rows.length) {
    document.querySelectorAll('[class*="search-card"],[class*="card-out-wrapper"],[class*="list--item"],a.search-card-item').forEach(card => {
      try {
        const h3 = card.querySelector('h3,h2,[class*="title"]');
        if (!h3) return;
        const title = (h3.getAttribute('title') || h3.innerText || '').trim();
        if (!title || title.length < 5) return;
        const linkA = h3.closest('a') || card.querySelector('a[href*="/item/"]');
        const url = linkA ? (linkA.href || linkA.getAttribute('href') || '') : '';
        if (!url) return;
        pushRow(card, url, title);
      } catch (e) {}
    });
  }

  // Strategy C — JSON-LD ItemList
  if (!rows.length) {
    document.querySelectorAll('script[type="application/ld+json"]').forEach(jld => {
      try {
        const d = JSON.parse(jld.textContent);
        const list = d.itemListElement || (d['@graph'] || []).filter(x => x['@type'] === 'ListItem') || [];
        (Array.isArray(list) ? list : []).forEach(li => {
          try {
            const item = li.item || li;
            const url = item.url || item['@id'] || '';
            if (!url || seen[itemId(url)]) return;
            pushRow(document.body, url, item.name || '');
          } catch (e) {}
        });
      } catch (e) {}
    });
  }

  // Strategy D — any /item/ link with an image sibling (last resort)
  if (!rows.length) {
    document.querySelectorAll('a[href*="/item/"]').forEach(a => {
      try {
        const url = a.href || '';
        if (!url || seen[itemId(url)]) return;
        const card = findCard(a, 6);
        if (!card.querySelector('img')) return;
        const title = (a.getAttribute('title') || a.innerText || '').trim().split('\n')[0];
        if (title.length < 5) return;
        pushRow(card, url, title);
      } catch (e) {}
    });
  }

  // Strategy E — embedded hydration JSON (window.runParams / __AER_DATA__ /
  // any inline script JSON blob). AliExpress's SPA ships the raw product
  // list as JSON before rendering it; if all DOM strategies above found
  // nothing (e.g. a completely new layout), pull straight from that data.
  if (!rows.length) {
    try {
      const state = H.scanEmbeddedState ? H.scanEmbeddedState() : {};
      Object.keys(state).forEach(key => {
        if (rows.length) return;
        const found = H.deepFindKeys(state[key], ['productId', 'itemId', 'title', 'subject', 'productTitle'], 6);
        // deepFindKeys only returns single scalar values; for list data we
        // do a shallow manual walk instead since we need every item, not one.
      });
      // Manual shallow walk for arrays that look like a product list.
      Object.keys(state).forEach(key => {
        if (rows.length) return;
        const root = state[key];
        if (!root || typeof root !== 'object') return;
        const stack = [root];
        let steps = 0;
        while (stack.length && steps < 500 && !rows.length) {
          steps++;
          const node = stack.pop();
          if (Array.isArray(node)) {
            const looksLikeProducts = node.length > 1 && node.every(x => x && typeof x === 'object' && (x.title || x.subject || x.productTitle));
            if (looksLikeProducts) {
              node.forEach(it => {
                const title = it.title || it.subject || it.productTitle || '';
                const pid = it.productId || it.itemId || it.id || '';
                if (!title || !pid || seen[pid]) return;
                seen[pid] = true;
                const price = it.price || (it.prices && it.prices.salePrice && it.prices.salePrice.formattedPrice) || '';
                rows.push({ Item: String(title).substring(0, 200), Store: '', StoreLink: '', Link: 'https://www.aliexpress.com/item/' + pid + '.html', SalePrice: String(price || ''), OrigPrice: '', Discount: '', DelCost: '', Setup: '', Delivery: '', Return: '', Rating: '', Reviews: '', Sold: '', Condition: '', Badge: '', MOQ: '', SupplierInfo: '', Description: '', Specifications: '', Images: '' });
              });
              return;
            }
            node.forEach(x => { if (x && typeof x === 'object') stack.push(x); });
          } else {
            Object.keys(node).forEach(k => { if (node[k] && typeof node[k] === 'object') stack.push(node[k]); });
          }
        }
      });
    } catch (e) {}
  }

  return rows;
};
