// ═══════════════════════════════════════════════════════════════════════
// scrapers/walmart.js — Walmart search results (PLP)
// ═══════════════════════════════════════════════════════════════════════
window.ScraperRegistry = window.ScraperRegistry || {};

window.ScraperRegistry.walmart = function scrapeWalmart() {
  const H = window.ShopHelpers, absUrl = H.absUrl;
  const rows = [], seen = {};
  document.querySelectorAll('[data-item-id]').forEach(card => {
    try {
      const id = card.getAttribute('data-item-id');
      if (!id || seen[id]) return;

      let title = '';
      const ts = card.querySelector('[data-automation-id="product-title"]');
      if (ts) title = ts.innerText.trim();
      if (!title) { const btn = card.querySelector('button[data-automation-id="add-to-cart"]'); if (btn) { const m = (btn.getAttribute('aria-label') || '').match(/Add to cart - (.+)/i); if (m) title = m[1]; } }
      if (!title) { const h = card.querySelector('span[data-automation-id],a span'); if (h) title = (h.innerText || '').trim(); }
      if (!title) return;

      const pt = card.querySelector('[data-automation-id="product-price"]');
      const priceText = pt ? pt.innerText : (card.innerText || '');
      // BUG FIX (live-verified): Walmart's visible "Now$1988" text has no
      // decimal point (dollars/cents render as separate DOM nodes with no
      // "." between them) — the accessibility text a few characters later
      // ("current price Now $19.88, Was $29.38") has the real value, but
      // has "Now " between "price" and "$" which the old regex didn't
      // allow for, so it fell through to the broken "$1988" match instead.
      const pm = priceText.match(/current price[^$]{0,10}\$([\d,]+\.\d{2})/i) || priceText.match(/\$([\d,]+\.\d{2})/) || priceText.match(/\$([\d,.]+)/);
      const price = pm ? '$' + pm[1] : '';
      if (!price) return;
      seen[id] = true;

      const origMatch = priceText.match(/Was \$([\d.]+)/i);
      const origPrice = origMatch ? '$' + origMatch[1] : '';

      const cardText = card.innerText;
      const rm = cardText.match(/([\d.]+)\s+out of 5 Stars?\.\s*([\d,]+)\s*reviews?/i);
      const rating = rm ? rm[1] : '';
      const reviews = rm ? rm[2].replace(/,/g, '') : '';

      const bg = card.querySelector('[data-testid="badgeTagComponent"],[class*="badge"]');
      const badge = bg ? (bg.innerText || '').trim() : '';

      const dm = cardText.match(/(Shipping arrives[^\n]+|Free delivery[^\n]+|Arrives [^\n]+)/i);
      const delivery = dm ? dm[0].substring(0, 50) : '';

      const sm = cardText.match(/([\d+]+\+?\s*bought\s+[^\n]+)/i);
      const sold = sm ? sm[0].substring(0, 35) : '';

      const lk = card.querySelector('a[href*="/ip/"]');
      const url = lk ? lk.href : '';

      let storeLink = '', store = '';
      const sellerA = card.querySelector('a[href*="/seller/"],a[href*="/brand/"],a[href*="/cp/"]');
      // BUG FIX: same class of bug as Amazon — don't strip the query
      // string, only the hash. Walmart seller/brand links can carry
      // identifying query params too.
      if (sellerA) { storeLink = absUrl(sellerA.getAttribute('href') || '').split('#')[0]; store = (sellerA.innerText || '').trim().substring(0, 30); }
      if (!store) { const sb = cardText.match(/Sold (?:and shipped )?by\s+([^\n]{2,30})/i); if (sb) store = sb[1].trim(); }

      const images = H.collectImages(card, 5).join(' | ');
      rows.push({ Item: title, Store: store, StoreLink: storeLink, Link: url, SalePrice: price, OrigPrice: origPrice, Discount: '', DelCost: delivery.toLowerCase().includes('free') ? 'FREE' : '', Setup: '', Delivery: delivery, Return: '', Rating: rating || '', Reviews: reviews || '', Sold: sold || '', Condition: '', Badge: badge, MOQ: '', SupplierInfo: '', Description: '', Specifications: '', Images: images });
    } catch (e) { /* skip malformed card */ }
  });

  // Last resort — embedded hydration JSON (DOM-change-proof). Walmart's
  // search page is Next.js-rendered; if every DOM strategy above finds
  // nothing, pull title/price/itemId straight from that hydration state.
  // A bare "/ip/<id>" URL (no slug) reliably redirects to the real PDP.
  if (!rows.length) {
    H.findEmbeddedProducts().forEach(p => {
      if (!p.title || !p.id || seen[p.id]) return;
      seen[p.id] = true;
      rows.push({ Item: p.title.substring(0, 200), Store: '', StoreLink: '', Link: 'https://www.walmart.com/ip/' + p.id, SalePrice: p.price, OrigPrice: '', Discount: '', DelCost: '', Setup: '', Delivery: '', Return: '', Rating: '', Reviews: '', Sold: '', Condition: '', Badge: '', MOQ: '', SupplierInfo: '', Description: '', Specifications: '', Images: p.image ? H.upgradeImageUrl(p.image) : '' });
    });
  }
  return rows;
};
