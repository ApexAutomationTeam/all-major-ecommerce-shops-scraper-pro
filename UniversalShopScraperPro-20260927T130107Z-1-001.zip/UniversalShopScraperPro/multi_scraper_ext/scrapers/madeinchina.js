// ═══════════════════════════════════════════════════════════════════════
// scrapers/madeinchina.js — Made-in-China search results (PLP)
// ═══════════════════════════════════════════════════════════════════════
window.ScraperRegistry = window.ScraperRegistry || {};

window.ScraperRegistry.madeinchina = function scrapeMadeInChina() {
  const H = window.ShopHelpers;
  const rows = [], seen = {};
  document.querySelectorAll('h2').forEach(h2 => {
    try {
      const title = (h2.innerText || '').trim();
      if (!title || title.length < 5 || seen[title]) return;

      let container = h2.parentElement;
      while (container && container.parentElement) {
        const p = container.parentElement;
        if (p.querySelectorAll('h2').length > 1 || /US\$/.test(container.innerText)) break;
        container = p;
      }
      let text = (container.innerText || '');
      let sib = container.nextElementSibling;
      for (let i = 0; i < 5 && sib; i++) { text += ' ' + sib.innerText; sib = sib.nextElementSibling; }

      const lk = container.querySelector('a[href*="made-in-china.com/product"]') || h2.querySelector('a') || h2.closest('a');
      const url = lk ? (lk.href || '') : '';
      if (!url) return;
      seen[title] = true;

      const pm = text.match(/US\$([\d.]+[-–][\d.]+)/) || text.match(/US\$([\d.]+)/);
      const moqM = text.match(/(\d+)\s*Pieces?\s*\(MOQ\)/i);
      const ratM = text.match(/([\d.]+)\s*\/\s*5\.0/);
      const compM = text.match(/([A-Z][\w\s]+(?:Co\.|Ltd|Inc|Technology|Electronics|Machinery)[^|]{0,15})/);
      const company = compM ? compM[0].trim().substring(0, 40) : 'China Supplier';

      const urlMatch = url.match(/\/\/([\w-]+)\.en\.made-in-china\.com/);
      const storeLink = urlMatch ? 'https://' + urlMatch[1] + '.en.made-in-china.com/' : url;

      // BUG FIX (live-verified — reported by user): specs were limited to
      // a fixed 15-keyword whitelist (Type, Material, Warranty, etc.), so
      // any attribute the card actually shows under a DIFFERENT label
      // (e.g. "Compatible Brand", "Power Source", "Quick Charging
      // Function", "Over-Current Protection" — all real Made-in-China
      // attribute names, none of which were in the old list) was silently
      // dropped even though the text was right there. Replaced with a
      // generic line-by-line "Label : Value" scanner that captures
      // whatever attributes the card actually displays, whatever they're
      // called, instead of only the pre-picked few.
      const specs = [];
      const seenLabels = {};
      text.split('\n').map(l => l.trim()).forEach(line => {
        if (specs.length >= 12) return;
        const m = line.match(/^([A-Z][A-Za-z0-9][\w()./&\- ]{1,35}?)\s*:\s*(.{1,60})$/);
        if (!m) return;
        const label = m[1].trim(), value = m[2].trim();
        if (!value || seenLabels[label.toLowerCase()]) return;
        if (/^(US\$|MOQ|Piece|Pieces|Send Inquiry|Chat Now|Rating|Review)/i.test(label)) return;
        seenLabels[label.toLowerCase()] = true;
        specs.push(label + ': ' + value);
      });
      // Keep the old fixed-keyword pass too as a safety net for cases where
      // a label/value pair got split across two DOM nodes and lost its
      // own newline in `text` (so the line-scanner above wouldn't see it).
      ['Type', 'Material', 'After-sales Service', 'Warranty', 'Logo Printing', 'Customized', 'Size', 'Application', 'Color', 'Weight', 'Certification', 'Brand Name', 'Voltage', 'Power', 'Condition'].forEach(k => {
        if (seenLabels[k.toLowerCase()]) return;
        const m = text.match(new RegExp(k + '\\s*[:\\s]\\s*([^\\n]{2,40})', 'i'));
        if (m) { specs.push(k + ': ' + m[1].trim()); seenLabels[k.toLowerCase()] = true; }
      });

      const badges = [];
      if (/Audited/i.test(text)) badges.push('Audited');
      if (/Secured Trading/i.test(text)) badges.push('Secured Trading');
      if (/On-time Delivery/i.test(text)) badges.push('On-time Delivery');
      if (/Fast Dispatch/i.test(text)) badges.push('Fast Dispatch');

      // BUG FIX (live-verified): `container` (the walk-up used for title/
      // price text) stops climbing as soon as it sees ">1 h2" or "US$" in
      // its own text, which is BELOW where the actual product photo
      // lives — that photo sits in the wider `.products-item` card, one
      // level up from the trust-badge cluster. Search there specifically;
      // fall back to `container` if the card class isn't present.
      const imgScope = h2.closest('.products-item') || container;
      const images = H.collectImages(imgScope, 6).join(' | ');
      rows.push({ Item: title, Store: company, StoreLink: storeLink, Link: url, SalePrice: pm ? 'US$' + pm[1] : 'FOB', OrigPrice: '', Discount: '', DelCost: '', Setup: '', Delivery: '', Return: '', Rating: ratM ? ratM[1] : 'N/A', Reviews: 'N/A', Sold: 'N/A', Condition: '', Badge: badges.join(', '), MOQ: moqM ? moqM[0] : '—', SupplierInfo: company + (badges.includes('Audited') ? ' | Audited' : ''), Description: '', Specifications: specs.join(' | '), Images: images });
    } catch (e) { /* skip malformed card */ }
  });
  return rows;
};
