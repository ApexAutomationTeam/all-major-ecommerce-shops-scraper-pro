// ═══════════════════════════════════════════════════════════════════════
// scrapers/daraz.js — Daraz search results (PLP)
// ═══════════════════════════════════════════════════════════════════════
window.ScraperRegistry = window.ScraperRegistry || {};

window.ScraperRegistry.daraz = function scrapeDaraz() {
  const H = window.ShopHelpers;
  const rows = [], seen = {};
  // BUG FIX (live-verified): `[data-qa-locator*="product"]` also matches
  // the single big wrapper `data-qa-locator="general-products"` that
  // contains EVERY product on the page, so it was being iterated as if
  // it were one giant (wrong) card. Prefer the exact per-item locator;
  // only fall back to the wildcard if the exact one finds nothing (new
  // layout Daraz hasn't rolled out yet, etc.).
  let cardEls = [...document.querySelectorAll('[data-qa-locator="product-item"]')];
  if (!cardEls.length) cardEls = [...document.querySelectorAll('[data-qa-locator*="product"],[class*="gridItem"],[class*="c1_t2i"]')].filter(el => (el.getAttribute('data-qa-locator') || '') !== 'general-products');
  cardEls.forEach(card => {
    try {
      const lk = card.querySelector('a[href*="/products/"]') || (card.matches('a[href*="/products/"]') ? card : null);
      const url = lk ? lk.href : '';
      if (!url || seen[url]) return;
      const text = card.innerText || '';
      const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
      let title = '';
      for (let i = 0; i < lines.length; i++) { if (lines[i].length > 10 && !lines[i].startsWith('Rs.')) { title = lines[i]; break; } }
      if (!title || title.length < 5 || seen[title]) return;
      seen[title] = true; seen[url] = true;

      const pm = text.match(/Rs\.\s*([\d,]+)/);
      const price = pm ? 'Rs. ' + pm[1] : '';
      const discM = text.match(/(\d+)%\s*Off/i);
      const disc = discM ? discM[1] + '% Off' : '';
      const soldM = text.match(/([\d,.]+[KkMm]*)\s*sold/i);
      const sold = soldM ? soldM[1] + ' sold' : '';
      const revM = text.match(/\((\d[\d,]*)\)/);
      const reviews = revM ? revM[1] : '';
      const locM = text.match(/(Sindh|Punjab|Islamabad|KPK|Balochistan)/i);
      const loc = locM ? locM[0] : '';

      const images = H.collectImages(card, 5).join(' | ');
      rows.push({ Item: title.substring(0, 80), Store: '', StoreLink: url, Link: url, SalePrice: price, OrigPrice: '', Discount: disc, DelCost: '', Setup: '', Delivery: '', Return: '', Rating: 'N/A', Reviews: reviews || '', Sold: sold || '', Condition: '', Badge: '', MOQ: '', SupplierInfo: loc, Description: '', Specifications: '', Images: images });
    } catch (e) { /* skip malformed card */ }
  });
  return rows;
};
