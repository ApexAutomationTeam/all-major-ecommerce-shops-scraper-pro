// ═══════════════════════════════════════════════════════════════════════
// scrapers/ebay.js — eBay search results (PLP)
// ═══════════════════════════════════════════════════════════════════════
window.ScraperRegistry = window.ScraperRegistry || {};

window.ScraperRegistry.ebay = function scrapeEbay() {
  const H = window.ShopHelpers;
  const rows = [], seen = {};
  document.querySelectorAll('[class*="s-item"]').forEach(x => {
    try {
      const lk = x.querySelector('a.su-link, a[href*="/itm/"]');
      if (!lk) return;
      const url = lk.href || '';
      const id = (url.match(/\/itm\/(\d+)/) || [])[1] || '';
      if (!id || seen[id]) return;

      const te = x.querySelector('a.su-link span.su-styled-text') || x.querySelector('.s-item__title span') || x.querySelector('.s-item__title');
      const title = te ? (te.innerText || '').trim() : '';
      if (!title || title.length < 5 || /^Shop on eBay$/i.test(title)) return;

      const pe = x.querySelector('.su-item-card__price-container .su-styled-text') || x.querySelector('.s-item__price');
      const price = pe ? (pe.innerText || '').trim().split('\n')[0] : '';
      if (!price) return;
      seen[id] = true;

      const cardText = x.innerText || '';
      const lines = cardText.split('\n').map(l => l.trim());

      const cond = (cardText.match(/^(Brand New|Pre-Owned|Open Box|New \(Other\)|Used|Refurbished|New)$/im) || [])[1] || '';

      const sellerM = cardText.match(/([a-z_][\w.-]{2,30})\s+([\d.]+)%\s+positive\s+\(([\d.,KkMm]+)\)/i);
      const sellerName = sellerM ? sellerM[1] : '';
      const sellerFeedback = sellerM ? sellerM[2] + '% positive (' + sellerM[3] + ')' : '';
      let storeLink = sellerName ? 'https://www.ebay.com/usr/' + encodeURIComponent(sellerName) : '';
      if (!storeLink) { const sa = x.querySelector('a[href*="/usr/"],a[href*="/str/"]'); if (sa) storeLink = sa.href; }

      let origP = '';
      lines.forEach(l => { const m = l.match(/^\$([\d,.]+)$/); if (m && '$' + m[1] !== price && !origP) origP = '$' + m[1]; });

      let sold = ''; const soldM2 = cardText.match(/(\d[\d,]*)\s+sold/i); if (soldM2) sold = soldM2[1] + ' sold';

      let delCost = ''; const delM = cardText.match(/\+\$([\d.]+)\s*delivery/i); if (delM) delCost = '+$' + delM[1];
      if (/Free.*Shipping|Free.*delivery/i.test(cardText)) delCost = 'FREE';

      const buyFmt = (cardText.match(/(Buy It Now|Auction|Best Offer)/i) || [])[1] || '';

      const images = H.collectImages(x, 5).join(' | ');
      rows.push({ Item: title, Store: sellerName, StoreLink: storeLink, Link: url, SalePrice: price, OrigPrice: origP, Discount: '', DelCost: delCost, Setup: '', Delivery: '', Return: '', Rating: '', Reviews: '', Sold: sold, Condition: cond, Badge: buyFmt, MOQ: '', SupplierInfo: sellerFeedback, Description: '', Specifications: '', Images: images });
    } catch (e) { /* skip malformed card */ }
  });

  // Last resort — embedded hydration JSON (DOM-change-proof). If eBay's
  // card markup changes entirely and every selector above finds nothing,
  // pull title/price/itemId straight from the page's own hydration state.
  if (!rows.length) {
    H.findEmbeddedProducts().forEach(p => {
      if (!p.title || !p.id || seen[p.id]) return;
      seen[p.id] = true;
      rows.push({ Item: p.title.substring(0, 200), Store: '', StoreLink: '', Link: 'https://www.ebay.com/itm/' + p.id, SalePrice: p.price, OrigPrice: '', Discount: '', DelCost: '', Setup: '', Delivery: '', Return: '', Rating: '', Reviews: '', Sold: '', Condition: '', Badge: '', MOQ: '', SupplierInfo: '', Description: '', Specifications: '', Images: p.image ? H.upgradeImageUrl(p.image) : '' });
    });
  }
  return rows;
};
