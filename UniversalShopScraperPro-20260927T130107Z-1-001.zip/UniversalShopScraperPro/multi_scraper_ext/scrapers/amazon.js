// ═══════════════════════════════════════════════════════════════════════
// scrapers/amazon.js — Amazon search results (PLP)
// Multi-selector fallbacks so a DOM refresh on Amazon's side degrades
// gracefully instead of returning zero rows.
// ═══════════════════════════════════════════════════════════════════════
window.ScraperRegistry = window.ScraperRegistry || {};

window.ScraperRegistry.amazon = function scrapeAmazon() {
  const H = window.ShopHelpers, nm = H.nm, absUrl = H.absUrl;
  const MIN = 5;
  const rows = [], seen = {};
  const host = location.hostname;

  let cards = [...document.querySelectorAll('div[data-asin][data-component-type="s-search-result"]')];
  if (!cards.length) document.querySelectorAll('[data-asin]').forEach(x => { if ((x.getAttribute('data-asin') || '').length === 10) cards.push(x); });
  if (!cards.length) cards = [...document.querySelectorAll('[data-cel-widget*="search_result"]')];

  cards.forEach(x => {
    try {
      const id = x.getAttribute('data-asin') || '';
      if (!id || id.length !== 10 || seen[id]) return;

      // BUG FIX (live-verified): querying `[class*="title"] span` across the
      // whole card also matches Amazon's sponsored-ad disclosure block
      // ("Sponsored ... Leave ad feedback"), whose wrapper class also
      // contains "title", and querying `h2 span` across the whole card
      // picks up OTHER h2 badges (e.g. "Global Recycled Standard") that
      // sit as siblings of the real title h2. Scope strictly to the
      // FIRST h2 in the card, which is always the actual product title.
      const titleH2 = x.querySelector('h2');
      let title = titleH2 ? Array.from(titleH2.querySelectorAll('span')).map(s => s.innerText.trim()).filter(t => t.length > 1).join(' ') : '';
      if (!title && titleH2) title = (titleH2.innerText || '').trim();
      if (!title) { const at = x.querySelector('a[href*="/dp/"] span, a[href*="/dp/"]'); title = at ? (at.innerText || '').trim() : ''; }
      if (!title || title.length < 5) return;

      let price = '';
      const pe = x.querySelector('.a-price .a-offscreen,[class*="price"] .a-offscreen,span.a-price-whole');
      if (pe) price = pe.innerText.trim();
      if (!price) { const pm = (x.innerText || '').match(/\$[\d,.]+/); price = pm ? pm[0] : ''; }
      if (!price || nm(price) < MIN) return;
      seen[id] = true;

      let store = '', storeLink = '';
      const storeA = x.querySelector('a[href*="/stores/"],a[href*="/sp?"],a[href*="seller="],a[href*="/s?me="]');
      // BUG FIX (live-verified — reported by user): `.split('?')[0]` used
      // to strip the whole query string here, but Amazon's "/sp?seller="
      // and "/s?me=" seller/brand links carry the seller ID IN the query
      // string — stripping it left a dead "/sp" or "/s" that redirects to
      // the homepage instead of the seller page. Only drop the hash.
      if (storeA) { storeLink = absUrl(storeA.getAttribute('href') || '').split('#')[0]; store = (storeA.innerText || '').trim().substring(0, 40); }
      if (!store) x.querySelectorAll('span.a-size-base.a-color-secondary,span.a-color-secondary').forEach(sp => {
        const bt = (sp.innerText || '').trim(); const byM = bt.match(/^by\s+(.+)/i); if (byM && !store) store = byM[1].substring(0, 40);
      });
      if (!store) { const visit = x.querySelector('a[href*="/stores/"]'); if (visit) store = (visit.innerText || '').replace(/^Visit the\s+/i, '').replace(/\s+Store$/i, '').substring(0, 40); }

      let rating = '';
      const st = x.querySelector('[aria-label*="out of 5"],[aria-label*="de 5"],[aria-label*="von 5"],i[class*="a-star"]');
      if (st) { const m = (st.getAttribute('aria-label') || st.parentElement?.getAttribute('aria-label') || '').match(/([\d.]+)\s+(?:out of 5|de 5|von 5)/); if (m) rating = m[1]; }
      if (!rating) { const m2 = (x.innerText || '').match(/([\d.]+)\s+out of 5 stars/i); if (m2) rating = m2[1]; }

      let reviews = '';
      const rl = x.querySelector('a[aria-label*="ratings"],a[aria-label*="valoraciones"],a[aria-label*="Bewertungen"],span[aria-label*="ratings"]');
      if (rl) { const m = (rl.getAttribute('aria-label') || '').match(/([\d,.]+)\s+(?:ratings|valoraciones|Bewertungen)/i); if (m) reviews = m[1].replace(/,/g, ''); }
      if (!reviews) {
        const rb = x.querySelector('.a-row.a-size-small,[class*="rating"]');
        if (rb) {
          const links = rb.querySelectorAll('a,span');
          for (let i = 0; i < links.length; i++) {
            const t = (links[i].innerText || '').trim();
            if (/^\([\d,.]+[KkMm]?\)$/.test(t) && !/bought|sold/i.test(rb.innerText)) { reviews = t.replace(/[()]/g, ''); break; }
          }
        }
      }

      let origP = '';
      const origEl = x.querySelector('.a-price[data-a-strike="true"] .a-offscreen,.a-text-price .a-offscreen,[data-a-strike="true"] .a-offscreen');
      if (origEl) origP = origEl.innerText.trim();

      let delivery = '', delCost = '';
      const dEl = x.querySelector('[data-cy="delivery-recipe"],[class*="delivery"]');
      if (dEl) {
        const dt = dEl.innerText;
        const dm = dt.match(/((?:Mon|Tue|Wed|Thu|Fri|Sat|Sun|Tomorrow|mañana|lun|mar|mié|jue|vie)[^\n]{0,25}\d+|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*\s+\d+(?:\s*-\s*\d+)?)/i);
        if (dm) delivery = dm[1].trim();
        if (/gratis|free/i.test(dt)) delCost = 'FREE';
      }

      const badgeEl = x.querySelector('.a-badge-text,[class*="badge"]');
      const badge = badgeEl ? (badgeEl.innerText || '').trim() : '';

      let sold = '';
      x.querySelectorAll('.a-size-base,.a-color-secondary,span').forEach(sp => {
        const t = (sp.innerText || '').trim();
        if (/bought|purchased|verkauft/i.test(t) && !/rating|review/i.test(t) && !sold) sold = t.substring(0, 35);
      });

      const link = 'https://' + host + '/dp/' + id;
      const images = H.collectImages(x, 5).join(' | ');
      rows.push({ Item: title, Store: store, StoreLink: storeLink || '', Link: link, SalePrice: price, OrigPrice: origP, Discount: '', DelCost: delCost, Setup: '', Delivery: delivery, Return: '', Rating: rating || '', Reviews: reviews || '', Sold: sold || '', Condition: '', Badge: badge, MOQ: '', SupplierInfo: '', Description: '', Specifications: '', Images: images });
    } catch (e) { /* skip malformed card, keep going */ }
  });

  // Last resort — embedded hydration JSON (DOM-change-proof). If Amazon
  // rolls out a completely new card layout and every selector above finds
  // nothing, pull title/price/ASIN straight from whatever React hydration
  // state the page shipped before rendering, instead of returning empty.
  if (!rows.length) {
    H.findEmbeddedProducts().forEach(p => {
      if (!p.title || !p.id || seen[p.id]) return;
      seen[p.id] = true;
      rows.push({ Item: p.title.substring(0, 200), Store: '', StoreLink: '', Link: 'https://' + host + '/dp/' + p.id, SalePrice: p.price, OrigPrice: '', Discount: '', DelCost: '', Setup: '', Delivery: '', Return: '', Rating: '', Reviews: '', Sold: '', Condition: '', Badge: '', MOQ: '', SupplierInfo: '', Description: '', Specifications: '', Images: p.image ? H.upgradeImageUrl(p.image) : '' });
    });
  }
  return rows;
};
