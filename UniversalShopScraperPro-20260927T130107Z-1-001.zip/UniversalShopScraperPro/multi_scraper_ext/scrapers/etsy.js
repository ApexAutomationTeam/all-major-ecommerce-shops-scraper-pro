// ═══════════════════════════════════════════════════════════════════════
// scrapers/etsy.js — Etsy search results (PLP)
// BUG FIX (live-verified): the JSON-LD ItemList Etsy embeds only contains
// ~11 "picked" listings out of the 60+ actually on the page — using it as
// the primary source was silently dropping ~80% of results. DOM scraping
// of the <li class="wt-grid__item..."> cards is now primary (captures
// all of them); JSON-LD is kept as a secondary enrichment pass that fills
// in any field the DOM regexes missed for listings it happens to cover.
// ═══════════════════════════════════════════════════════════════════════
window.ScraperRegistry = window.ScraperRegistry || {};

window.ScraperRegistry.etsy = function scrapeEtsy() {
  const H = window.ShopHelpers;
  const rows = [], seen = {};

  // Primary — DOM cards (covers every listing on the page)
  document.querySelectorAll('li[class*="wt-grid__item"], .v2-listing-card, [data-listing-id]').forEach(li => {
    try {
      const a = li.querySelector ? li.querySelector('a[href*="/listing/"]') : null;
      if (!a) return;
      const url = (a.href || '').split('?')[0];
      if (!url || seen[url]) return;
      const text = li.innerText || '';
      if (text.length < 10) return;
      // BUG FIX (live-verified — reported by user): `[class*="title"]`
      // also matches Etsy's "Find similar" button (class
      // "wt-text-title-small" — a UI label, not a product heading), and
      // since it's an <h3> too it wins the `h3,[class*="title"]` query
      // before the real title is ever checked. The link's own aria-label
      // already carries the full, correct listing title — trust that
      // first and only fall back to the h3 scan (with the button text
      // explicitly excluded) if aria-label is somehow missing.
      const ariaTitle = (a.getAttribute('aria-label') || '').trim();
      let title = ariaTitle;
      if (!title) {
        const h3 = [...li.querySelectorAll('h3,[class*="title"]')].find(el => {
          const t = (el.innerText || '').trim();
          return t.length > 4 && !/^(find similar|report this ad|add to favou?rites)$/i.test(t);
        });
        title = (h3 ? h3.innerText : (a.innerText || '')).trim();
      }
      if (!title || title.length < 5) return;
      seen[url] = true;

      const shopM = text.match(/From shop\s+([^\n]{2,30})/i) || text.match(/(?:Sold by|By)\s+([^\n]{2,30})/i);
      const store = shopM ? shopM[1].trim() : '';
      const priceM = text.match(/(?:USD|PKR|US\$|\$|€|£)\s*[\d,.]+/i);
      const price = priceM ? priceM[0] : '';
      const ratM = text.match(/\b([1-5]\.\d)\b/);
      const rating = ratM ? ratM[1] : '';
      const revM = text.match(/\((\d[\d,]*)\)/);
      const reviews = revM ? revM[1].replace(/,/g, '') : '';
      const freeShip = /Free delivery|Free shipping/i.test(text);
      const images = H.collectImages(li, 5).join(' | ');

      rows.push({ Item: title, Store: store, StoreLink: '', Link: url, SalePrice: price, OrigPrice: '', Discount: '', DelCost: freeShip ? 'FREE' : '', Setup: '', Delivery: '', Return: '', Rating: rating, Reviews: reviews, Sold: '', Condition: '', Badge: '', MOQ: '', SupplierInfo: store, Description: '', Specifications: '', Images: images });
    } catch (e) { /* skip malformed card */ }
  });

  // Secondary — JSON-LD enrichment: fill gaps for listings it covers
  document.querySelectorAll('script[type="application/ld+json"]').forEach(jld => {
    try {
      const d = JSON.parse(jld.textContent);
      if (!d.itemListElement) return;
      d.itemListElement.forEach(li => {
        try {
          const item = li.item;
          if (!item || item['@type'] !== 'Product') return;
          const url = (item.url || '').split('?')[0];
          const row = rows.find(r => r.Link === url);
          if (!row) return; // don't add duplicates here — DOM pass is authoritative for coverage
          const p = item.offers || {};
          const ar = item.aggregateRating || {};
          if (!row.SalePrice && p.price) row.SalePrice = (p.priceCurrency || '') + ' ' + p.price;
          if (!row.Rating && ar.ratingValue) row.Rating = String(ar.ratingValue);
          if (!row.Reviews && ar.reviewCount) row.Reviews = String(ar.reviewCount);
          if ((!row.Images || row.Images === '—') && item.image) {
            const imgs = Array.isArray(item.image) ? item.image : [item.image];
            row.Images = imgs.filter(Boolean).slice(0, 5).map(H.upgradeImageUrl).join(' | ');
          }
        } catch (e) {}
      });
    } catch (e) {}
  });

  // Last resort — embedded hydration JSON (DOM-change-proof). If Etsy's
  // card markup changes entirely and both passes above find nothing, pull
  // title/price/listingId straight from the page's own hydration state.
  if (!rows.length) {
    H.findEmbeddedProducts().forEach(p => {
      if (!p.title || !p.id) return;
      const link = 'https://www.etsy.com/listing/' + p.id;
      if (seen[link]) return;
      seen[link] = true;
      rows.push({ Item: p.title.substring(0, 200), Store: '', StoreLink: '', Link: link, SalePrice: p.price, OrigPrice: '', Discount: '', DelCost: '', Setup: '', Delivery: '', Return: '', Rating: '', Reviews: '', Sold: '', Condition: '', Badge: '', MOQ: '', SupplierInfo: '', Description: '', Specifications: '', Images: p.image ? H.upgradeImageUrl(p.image) : '' });
    });
  }

  return rows;
};
