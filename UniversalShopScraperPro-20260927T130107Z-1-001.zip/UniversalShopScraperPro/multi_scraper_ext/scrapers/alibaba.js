// ═══════════════════════════════════════════════════════════════════════
// scrapers/alibaba.js — Alibaba search results (PLP)
// ═══════════════════════════════════════════════════════════════════════
window.ScraperRegistry = window.ScraperRegistry || {};

window.ScraperRegistry.alibaba = function scrapeAlibaba() {
  const H = window.ShopHelpers;
  const rows = [], seen = {};
  document.querySelectorAll('h2').forEach(h2 => {
    try {
      const title = (h2.innerText || '').trim();
      if (!title || title.length < 5 || seen[title]) return;
      let card = h2;
      for (let j = 0; j < 8; j++) { if (!card.parentElement) break; const p = card.parentElement; if (p.querySelectorAll('h2').length > 1) break; card = p; }
      const text = card.innerText;

      const lk = card.querySelector('a[href*="alibaba.com/product"]');
      const url = lk ? lk.href : '';
      if (!url) return;
      seen[title] = true;

      // BUG FIX (live-verified — reported by user): StoreLink used to be
      // set to the SAME product-detail URL as `Link`, so clicking "Store
      // Link" just reopened the product page instead of the supplier's
      // storefront. The real supplier link lives on its own anchor
      // (class "searchx-product-e-company", href like
      // "https://<slug>.en.alibaba.com/company_profile.html") — grab that
      // directly instead of reusing the product link.
      const companyA = card.querySelector('a.searchx-product-e-company') ||
        [...card.querySelectorAll('a')].find(a => /(Co\.,?\s*Ltd\.?|Corporation|Trading Co|Factory|Manufacturer)\b/i.test((a.textContent || '').trim()) && (a.textContent || '').trim().length < 80);
      const companyHref = companyA ? H.absUrl(companyA.getAttribute('href') || '').split('#')[0] : '';

      const pm = text.match(/(?:PKR|US\$|\$|€)\s*[\d,.]+(?:\s*[-–]\s*(?:PKR|US\$|\$|€)?\s*[\d,.]+)?/);
      const price = pm ? pm[0] : 'Inquiry';

      const moqM = text.match(/Min\.\s*order:\s*([\d,]+\s*\w+)/i) || text.match(/(\d+)\s*(?:Pieces?|Units?)\s*\(Min/i);
      const moq = moqM ? moqM[0].substring(0, 25) : '—';

      const ratM = text.match(/([\d.]+)\s*\/\s*5\.0/);
      const rating = ratM ? ratM[1] : '';

      const revM = text.match(/\((\d+)\)/);
      const reviews = revM ? revM[1] : '';

      const yrsM = text.match(/(\d+)\s*yrs?/i);
      const yrs = yrsM ? yrsM[0] + ' on Alibaba' : '';

      // BUG FIX (live-verified): the old cross-line regex latched onto
      // whatever word preceded "Co., Ltd." (often just "Technology") and
      // then grabbed 30 more characters INCLUDING following lines ("1
      // yr\nCN\nAdd to cart..."), producing garbage company names. The
      // company is reliably its own single line in the card text — find
      // that line instead of pattern-matching across line breaks.
      // BUG FIX (live-verified — reported by user): "Alibaba" itself is
      // never the supplier — it's the marketplace. The real company name
      // is always present on the search card; prefer the company anchor's
      // own text (most reliable), then fall back to the line-scan, and
      // only use the generic placeholder if truly nothing was found.
      const companyLine = text.split('\n').map(l => l.trim()).find(l => /(Co\.,?\s*Ltd\.?|Corporation|Trading Co|Factory|Manufacturer)\b/i.test(l) && l.length < 80);
      const company = (companyA && (companyA.textContent || '').trim()) || companyLine || 'Alibaba Supplier';

      const cnM = text.match(/\b(CN|IN|TR|VN|TW|TH)\b/);
      const country = cnM ? cnM[1] : '';

      const verified = /verified/i.test(text);

      const images = H.collectImages(card, 5).join(' | ');
      rows.push({ Item: title, Store: company, StoreLink: companyHref || '', Link: url, SalePrice: price, OrigPrice: '', Discount: '', DelCost: '', Setup: '', Delivery: '', Return: '', Rating: rating || '', Reviews: reviews || '', Sold: 'N/A', Condition: '', Badge: verified ? 'Verified Supplier' : '', MOQ: moq, SupplierInfo: yrs + (country ? ' | ' + country : '') + (verified ? ' | Verified' : ''), Description: '', Specifications: '', Images: images });
    } catch (e) { /* skip malformed card */ }
  });

  // Last resort — embedded hydration JSON (DOM-change-proof). If every
  // `h2`-based DOM strategy above finds nothing, pull title/price straight
  // from Alibaba's own search-page hydration state. Alibaba product URLs
  // require an exact slug (numeric ID alone 404s), so — unlike the sites
  // where a bare "/dp/<id>"-style link is known to work — the Link column
  // here honestly points back to this search page rather than guessing a
  // broken product URL.
  if (!rows.length) {
    H.findEmbeddedProducts().forEach(p => {
      if (!p.title || seen[p.title]) return;
      seen[p.title] = true;
      rows.push({ Item: p.title.substring(0, 200), Store: '', StoreLink: '', Link: location.href.split('#')[0], SalePrice: p.price, OrigPrice: '', Discount: '', DelCost: '', Setup: '', Delivery: '', Return: '', Rating: '', Reviews: '', Sold: '', Condition: '', Badge: '', MOQ: '', SupplierInfo: '', Description: '', Specifications: '', Images: p.image ? H.upgradeImageUrl(p.image) : '' });
    });
  }
  return rows;
};
