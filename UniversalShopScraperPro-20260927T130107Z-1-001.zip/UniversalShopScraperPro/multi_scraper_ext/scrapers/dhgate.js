// ═══════════════════════════════════════════════════════════════════════
// scrapers/dhgate.js — DHgate search results (PLP)
// ═══════════════════════════════════════════════════════════════════════
window.ScraperRegistry = window.ScraperRegistry || {};

window.ScraperRegistry.dhgate = function scrapeDhgate() {
  const H = window.ShopHelpers;
  const rows = [], seen = {};
  document.querySelectorAll('.gallery-main, [class*="gallery-main"], [class*="product-item"]').forEach(card => {
    try {
      const text = card.innerText;
      if (!text || text.length < 30) return;
      const lk = card.querySelector('a[href*="dhgate.com/product"],a[href*="/product/"]');
      const url = lk ? lk.href : '';
      if (!url || seen[url]) return;
      seen[url] = true;

      const lines = text.split('\n').map(l => l.trim()).filter(l => l.length > 5);
      let title = '';
      for (const l of lines) { if (l.length > 20 && !/^(US\s*\$|Free|Endorsed)/.test(l)) { title = l; break; } }
      if (!title) return;

      const pm = text.match(/US\s*\$[\d.]+\s*[-–]\s*[\d.]+/) || text.match(/US\s*\$[\d.]+/);
      const soldM = text.match(/(\d+)\s*Sold/i);
      const sold = soldM ? soldM[1] + ' sold' : '';
      const ratM = text.match(/([\d.]+)\s*$/m);
      const rating = (ratM && parseFloat(ratM[1]) <= 5) ? ratM[1] : '';
      const shipFree = /Free Shipping/i.test(text);
      const delivM = text.match(/(\d+)\s*Days?\s*Del/i);
      const endorsed = /Endorsed/i.test(text);

      let store = 'DHgate', storeLink = url;
      const storeA = card.querySelector('a[href*="/store/"]');
      if (storeA) { storeLink = storeA.href; store = (storeA.innerText || 'DHgate').trim().substring(0, 40) || 'DHgate'; }

      const images = H.collectImages(card, 5).join(' | ');
      rows.push({ Item: title.substring(0, 90), Store: store, StoreLink: storeLink, Link: url, SalePrice: pm ? pm[0] : 'See DHgate', OrigPrice: '', Discount: '', DelCost: shipFree ? 'FREE' : '', Setup: '', Delivery: delivM ? delivM[0] : '', Return: '', Rating: rating || '', Reviews: 'N/A', Sold: sold || '', Condition: '', Badge: endorsed ? 'Endorsed' : '', MOQ: '', SupplierInfo: '', Description: '', Specifications: '', Images: images });
    } catch (e) { /* skip malformed card */ }
  });
  return rows;
};
