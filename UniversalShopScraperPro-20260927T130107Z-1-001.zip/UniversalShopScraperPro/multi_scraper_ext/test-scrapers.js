/**
 * Standalone scraper test runner — run in browser console on search pages
 * Usage: paste SCRAPER function + call: SCRAPER('amazon') etc.
 * This file mirrors popup.js SCRAPER for Node-less validation.
 */
// Export test URLs for manual/browser testing
const TEST_URLS = {
  amazon: 'https://www.amazon.com/s?k=bed+frame',
  ebay: 'https://www.ebay.com/sch/i.html?_nkw=iphone',
  walmart: 'https://www.walmart.com/search?q=laptop',
  etsy: 'https://www.etsy.com/search?q=necklace',
  aliexpress: 'https://www.aliexpress.com/w/wholesale-iphone.html',
  alibaba: 'https://www.alibaba.com/trade/search?SearchText=phone+case',
  temu: 'https://www.temu.com/search_result.html?search_key=phone+case',
  daraz: 'https://www.daraz.pk/catalog/?q=phone',
  dhgate: 'https://www.dhgate.com/wholesale/search.do?searchkey=phone+case',
  madeinchina: 'https://www.made-in-china.com/productdirectory.do?word=phone',
  '1688': 'https://s.1688.com/selloffer/offer_search.htm?keywords=phone'
};

function scoreRows(rows, site) {
  if (!rows || !rows.length) return { ok: false, count: 0, issues: ['ZERO products'] };
  const issues = [];
  let withPrice = 0, withLink = 0, withTitle = 0, withRating = 0, withStore = 0, withReviews = 0;
  rows.forEach(r => {
    if (r.Item && r.Item.length > 5) withTitle++;
    if (r.Link && r.Link.startsWith('http')) withLink++;
    if (r.SalePrice && r.SalePrice.length > 1) withPrice++;
    if (r.Rating && r.Rating !== '—' && r.Rating !== 'N/A') withRating++;
    if (r.Reviews && r.Reviews !== '—' && r.Reviews !== 'N/A') withReviews++;
    if (r.StoreLink && r.StoreLink.startsWith('http') && r.StoreLink !== r.Link) withStore++;
    if (r.Store && r.Store !== '—') withStore++;
  });
  const n = rows.length;
  if (withTitle < n * 0.8) issues.push(`titles: ${withTitle}/${n}`);
  if (withLink < n * 0.8) issues.push(`links: ${withLink}/${n}`);
  if (withPrice < n * 0.5) issues.push(`prices: ${withPrice}/${n}`);
  if (['amazon','walmart','aliexpress','etsy'].includes(site) && withRating < n * 0.3) issues.push(`ratings: ${withRating}/${n}`);
  if (site === 'ebay' && withStore < n * 0.3) issues.push(`storeLinks: ${withStore}/${n}`);
  return { ok: issues.length === 0, count: n, withPrice, withLink, withTitle, withRating, withReviews, withStore, issues, sample: rows[0] };
}

if (typeof module !== 'undefined') module.exports = { TEST_URLS, scoreRows };
